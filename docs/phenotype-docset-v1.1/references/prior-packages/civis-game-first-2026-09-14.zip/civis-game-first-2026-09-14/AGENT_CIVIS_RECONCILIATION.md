# Civis game-first reconciliation — additive agent assignment

This assignment corrects product and decision framing. It does not authorize rewriting the whole game, switching engines, creating repositories, discarding working branches, weakening gates, publishing releases or deleting historical evidence. Continue existing valid work under existing permissions and write ownership.

## Governing direction

Civis is a game first: a persistent, visually expressive, systemic world in which a player can act as a god, leader and individual. The headless world core is supporting architecture, not the primary product. Rendering, animation, input, UI, audio, embodied play and readable consequences are acceptance obligations—not optional marketing work after the backend is finished.

The latest human message is preserved in `docs/intent/user-message-2026-09-14.txt`. The accompanying design document is a proposed formalization. It must not be represented as an operator-approved production-engine decision or as proof of implemented features.

## Begin with a delta reconciliation, not another full audit

Read applicable AGENTS.md, the current scoped work state and current heads/worktrees. Preserve dirty/untracked work, refs, provenance and existing passing evidence. Reuse evidence only when its scope and source equivalence are demonstrated. Other agents remain owners of their existing slices.

Revalidate the findings at the current head. The audit inspected b753c820acb707fcda55e8da0b57fbbec7eac7d9. It did not execute the game or inspect local installations.

Reconcile these exact active records first:
- PRD.md and applicable product/requirements indexes.
- docs/adr/ADR-007-three-renderers.md and the Unreal agent playbook.
- docs/adr/ADR-determinism-dropped.md, docs/guides/emergence-charter.md, and older global determinism documents.
- docs/research/engine-parity/godot.md and unity.md.
- clients/bevy-ref/Cargo.toml and actual package/build scripts.

Return a compact conflict ledger: claim, source, governing human input, current implementation/evidence, proposed resolution, owner and approval needed. Mark supersessions and maintain redirects/indexes. Do not erase history or bulk-replace all uses of “simulation” or “deterministic.”

## Current viable GAME target

Freeze the accepted player-facing horizon, not a minimal backend build. Separate capabilities already promised from newly extrapolated future work. New critical defects in that horizon remain in scope for repair.

Qualify the actual release feature/asset profile. The inspected macOS builder selected bevy,egui,client-bins while models/audio/vfx/pbr-textures were separately gated. Missing assets could be skipped. Recheck and close the mismatch. Do not blindly turn on all expensive or unsupported features; specify real platform variants and required fallbacks.

Build/install outside the source tree, launch through the normal OS entry point, verify the correct binary and assets, exercise useful gameplay, save/quit/relaunch, and capture actual behavior. A silent primitive fallback is not the intended rich game unless explicitly accepted for that profile.

## Reproducibility contract

Do not reinstate global bit-identical or seed-only replay. Do not remove every useful deterministic check either. Declare per-subsystem profiles: exact within a pinned scope, controlled stochastic, authoritative recorded outcomes, or presentation-local variation.

Randomness must not be an excuse for data races, duplicate events, missing state or unstable ownership. Persist actual world and required stochastic/learned state. Separate security randomness from gameplay RNG. Statistical tests require recorded samples, versions and failures, not retry-until-green.

## Multipart generation and branching

Separate content presets, generation keys, stochastic state and saved worlds. Define stable domain-separated keys and a versioned dependency manifest. Locking founder identities/genomes at a branch boundary does not freeze later life histories when knowledge or technology changes.

Branch existing checkpoints without overwriting live worlds. Record parent checkpoint, selected intervention, locked domains and downstream recomputation. Validate conflicting constraints. No implicit claim that a root seed restores months of play.

## Emergence and play roles

Model generative mechanisms and constrained interactions at appropriate scales. Avoid both fixed enumerations of every possible societal outcome and a requirement to derive all biology/culture from fundamental physics. Research one falsifiable generative question with baselines/ablations and a compute budget.

God, leader and individual are authority and action models, not only camera modes. Preserve entity identity/history across control transfer. Define conflict, pending-order, time-mode and autonomy-resumption behavior. Multiple roles do not implicitly add multiplayer to v1.

## Persistent world

Differentiate renderer closed, world paused, host off, unattended running and bounded catch-up. Preserve state on crashes and migrations; never rewrite the sole source save on load. Qualify relevance-based simulation detail, including offscreen important actors and quantities conserved across fidelity changes.

Resource budgets must protect foreground gaming/audio work. Provide a grounded return summary. An accelerated run is not proof of long wall-clock stability.

## Engine research — no unsupported winner

Keep the current Bevy player moving while running bounded candidate experiments. Reopen Unreal versus Unity for production. Evaluate Godot with direct Rust integration separately from godot-bevy. The bridge compatibility table now has a Bevy 0.18 path; the old mismatch is not sufficient grounds for exclusion.

UE 5.8 official experimental MCP and Unity's September 9 official plugin change the agent-tooling baseline. Verify exact versions and local capabilities. Do not depend on future UE6. Keep editor automation isolated/local and serialize mutation per editor instance.

Compare the same living-world scene, dynamic edits, animated agents, overview-to-individual play, actual Windows/Mac builds and end-to-end agent tasks. Distinguish cold/warm runs, static/GPU rendering, mock/live data, and headless/packaged-player evidence. Keep failures and manual interventions. Do not maintain several fully polished clients solely to avoid a decision.

## Acceptance and handoff

Retain all independently applicable coverage floors and stronger accepted thresholds. Do not combine unit/integration/E2E into a passing aggregate; do not substitute docs or screenshots for execution. Add visual/art/usability judgment against a concrete brief, not an invented percentage of “fun.”

Use AgilePlus as tooling for actual scoped work; PhenoDocs as a publication/federation tool; phenotype-journeys for real execution/capture and provenance. Do not create another ownership registry in any of them.

Report: completed player capabilities, exact source and installed artifact identities, executed checks and capture references, remaining failures, authority decisions, and the next bounded useful outcome. Work-package completion, integration, installed qualification and product acceptance remain separate states.
