# Civis game-first design reconciliation

Date: 2026-09-14. Status: proposed design/specification and source-grounded correction.

The main report formalizes the latest human direction without treating old agent-authored “accepted” labels as conclusive authority. It does not select a final production engine or claim native game/benchmark execution.

## Files

- `CIVIS_GAME_FIRST_DESIGN.md`: editable primary report.
- `Civis_Game_First_Design_2026-09-14.docx`: editable formatted report.
- `Civis_Game_First_Design_2026-09-14.pdf`: reading/annotation copy.
- `AGENT_CIVIS_RECONCILIATION.md`: additive, bounded agent handoff.
- `docs/intent/user-message-2026-09-14.txt`: exact supplied message text, not original audio.
- `docs/intent/provenance.json`: text-source provenance and digest.
- `research/sources.json`: pinned repository reads and external primary sources.
- `specification/requirements.json`: proposed requirement inventory with origin classification and acceptance conditions.
- `work/work-packages.json`: work dependencies, outputs and scope boundaries.
- `validation.json`: actual package checks; not a game test report.
- `SHA256SUMS`: file integrity manifest, not a trusted signature.

No repository changes, engine installations, new registrations, provider changes, deletions, deployments, game captures or native tests were performed. Old portfolio packages were left unchanged. New human requirements may need implementation; their presence in this packet is not evidence they already work.
