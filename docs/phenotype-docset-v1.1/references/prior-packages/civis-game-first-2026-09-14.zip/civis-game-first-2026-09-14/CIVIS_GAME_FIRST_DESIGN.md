# Civis: Game-First Design Reset

**Product charter, architecture reconciliation, engine decision plan, and current-viable-game acceptance**

**Edition:** Proposed reconciliation P0 · 14 September 2026  
**Repository inspected:** KooshaPari/Civis at `b753c820acb707fcda55e8da0b57fbbec7eac7d9`  
**Status:** Latest human intent is the governing input. New technical contracts and priorities below are proposals, not fabricated approvals. No repository files were modified, no engine benchmark was executed, and no installed game was tested during this review.

> Civis is a persistent, visually expressive, systemic sandbox game. The player can shape a world as a god, govern within it as a leader, and inhabit it as an individual. The world develops through interacting rules, retains its history, and remains worth returning to. A headless living-world runtime supports this experience; it is not the product's identity.

## Reading map

This document separates four things that the existing documents often mix: **what the player should experience; what the software must guarantee; what has actually been demonstrated; and which technology should deliver it.** Sections 1–2 reconcile intent and evidence. Sections 3–6 define play, emergence, randomness, and seeds. Sections 7–8 cover persistence and runtime architecture. Sections 9–10 evaluate engines and agent workflows. Sections 11–12 define delivery and the reconciliation work.

The source IDs in brackets resolve in the final source register and `research/sources.json`. User requirements originate in the unedited message preserved under `docs/intent/`; design extrapolations are not represented as words the user said.

# 1. What this correction changes

## 1.1 Product priority, not an argument against simulation

The distinction is not whether Civis computes a simulation. It plainly needs a substantial world model. The distinction is which outcome governs engineering decisions. A fascinating headless run that produces an unreadable, lifeless or unpleasant player experience has not completed the game. Conversely, attractive scenery without causal agency, persistent consequences and meaningful play has not completed it either.

The target is the combination: readable systemic behavior, responsive interaction, distinctive creatures and settlements, satisfying audiovisual feedback, and long-lived worlds. Research and automation are enabling capabilities and potentially valuable secondary uses. They must not displace the player as the primary customer.

The earlier portfolio audit overemphasized simulation and packaging readiness. A compiled `.app` is only a distribution boundary. It is not evidence that the right renderer profile, assets, gameplay loops, permissions, save state or presentation actually work together.

## 1.2 Commitments from the latest human message

The current direction requires a game-first visual and interaction bar; a justified production-engine decision; useful scoped reproducibility without a universal bit-identical mandate; independently configurable generation domains; generative life and society; distinct god, leader and individual play; and persistence across long periods, including optional unattended operation.

It does **not** establish a final Unreal-versus-Unity winner, require every subsystem to be nondeterministic, mandate scientific accuracy, authorize a complete rewrite, or require multiplayer. The repository's charter currently identifies single-player as the v1 scope. Multiple clients, multiple viewpoints and multiple control roles do not by themselves overturn that scope. [R08]

## 1.3 Proposed non-goals

Do not attempt a scientifically complete universe, require abiogenesis before ordinary play can begin, promise unbounded evolutionary novelty, or gate every feature on an eventual universal platform. Do not maintain several fully polished shipping clients merely to avoid making an engine decision. Do not make an AI model mandatory for each citizen's moment-to-moment behavior.

These are boundaries on implementation cost, not permission to replace emergence with a small collection of scripted outcomes. Any scope exclusion that removes an already accepted player capability needs its own explicit disposition rather than a convenient reinterpretation of “CVP.”

## 1.4 Decision authority

An `ACCEPTED` label inside an old agent-authored file is evidence that the file claims acceptance; it is not independent proof of an operator decision. Reconcile the source prompt, explicit approval, later correction, implementation and verification. Preserve obsolete records as history and mark their authority accurately instead of leaving conflicting documents active.

In particular, do not replace one global dogma with another. “Everything must be deterministic,” “everything must be random,” and “everything above physics must emerge without any authored abstraction” are each too broad to function as useful engineering contracts.

# 2. What the pinned repository actually says

## 2.1 Conflicting authorities

| Source at the inspected revision | Recorded position | Reconciliation needed |
| --- | --- | --- |
| `PRD.md` | Headless CivLab engine; research-first benefits; global exact replay and deterministic cross-client expectations | Replace active product framing and qualify reproducibility by subsystem/profile. [R02] |
| `ADR-007-three-renderers.md` | Three parallel reference clients; Unreal both showcase and shipping client; Unity dropped | Reopen the shipping decision and justify each maintained client by evidence and cost. [R03] |
| Unreal agent playbook | Unreal is showcase-only and hostile to a complete agent loop; older machine/toolchain restrictions | Separate historical workstation issues from current engine capabilities. [R06] |
| May 30 determinism ADR | Global bit-identical and seed-only reproducibility are no longer required | This correction already exists and must not be overridden by older generic templates. [R07] |
| Emergence charter | Only physical/environmental rules authored; almost everything else emerges; randomness positioned against determinism | Preserve generative ambition, but replace the false opposition and define tractable cross-scale mechanisms. [R08] |
| Bevy client manifest | Presentation features opt-in; default workspace tests avoid full desktop binaries | Qualification must identify the actual shipping feature set and run the player. [R09] |

The coexistence of these records substantiates the user's concern. It does not establish that every implementation is wrong, nor that all earlier decisions lack a valid source. This is a targeted evidence review, not a complete semantic audit of every branch or every game mechanic.

## 2.2 A concrete presentation gap in the packaging path

The current macOS builder selects `civ-bevy-window` with `--features bevy,egui,client-bins`. The client manifest independently gates models, audio, VFX and PBR textures, all off by default. The model path explicitly permits primitive fallback when disabled or when assets are missing. The bundler also skips a missing assets directory without failing. [R09, R10]

Therefore, the present build recipe does not establish the presentation the user expects. This is a source-level finding, not proof that it caused a particular observed ugly build. The repair is **an explicit supported release profile with required asset validation**, not blindly enabling every optional feature. Some advanced features have hardware or dependency constraints.

The required profile must list enabled features, asset-pack digests, minimum hardware, fallbacks, startup behavior and acceptance scenes. Missing required assets must fail qualification; intentionally lower-fidelity modes must be named and reviewed. Tests for a minimal backend profile cannot certify the full game profile.

## 2.3 Engine research needs a different question

The Unity research file largely asks whether Unity can donate code to a Bevy application. That is not the same question as whether Unity is a good production host for Civis. Its source-access and cross-engine asset-license generalizations are also overbroad: Unity offers proprietary source-access arrangements, and asset rights depend on the applicable asset license. [R04, W07, W08]

The Godot research file's bridge compatibility premise is stale: the upstream compatibility table now includes a Bevy 0.18 route. [R05, W03] The Unreal record also makes a royalty inference from placing game logic outside Unreal. Do not use that as an architecture justification; Epic's agreement defines products broadly and requires analysis of the actual product and distribution. This document is not a legal eligibility determination. [R03, W09]

# 3. The player contract

## 3.1 One world, three kinds of agency

A role is a combination of authority, information, available actions and responsibility. It is not a camera preset. The same entity, settlement and world history must survive changes of perspective.

| Role | Primary play loop | Necessary limits and feedback |
| --- | --- | --- |
| God | Observe patterns, sculpt conditions, introduce or alter organisms, intervene, and examine consequences | Powers are explicit. Interventions are attributed; sandbox freedom must not masquerade as an ordinary citizen's action. |
| Leader | Set priorities, allocate resources, delegate, negotiate, build and respond to crises | Authority depends on the selected context: office, jurisdiction, command, legitimacy, resources and information. Mayor and general are distinct command profiles, not just different labels. |
| Individual | Move, perceive, use tools, work, converse, build or fight through an embodied character | Motion, animation, camera, collision and input must feel responsive. Knowledge and abilities belong to the character unless the player chooses an omniscient sandbox policy. |

Observation is an additional read-only stance, usable between interventions or while watching a world evolve. It should not require inventing a fourth independent simulation.

## 3.2 Safe, legible role transfer

A role switch must specify the target identity, authority scope, camera transition, input mapping, time policy and disposition of pending orders. The prior role must relinquish incompatible control. The new role receives a coherent world revision rather than a partially updated state.

For a possessed citizen, transfer control through a lease or equivalent exclusive controller record. On release, autonomous behavior resumes from the character's actual current state. Do not destroy and respawn the citizen to switch modes; that would sever relationships, memory, health, inventory and historical references.

Leaders' background plans need not stop when the player inhabits a citizen. The UI must distinguish delegated plans from direct input and define conflicts. A persistent policy can continue; two controllers must not independently issue contradictory locomotion or inventory mutations to the same actor.

A role switch may fail because the target no longer exists or the world changed. That should produce a clear safe outcome, not a detached camera or control over the wrong actor. Quitting mid-transfer, loading afterward, and switching while accelerated time is active are explicit test cases.

## 3.3 Free sandbox and constrained play are separate policies

The default expression of this intent should permit fluid role changes. Optional challenge rules may limit divine interventions, hide knowledge or bind the player to a dynasty or office. Those constraints must be chosen, not accidentally imposed by the engine or UI.

A “leader” is not synonymous with an all-knowing planner. A god may inspect every settlement while a mayor sees delayed or biased reports. Keep world truth, actor belief, and player-visible information distinct. That separation enables misunderstandings and discovery without silently changing the underlying facts.

## 3.4 A proposed experiential proof scene

Use one living settlement and its surrounding ecology. The player notices a water or food bottleneck, changes terrain as a god, then acts as a leader to redirect labor or infrastructure. The change affects travel, resource access and social choices. The player inhabits one affected resident, traverses the resulting world and performs a useful task. Later, they leave the world running and return to inspect developments and their causes.

This is a vertical acceptance witness, not permission to discard the rest of the current capability horizon. It tests whether the existing subsystems form a game. A passive camera orbit around unrelated systems does not pass.

## 3.5 Presentation is semantic, not decoration

Creature morphology must connect to locomotion, collision, interaction reach and visible activity. Construction should show intention, progress and use. Ecological or economic changes need perceptible consequences: different traffic, architecture, clothing, vegetation, sounds or behavior, rather than only a number in a debug panel.

The art target needs its own reference brief: scale readability, silhouette language, materials, animation, lighting, UI density, camera feel, audio identity and transitions. “AAA” and “Unreal-quality” are not acceptance criteria. A coherent stylized world can be richer and more readable than a photorealistic terrain demo with static capsules.

# 4. Emergence without simulating the universe

## 4.1 The false choice

Civis does not need to choose between rigidly authored social outcomes and deriving civilization from fundamental physics. A tractable game can author **mechanisms and representational building blocks**, then let outcomes arise from their interaction.

The proposed rule is: **author generative mechanisms and constraints; let histories and configurations emerge; explicitly label any authored scenarios or interventions.** That is more useful than claiming that only physics is authored while also hardcoding cognitive traits, speciation thresholds and communication rules.

The scientific language should be honest. A game genome is an engineered heredity representation. A cognitive threshold is a game capability threshold, not evidence of consciousness. A market abstraction is a model selected for behavior and playability, not a verified account of all economic systems.

## 4.2 Proposed cross-scale substrate

| Layer | Deliberately modeled primitives | Outcomes to discover rather than enumerate |
| --- | --- | --- |
| Environment | Material affordances, resource stocks, flows, terrain, selected energy/thermal constraints | Habitats, bottlenecks, local hazards, routes and ecological pressure |
| Organism | Heritable traits and body structures, physiology, reproduction, development and resource needs | Viable morphologies, ecological niches, divergence and local adaptation |
| Mind and behavior | Perception, memory, preferences, learned policies, planning and limited attention | Individual strategies, routines, mistakes and skill differences |
| Knowledge | Observations, demonstrations, beliefs, uncertainty, communication and external records | Uneven diffusion, conventions, expertise, discoveries and misconceptions |
| Social organization | Repeated interaction, trust, obligations, membership, coercion and coordination | Overlapping groups, norms, roles, institutions and political forms |
| Technology | Material operations, transformations, tools, procedures and compositional affordances | Useful inventions, substitutions, production chains and engineering styles |

These layers influence each other through explicit contracts. They need not use one solver, one clock, one ECS or one level of fidelity. “Everything is coupled” is not a reason to let every module read and mutate every other module's internals.

## 4.3 Technology and knowledge need separate representations

Knowing a procedure is not possessing the equipment to perform it. A community can understand a technique but lack materials, tools, energy, coordination or skilled execution. Conversely, it can inherit functioning artifacts whose construction it does not understand.

A useful technology model represents operations and prerequisites as composable relationships. A discovery can be a newly successful composition rather than a fixed named item in a global technology enum. Give it an identity and provenance after it occurs. Naming, interpretation and diffusion are additional processes.

The representational grammar bounds what can be invented. Admit that bound. Extending the operation vocabulary, editable mechanisms or learned-policy family can enlarge the possibility space; it does not make the current version capable of literally any invention.

## 4.4 What artificial-life research contributes

Lenia demonstrates complex life-like patterns from generalized local update rules; its formal update construction is a counterexample to the notion that emergence intrinsically needs uncontrolled randomness. It does not establish the emergence of human technology or society. [W10]

Growing Neural Cellular Automata demonstrates learned local dynamics for growth and regeneration. Its useful lesson here is the interaction of local rules, training and robustness, not that untrained physics automatically gives desired organisms. [W11]

Enhanced POET explores evolving environments and solutions together. It motivates offline diversity search and challenge generation, not a promise that running Civis for more ticks inevitably discovers compelling civilizations. [W12]

These sources suggest research experiments. They are not already integrated Civis features, performance measurements or product proofs.

## 4.5 A bounded research program

Start with one falsifiable generative question, such as whether a small set of material affordances and learning rules yields several useful tool strategies under differing scarcity. Compare against a simpler authored baseline. Measure diversity, persistence, adaptation, causal intelligibility and runtime cost, while checking obvious exploits.

Use multiple seeds and held-out conditions. Run ablations that remove learning, communication, environmental variation or selection pressure. This shows which mechanism causes the interesting behavior. Preserve unsuccessful and degenerate runs, not only attractive recordings.

Do not pick a billion-step target without measuring what a step costs or what changed per unit of compute. Use event-driven updates where valid, bounded coarse-time integration, curated starting states and offline evolved archives. A player can begin with an interesting biosphere or civilization instead of waiting through origin-of-life research every time.

A measured lack of diversity should produce a model revision, not automatically more compute. A result that is diverse but unplayable should produce a game-design revision, not a declaration that the user failed to appreciate emergence.

## 4.6 Directed pacing without fake causality

A game may have a disclosed scenario director that introduces a storm, visitor or opportunity. That is an intervention into the world, not evidence that the event emerged unaided. It should use the same state-changing contracts and respect the selected sandbox/challenge policy.

For the living-world mode, novelty should primarily come from the model. Optional pacing assistance must be disableable and recorded. Summaries may interpret recorded events, but must not invent births, wars, discoveries or causes that the runtime did not produce.

# 5. Scoped reproducibility and controlled randomness

## 5.1 Distinguish four meanings

**Determinism** means fixed specified inputs and execution conditions determine the result. **Predictability** concerns whether an observer can practically anticipate that result. **Reproducibility** concerns recovering a result under a declared scope. **Persistence** concerns restoring the actual world state.

These are related but not equivalent. A reproducible seeded process can feel surprising. A nondeterministic process can repeatedly produce boring outcomes. A deterministic algorithm can still lose data when its save format omits state.

The existing May 30 ADR correctly removes a global requirement. Its implementation guidance should become more specific, not an order to delete all determinism tests. Useful pure transformations, procedural generation and protocol/state invariants still deserve precise checks. [R07]

## 5.2 Proposed subsystem profiles

| Profile | Promise | Appropriate examples |
| --- | --- | --- |
| Exact within a pinned profile | Same relevant state, inputs, versions and numerical/RNG policy produce the same result | Save encoders, ID derivation, recipe validation, selected world generation or rules |
| Controlled stochastic | Decisions use named streams or recorded state; reproducibility is conditional and documented | Mutation, exploratory choices, discovery trials, weather sampling |
| Authoritative recorded outcomes | Accepted results are persisted; rerunning the producer need not reproduce them | External model output, unavoidably nondeterministic solvers, player input arrival |
| Presentation-local variation | Variation is allowed and is not authoritative world truth | Cosmetic particles, selected animation variation, non-gameplay camera effects |

This is not a universal partition dictated by engine names. Each subsystem declares its contract and tests it. Some visual effects affect gameplay and must then cross into an authoritative profile. Security randomness must use appropriate security primitives, separate from game RNG conveniences.

## 5.3 An explicit update model

Conceptually, an authoritative update is:

`next_state = update(current_state, accepted_commands, accepted_external_outcomes, scoped_randomness, policy_version)`

Replay can reapply accepted outcomes rather than rediscover them. For nondeterministic modules, persist the state and outcomes required to continue safely; do not promise full historical re-simulation unless the implementation actually supports it.

Avoid uncontrolled shared random streams whose draw order changes whenever another subsystem adds one call. Counter-based random generators, such as the family represented by Random123, allow samples to be addressed by key and counter. This helps stabilize sample assignment under parallelism; it does not make unrelated state updates deterministic. [W13]

## 5.4 Never use concurrency bugs as creative entropy

A race, missed event, duplicated command, unstable iteration order or uninitialized value is a defect, not useful emergence. Nondeterminism may enter through an explicit source with an owner, distribution or acceptance policy. It must not enter through loss of control over state ownership.

When expensive stochastic behavior cannot be rerun exactly, test safety invariants, distributions, trends and failure boundaries. Use pinned examples for debugging and ensembles for general behavior. Record versions, seeds, sample size, confidence/uncertainty and failures. A retry-until-green loop is not statistical validation.

# 6. Multipart seeds, manifests and world branches

## 6.1 A seed is not a save file

A seed helps specify generation. It does not encode months of player actions, learned state, migrations, accumulated resources, evolving genomes or interactions with external models. Restoring a world therefore uses an actual checkpoint plus the necessary state/journal, not seed-only regeneration.

The repository already uses “seed” for authored creature archetypes as well as random initialization. Keep those concepts distinct in API and UI language: content preset, generation key, stochastic stream state and saved world are different artifacts. [R11]

## 6.2 Proposed generation manifest

A world-origin manifest contains a root identity; generator/ruleset/content/model versions; generation parameters; explicitly named domain keys; and the dependency relationships between generated outputs. Candidate domains include terrain, climate, biosphere, founder genomes, initial population, cultural priors, initial knowledge, available material operations, realized artifacts/infrastructure and historical warm-up.

A domain key is derived from a stable, versioned, domain-separated encoding of the root and domain identity, unless an explicit override supplies that domain's key. Within a domain, samples can be addressed by stable entity/event identifiers and a draw index. Do not use thread IDs, pointer addresses or a language runtime's unspecified default hash as the persistent identity scheme.

A conceptual declaration is:

```text
world_origin: origin-A
ruleset: rules-v1
content_manifest: content-sha256
root_seed: R
component_keys:
  terrain: T
  biosphere: B
  founders: F
  knowledge: K
  technology_opportunities: O
  historical_warmup: H
```

This is a design example, not an implemented Civis file format. Parameter ranges, serialization, IDs, RNG algorithms and migrations must be specified before it is a compatibility promise.

## 6.3 “Same life, different knowledge” needs an exact boundary

A valid branch can start from the same founder identities, genomes and physical state, then vary their initial memories or shared knowledge. This preserves the chosen initial conditions. It does not promise that those characters live identical subsequent lives: changing knowledge should be able to change reproduction, mortality, travel and invention.

Offer distinct operations rather than one ambiguous “reroll” button:

| Operation | What remains fixed | What can change |
| --- | --- | --- |
| Regenerate a component at creation | Explicitly locked upstream generation outputs | Selected component and declared downstream dependents |
| Branch an existing checkpoint | Actual state at the branch boundary, except named intervention | Future events and consequences |
| Controlled comparison | Chosen variables and exogenous inputs under a declared experiment profile | Target mechanism and permitted effects |
| Restart the same preset | Generation manifest under compatible versions | Play history and any intentionally fresh entropy |

If the user requests identical life histories despite different knowledge, the system must explain or expose the artificial constraints required. Do not silently suppress causality to satisfy a vague sameness label.

## 6.4 Dependency-aware variation

Keys alone do not isolate causes. Terrain can affect ecology; anatomy can affect usable tools; knowledge can affect attainable production. The manifest therefore needs a causal dependency graph and a validity pass. Changing an upstream output invalidates dependent generated outputs unless they are explicitly transplanted under a reviewed counterfactual policy.

“Same knowledge, different technology” may mean different known procedures, different physically possible operations, or different existing equipment. Those are distinct controls. The interface should name them accurately and reject impossible combinations or mark them as deliberate fantasy rules.

Existing branches are immutable inputs to the experiment. Creating a variant must not overwrite the player's live world. Record the parent checkpoint, intervention, manifest changes, retained locks and expected downstream recomputations. Preserve branch lineage even when a world is renamed.

## 6.5 Seed acceptance tests

Changing the knowledge key must not change locked founder bytes at the generation boundary. It may change later biology through causal interactions. Adding a cosmetic RNG draw must not perturb a declared independent world-generation stream. Reordering workers must not change keyed draws whose profile promises schedule-independent addressing.

A checkpoint must restore all required stochastic state and learned state. Unknown generator versions must fail clearly or invoke a documented migration. Reroll previews must be cancellable and must not mutate live state before acceptance.

# 7. Worlds that remain useful for months and years

## 7.1 Separate four clocks

Maintain wall time, simulated time, presentation time and experiment/catch-up time as explicit concepts. Closing a renderer, suspending a laptop, pausing a world, advancing time quickly and moving a world to another host are different operations.

The user must be able to close the graphics client while an authorized world host continues within a resource budget. If the host is off, choose between pause, bounded catch-up or a specifically supported offline advancement model. Do not silently advance months because the operating system clock changed.

Fast-forward is not “run every subsystem with an arbitrarily enormous timestep.” Some interactions require event boundaries or finer integration. Measure the approximation error and preserve causal ordering at those boundaries.

## 7.2 Persistence contract

Persist actual world truth: stable identities, relationships, knowledge and beliefs, genomes and developmental state, inventories, institutions, plans, construction, environmental fields, pending commands and stochastic/module state. Generated render meshes may be reconstructible caches; a learned policy or an unrecorded discovery generally is not.

Use coherent checkpoint generations, checksums and an atomic publication boundary. Large worlds can checkpoint partitioned data, but the manifest must identify a mutually consistent cut. An incomplete save must never replace the last valid save. Load and migration must not silently rewrite the sole source copy.

Version rules, content, learned models, native engine bridge and save schemas independently. Define whether an update preserves the current world's rules, migrates them with an explanation, or requires a fork. Avoid swapping a months-old world onto new economic rules simply because an executable auto-updated.

The acceptable crash-loss interval is an explicit operator choice informed by measured checkpoint and journal costs. It is not assumed to be zero, nor hidden behind a “save supported” checkbox.

## 7.3 Scale by relevance, not only camera distance

Full-detail simulation is appropriate for embodied play, active interactions and important causal boundaries. A mid-detail representation can serve settlements and ongoing conflicts. Far regions may use aggregates or event-driven models. Dormant systems may sleep until a relevant event.

However, a favorite offscreen character, a distant war or an actively monitored experiment can remain important. Relevance is a policy over attention, commitments, causal influence and risk, not simply distance from a camera.

Transitions between fidelity levels must preserve the required quantities and relationships. Do not duplicate stockpiles on promotion, forget deaths on demotion, reset cultural memory, or regenerate individuals whenever the player zooms in. Test round-trip promotion/demotion and compare aggregate error over representative workloads.

## 7.4 Render and world budgets

Allocate separate budgets for simulation, presentation, background capture and agent work. The main GPU may also be serving other work; the user has explicitly described gaming and audio-production contention. Sleeping or throttling a background world should be a controlled mode, not a crash or hidden change of physical laws.

Terrain generation, meshing, collider/navmesh updates, population behavior, history storage, rendering and I/O can each be the bottleneck. The charter's assertion that disk is the primary bound is not established by chunking alone. [R08] Measure the actual profile before promising map size or agent count.

## 7.5 Returning must itself be enjoyable

Provide a grounded “while you were away” account: important births/deaths, construction, migrations, ecological shifts, discoveries, conflicts and changes to tracked people or places. Link each claim to recorded facts, show uncertainty for inferred causes, and let the player move directly to the relevant location or history.

Let the player choose unattended policies: continue freely, slow at crises, pause on selected milestones, or protect selected commitments under a disclosed rule. Do not assume that either constant catastrophe or a perfectly frozen safe world is desirable for everyone.

Long-horizon tests need both accelerated simulated-time runs and real wall-clock soaks. They detect different failures: leak growth, timer overflow, checkpoint accumulation, expired credentials, reconnect behavior and background-resource drift cannot all be established by a short accelerated run.

# 8. Runtime architecture that serves the game

## 8.1 Shared authority, rich clients

Retain a renderer-independent living-world core where it provides value. Make it callable through a native boundary or a local/remote session adapter. But stop treating the shipping engine as a disposable pixel terminal.

The presentation/gameplay host should own appropriate camera, animation, audio, UI, input interpretation and local responsiveness. Embodied collision and control may need a high-frequency interaction subsystem. The authority map determines how those results become world truth; it cannot be left to whichever engine component updates last.

For example, the world owns a door's existence, durability and authorization. The client owns hover highlighting and camera easing. Either the authoritative runtime or one explicit physics authority owns whether the character crossed the doorway. Avoid running two conflicting authoritative physics solvers for the same interaction.

## 8.2 Proposed module boundaries

Use modules or applets for world identity/persistence; environment/materials; life/development; cognition/knowledge; society/production; player authority; perception/read models; and presentation adapters. These are capability boundaries, not an instruction to create eight new repositories.

Each boundary exposes typed commands, queries, events and state ownership. Composite applets may be reused at higher levels only when their contracts remain coherent. Recursion needs lifecycle limits, capability attenuation and cycle handling; it must not turn into a universal graph that every frame traverses unnecessarily.

The shared contract should communicate semantic changes and bounded spatial/state data, not an engine's entire internal scene hierarchy. Conversely, do not restrict all interaction to a chatty JSON path when an embedded/native hot path is justified. Measure batching, copying, latency and ownership before selecting transport.

## 8.3 Engine-portable does not mean engine-free assets

Preserve source models, rigs, textures, animation, audio, references and rights in a reproducible asset pipeline. Engine-specific materials, imported assets and optimized formats are legitimate adapters. Record their source and build recipe rather than pretending they are identical across engines.

A common scene manifest can compare candidates while allowing each to use its idiomatic asset and rendering features. One deliberately weakest-common-denominator material implementation would bias the comparison and degrade the game.

## 8.4 Coarse world time and fine player time

A world economy can update less often than a character controller or camera. A responsive 60-frame-per-second client does not require every social system to update at 60 Hz. Likewise, a fast headless tick does not establish good frame pacing. Correct the old PRD's direct equivalence between server tick and render rate. [R02]

For direct control, test action-to-feedback latency, collision stability, animation transitions and network/IPC delays. World updates may be interpolated, predicted or queued according to the ownership contract. Every prediction that affects persistent truth requires explicit reconciliation.

# 9. Production-engine decision: reopen, then measure

## 9.1 Interim recommendation

**Keep the existing Bevy client as the immediate playable delivery baseline. Reopen Unreal-versus-Unity as the production decision. Give Godot, with either a direct Rust boundary or godot-bevy, a bounded qualification path. Do not assume UE6 is the current target.**

This preserves useful current implementation without converting sunk cost into permanent architecture. Unreal is a reasonable visual-production hypothesis, not a winner proven by this review. Unity is a serious candidate, not merely a bag of concepts to copy. Godot's place depends on measured production and integration value, not an assumed perpetual UX-prototype role.

## 9.2 Corrected current facts

Epic's UE6 roadmap targets Early Access at the end of 2027 and says its visible development stream is not an alpha/general-adoption baseline. Treat future UE6 persistence/distribution ideas as watch items, not dependencies of today's CVP. [W01]

UE 5.8 has an official experimental MCP route. It provides editor control but has incomplete APIs, serial game-thread calls and no authentication on its local endpoint. This changes the old agent-hostility assessment; it does not prove reliable unattended Civis production. [W02]

The godot-bevy compatibility table lists 0.11.x with Bevy 0.18, Godot-Rust 0.4 and Godot 4.6.x; 0.12.x targets Bevy 0.19. The bridge brings Bevy ECS into Godot's editor/rendering environment, rather than stacking two renderers. [W03]

Unity announced its official Claude Code plugin on September 9, 2026, combining engineering skills, CLI access and MCP Editor control. Compatibility with the user's chosen harnesses must still be tested rather than inferred from that announcement. [W04]

On the M1-family Mac, Epic documents software Lumen support but reserves other advanced paths for newer hardware. A Windows showcase configuration is therefore not automatically the laptop's render profile. [W05]

## 9.3 Candidate comparison as engineering hypotheses

| Candidate | Why test it for Civis | What must be demonstrated, not assumed |
| --- | --- | --- |
| Current Bevy client | Lowest immediate migration burden; existing Rust code and interactions are available to qualify | A complete rich-content player profile, usable tooling, native packaging, credible art/animation pipeline and dynamic-world performance |
| Godot + direct Rust integration | A potential editor/content workflow without requiring the whole authoritative core to become Bevy ECS | Efficient state boundary, collision/animation ownership, native extension distribution and tested content iteration |
| Godot + godot-bevy | A potential reuse route where Bevy ECS systems are genuinely portable | Version compatibility, lifecycle/transform ownership and maintenance cost better than direct integration |
| Unreal 5.x + living-world bridge | A production candidate aligned with the stated visual ambition | Agent iteration on real assets, dynamic terrain/collision/nav behavior, Windows/Mac profiles, packaged-player tests and sustainable cook/build cost |
| Unity + living-world bridge | A production alternative deserving a fair player/editor evaluation | Pipeline choice, bridge overhead, dynamic content, large-world behavior, artifact quality and repeatable agent-driven iteration |

There are no fabricated numeric scores in this table. Capabilities, documentation and architectural fit motivate experiments; they do not substitute for results.

## 9.4 What “Bevy versus Godot” actually compares

There are at least three architectures: keep Bevy's renderer and ECS; use Godot as the presentation host with a direct Rust core; or move reusable Bevy ECS systems into Godot through the bridge. These have different dependencies and migration work.

Do not introduce a second ECS solely because the bridge exists. First identify how much current logic actually depends on Bevy types, how much is plain Rust, and how much belongs to the presentation layer. The viable reuse unit may be a library or protocol, not a wholesale scene conversion.

## 9.5 A single representative benchmark scene

Each serious candidate should present the same world checkpoint, content target, camera route and interaction script: settlement at overview scale; animated inhabitants; terrain/water/material changes; construction; direct movement; day/night; selection and menus; saves and return. Include a dynamic change that forces mesh, collision and navigation updates, not just a static beauty scene.

Use both a controlled comparison with common inputs and an idiomatic comparison that lets each engine express its best practical implementation. Report what changed between them. Compare on the user's Windows/GPU system and the M1-family laptop under documented profiles, with a separate future-hardware profile only when needed.

Measure frame-time distributions and spikes, input latency, simulation interference, resident memory/VRAM, cold/warm start, shader/import stalls, package size, and asset/error handling. Include qualitative art-direction and usability review. Do not award the winner to the engine with the best idle FPS in an empty scene.

## 9.6 Decision gates

A candidate must meet the accepted player-facing feature scope, supported-platform contract, required automated verification, asset provenance and viable development workflow. Among passing candidates, compare quality, iteration cost, runtime headroom, compatibility, staffing/tooling burden and long-term maintenance.

Failure to meet a mandatory constraint cannot be averaged away by an attractive weighted score. When a candidate fails, distinguish an inherent limitation, missing adapter, bad prototype, uninstalled toolchain and temporary defect. Archive experiment evidence; do not interpret a broken first attempt as proof that an engine can never work.

Select one production client when evidence supports the decision. Keep other clients only for a clearly owned purpose with an explicit parity and maintenance budget. Do not demand four complete games before making that choice.

# 10. Agent development and verification

## 10.1 A useful engine-agent benchmark

Give each environment the same bounded tasks: alter a material, import and rig a creature, wire a visible command, add an interaction test, run a render capture, build an installable artifact and recover from an editor restart. Measure successful completion, operator interventions, retained state, bad edits, review burden and time/cost under the same harness/model profile.

Separate transport stability from competence. A harness that keeps a conversation connected has an advantage, but it still needs to identify the live editor, correct project, exact revision and actual result. Cached tool discovery is not proof that a restarted editor has registered the current toolset.

## 10.2 Native sessions and controlled concurrency

Use one authorized writer per editor session or transactional resource. Independent workers can use isolated worktrees, editor instances, ports, temporary directories and asset ownership leases. Do not let several agents mutate the same binary asset, scene or editor selection concurrently and call the resulting repair churn “parallelism.”

Commands need bounded execution, cancellation, ownership and result receipts. Retry after a disconnect only when the operation is idempotent or its outcome can be queried. Do not duplicate a world mutation because a network response was lost.

Keep editor-control endpoints local and isolated. They are powerful development interfaces, not a game server API. Exposing an unauthenticated editor MCP endpoint through the user's general network fabric is outside the supported trust boundary. [W02]

## 10.3 Several proof layers

Native unit and integration tests check contracts. Packaged-player automation checks actual launches and play flows. GPU-enabled captures check visible state. Art and usability evaluation check the interpretation and feel that structural tests cannot establish.

Epic's Gauntlet provides a session-oriented automation option. Unity and Godot expose command-line automation paths. [W06, W14, W15] Headless or no-graphics execution remains useful, but cannot alone certify rendering, audio, input, animation, permissions or the installed application.

Phenotype-journeys should orchestrate these real paths and preserve their evidence. PhenoDocs should publish source-backed product and research views. AgilePlus should track actual scoped work and receipts. None becomes an excuse to replace the game with a registry or another documentation-only milestone.

# 11. Current viable game: acceptance, not just packaging

## 11.1 Freeze the right horizon

Freeze current accepted player capabilities and known gaps at a named revision/profile. Do not freeze an accidental minimal build and call omitted features optional after the fact. Conversely, do not turn every newly extrapolated long-term requirement into an immediate blocker without an approved release horizon.

New defects discovered in the current horizon remain repair work. New breadth belongs in the next horizon unless it is necessary to close the selected experience. There must be one accountable integration owner for the candidate artifact even when several agents own different capability slices.

## 11.2 Proposed acceptance sequence

| Gate | Required evidence |
| --- | --- |
| Correct product profile | Exact executable revision, features, assets, content/rules versions and hardware profile |
| Installed launch | Clean install outside the repository; launch from the normal operating-system entry point; no development server dependency hidden from the user |
| Visible living world | Required models, animation, materials, audio, interaction feedback and loading/error states actually present |
| Meaningful play | At least one representative cross-system task, plus coverage of the rest of the accepted horizon |
| Role transfer | God/leader/individual behaviors qualified to their accepted scope with stable identities and clear control |
| Durability | Save, close, restore, crash recovery and compatible update/migration without loss of critical state |
| Persistent operation | Renderer-detached execution, resource limits, reconnect and a grounded return summary |
| Qualification | Independent assurance families, critical invariants, real captures, performance profiles and human play feedback |

The role-transfer and persistence entries represent the target product contract. Where current implementation lacks them, record the gap and a bounded work package; do not fabricate a passing demo or erase the requirement.

## 11.3 Test the actual contract

Retain the earlier independently applicable 85%+ assurance floors and all stronger accepted thresholds. Do not collapse unit, integration and E2E into one combined percentage. The intended executable/feature profile, platform and behavior inventory define the denominator.

No percentage proves fun or artistic quality. Use objective checks for missing assets, clipping, interaction, contrast/readability and state feedback, plus a recorded qualitative review against the art/experience brief. A thousand backend assertions cannot certify an untested camera or silent audio path.

Use deterministic fixtures where warranted, statistical ensembles for stochastic behavior, and fault injection for save/transport/migration. Preserve negative results and flaky outcomes. Do not change a test into a skip because it detects a missing required capability.

## 11.4 Proposed witness scenarios

A first installed session should demonstrate creation/loading, a useful action, a visible consequence, role or perspective transfer according to current scope, save/quit/relaunch and continuity. A 24-hour background soak should demonstrate resource stability and reconnect. Longer wall-clock qualification and accelerated simulated-time tests should follow for the months/years promise.

These durations are proposed test designs, not estimates of work this assistant will perform. Passing a 24-hour run is not proof of a year; the evidence claim must state the actual run duration, workload, version and failures.

# 12. Reconciliation and implementation plan

## 12.1 First, correct active authority

Map the latest human intent to the PRD, emergence charter, determinism guide, renderer ADR, client contracts and release profile. Record each conflict with an old source and a proposed replacement. Preserve old text in history; remove its active normative force through supersession links and generated indexes.

Do not bulk-replace every word “simulation” or delete useful deterministic modules. “Simulation” remains an implementation concept. “Deterministic” remains valid where a subsystem opts into a specific guarantee. What changes is the universal product claim.

## 12.2 Then close concrete delivery gaps

Qualify the current Bevy build with its intended features and required assets. Measure the actual player experience before drawing conclusions about the engine's visual ceiling. Inventory incomplete presentation work, authority wiring, save omissions and unhandled states against the accepted horizon.

Implement one coherent player-facing witness while engine experiments proceed in bounded isolated lanes. The witness should consume the same persistent authority and data contracts that later candidates will use. This reduces throwaway work without requiring a generic universal engine abstraction first.

## 12.3 Work packages and dependencies

| ID | Work package | Dependency / completion evidence |
| --- | --- | --- |
| WP-01 | Reconcile product identity and conflicting authority | Pinned conflict ledger and reviewed proposed supersessions |
| WP-02 | Freeze player capabilities and art/interaction brief | WP-01; actual release horizon and explicit gaps |
| WP-03 | Audit executable features and asset manifests | WP-02; required presentation cannot silently fall back |
| WP-04 | Qualify installed Bevy baseline | WP-03; real native gameplay and capture, not only build success |
| WP-05 | Establish scoped randomness and state ownership | WP-01; subsystem profiles, fault cases and explicit entropy boundaries |
| WP-06 | Design and implement generation/branch manifests | WP-05; locked domains, dependency invalidation and checkpoint branching tests |
| WP-07 | Implement/qualify control roles and transfer | WP-02, WP-05; stable actor identity and useful role-specific actions |
| WP-08 | Close persistence and return-loop gaps | WP-05; state inventory, migration, crash recovery and return evidence |
| WP-09 | Run one bounded emergence experiment | WP-02, WP-05; baselines, ablations, diversity and cost evidence |
| WP-10 | Prototype candidate engine/bridge boundaries | WP-02; Unreal, Unity, Godot options screened without full duplication |
| WP-11 | Benchmark render and agent workflows | WP-04, WP-10; same scenario/hardware and actual artifacts |
| WP-12 | Record production-engine decision | WP-11; evidence-based selection and migration/retention plan |
| WP-13 | Integrate current viable game candidate | WP-04, WP-07, WP-08; relevant experiment work only if accepted into the horizon |
| WP-14 | Long-run, performance and player acceptance | WP-13; current-head qualification, actual installation feedback and owned residual work |

WP-12 is not a precondition for fixing the current Bevy game. WP-09 is not permission to delay all play until artificial-life research is complete. Decisions changing accepted architecture, permissions or scope require the appropriate owner.

## 12.4 What to report

Report completed player capabilities; integrated and installed artifact identities; failing current-head obligations; measured quality/performance; discovered behavior; and exact remaining work. Do not report only changed lines, added test counts, number of ADRs or which engine's logo appears in a project file.

The final product acceptance question is: **Can the player inhabit a convincing, causally interesting world, influence it at different scales, leave it, and return to the same world with useful continuity?** The renderer, world model, tools and infrastructure must all serve that question.

# Source register and evidence boundaries

## Repository sources

All repository reads below are pinned to `b753c820acb707fcda55e8da0b57fbbec7eac7d9`; the live ref was independently read in this session. Reading an assertion in source does not validate its runtime behavior. Full URLs, retrieval basis and claim notes are in `research/sources.json`.

[R01] Civis main ref; GitHub connector read.  
[R02] `PRD.md`, first 230 lines; existing product and global determinism claims.  
[R03] `docs/adr/ADR-007-three-renderers.md`; three-client decision and selection rationale.  
[R04] `docs/research/engine-parity/unity.md`; donor-code framing and comparison gaps.  
[R05] `docs/research/engine-parity/godot.md`; bridge and renderer assessment.  
[R06] `docs/development-guide/fr-unreal-agent-playbook.md`; machine-specific and automation guidance.  
[R07] `docs/adr/ADR-determinism-dropped.md`; accepted May 30 correction.  
[R08] `docs/guides/emergence-charter.md`; emergence, determinism and v1 scope.  
[R09] `clients/bevy-ref/Cargo.toml`, first 170 lines; feature and test-profile boundaries.  
[R10] `scripts/build-macos-app.sh`; actual selected features and asset behavior.  
[R11] Search excerpts for `seed`; authored content seeds versus RNG seed terminology.

## Primary external sources

[W01] Epic Games, **The road to Unreal Engine 6**, June 22, 2026. https://www.unrealengine.com/news/the-road-to-ue-6  
[W02] Epic Games, **Unreal MCP**, UE 5.8 documentation. https://dev.epicgames.com/documentation/unreal-engine/unreal-mcp-in-unreal-editor?lang=en-US  
[W03] bytemeadow, **godot-bevy README and compatibility matrix**. https://github.com/bytemeadow/godot-bevy  
[W04] Unity, **Official Unity Plugin for Claude Code**, September 9, 2026. https://unity.com/blog/unity-plugin-for-claude-code  
[W05] Epic Games, **macOS Development Requirements**, UE 5.8 documentation. https://dev.epicgames.com/documentation/en-us/unreal-engine/macos-development-requirements-for-unreal-engine  
[W06] Epic Games, **Gauntlet Automation Framework Overview**. https://dev.epicgames.com/documentation/unreal-engine/gauntlet-automation-framework-overview-in-unreal-engine?lang=en-US  
[W07] Unity, **Source Code Access**. https://unity.com/products/source-code  
[W08] Unity Support, **Can I use assets from the Asset Store with other engines?** https://support.unity.com/hc/en-us/articles/34387186019988-Can-I-use-assets-from-the-Asset-Store-with-other-engines  
[W09] Epic Games, **Unreal Engine EULA**, product definition and distribution terms. https://www.unrealengine.com/eula/unreal  
[W10] Bert Wang-Chak Chan, **Lenia — Biology of Artificial Life**, 2019. https://arxiv.org/html/1812.05433v3  
[W11] Mordvintsev et al., **Growing Neural Cellular Automata**, 2020. https://distill.pub/2020/growing-ca/  
[W12] Wang et al., **Enhanced POET**, 2020. https://arxiv.org/abs/2003.08536  
[W13] Salmon et al./D. E. Shaw Research, **Parallel Random Numbers: As Easy as 1, 2, 3** and Random123. https://random123.com/  
[W14] Unity, **Editor command-line arguments**, Unity 6 documentation. https://docs.unity3d.com/6000.0/Documentation/Manual/EditorCommandLineArguments.html  
[W15] Godot, **Command line tutorial**, stable documentation. https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html

**Verification boundary:** This review performed remote source inspection and primary-source research. It did not run Civis, certify an engine bridge, inspect the user's current installed application, measure graphics performance, run native tests, or establish years-long world stability. The specifications and test plans above define what must be demonstrated next; they are not declarations that those results already exist.
