"""Read-only assurance reference package."""
