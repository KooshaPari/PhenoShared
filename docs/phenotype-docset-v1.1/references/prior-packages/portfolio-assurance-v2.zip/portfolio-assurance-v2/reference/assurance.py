"""Read-only integrity/coverage reference checker; never grants lifecycle approval.

An authorized controller must independently pin the acceptance contract digest,
validate the denominator and authenticate the evidence producer. This helper does
not discover missing requirements, execute product tests, or authenticate humans.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path, PureWindowsPath
from typing import Any

MAX_BYTES = 32 * 1024 * 1024
LAYERS = {'unit', 'integration', 'e2e', 'contract', 'property', 'fuzz', 'mutation',
          'security', 'performance', 'reliability', 'compatibility', 'accessibility',
          'documentation', 'intent', 'sota', 'pilot', 'tooling', 'operations',
          'migration', 'quality_engineering', 'process', 'static_analysis', 'visual'}
METRICS = {'line', 'branch', 'function', 'obligation', 'mutation_kill'}


class Invalid(ValueError):
    """The record cannot support a threshold claim."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise Invalid(message)


def text(value: Any, label: str) -> str:
    require(isinstance(value, str) and bool(value.strip()), f'{label}: nonblank string required')
    return value


def integer(value: Any, label: str, minimum: int = 0) -> int:
    require(type(value) is int and value >= minimum, f'{label}: integer >= {minimum} required')
    return value


def digest(value: Any, label: str = 'digest') -> str:
    require(isinstance(value, str) and bool(re.fullmatch('[0-9a-f]{64}', value)), f'{label}: SHA-256 required')
    return value


def unique(values: Any, label: str, nonempty: bool = True) -> set[str]:
    require(isinstance(values, list), f'{label}: list required')
    if nonempty:
        require(bool(values), f'{label}: empty denominator or selection')
    for value in values:
        text(value, label)
    require(len(values) == len(set(values)), f'{label}: duplicate identities')
    return set(values)


def keys(value: Any, expected: set[str], label: str) -> dict[str, Any]:
    require(isinstance(value, dict), f'{label}: object required')
    require(set(value) == expected, f'{label}: unexpected or missing fields')
    return value


def canonical_digest(value: Any) -> str:
    data = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')
    return hashlib.sha256(data).hexdigest()


def _no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        require(key not in result, 'JSON contains duplicate keys')
        result[key] = value
    return result


def _no_constant(value: str) -> None:
    raise Invalid('JSON contains non-finite numeric value')


def load(path: Path) -> Any:
    require(path.is_file(), 'Input file missing')
    require(path.stat().st_size <= MAX_BYTES, 'Input file exceeds bounded size')
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=_no_duplicates,
                      parse_constant=_no_constant)


def contained(root: Path, relative: Any) -> Path:
    name = text(relative, 'payload path')
    require('\x00' not in name and '\\' not in name, 'Invalid payload path characters')
    rel = Path(name)
    require(not rel.is_absolute() and not PureWindowsPath(name).drive and '..' not in rel.parts,
            'Payload path must be relative and contained')
    target = (root / rel).resolve()
    require(target.is_relative_to(root.resolve()), 'Payload symlink escaped evidence root')
    require(target.is_file(), 'Payload file missing')
    require(target.stat().st_size <= MAX_BYTES, 'Payload exceeds bounded size')
    return target


def timestamp(value: Any) -> datetime:
    raw = text(value, 'timestamp')
    try:
        result = datetime.fromisoformat(raw.replace('Z', '+00:00'))
    except ValueError as exc:
        raise Invalid('Invalid timestamp') from exc
    require(result.tzinfo is not None, 'Timestamp requires timezone')
    return result.astimezone(timezone.utc)


def subject(value: Any) -> None:
    keys(value, {'repo_id', 'commit', 'target'}, 'subject')
    text(value['repo_id'], 'repo_id')
    text(value['target'], 'target')
    require(isinstance(value['commit'], str) and bool(re.fullmatch(
        '(?:[0-9a-f]{40}|[0-9a-f]{64})', value['commit'])), 'Full subject commit required')


def check_contract(contract: dict[str, Any], trusted_sha256: str) -> dict[str, dict[str, Any]]:
    digest(trusted_sha256, 'externally pinned contract digest')
    require(canonical_digest(contract) == trusted_sha256, 'Acceptance contract digest mismatch')
    keys(contract, {'version', 'purpose', 'profile', 'subject', 'authority_ref', 'max_age_hours',
                    'required_layers', 'cells'}, 'contract')
    require(contract['version'] == '2.0', 'Unknown contract version')
    require(contract['purpose'] in {'demonstration', 'live_submission'}, 'Unknown purpose')
    require(contract['profile'] in {'runtime', 'role_specific'}, 'Unknown profile')
    subject(contract['subject'])
    text(contract['authority_ref'], 'authority reference')
    integer(contract['max_age_hours'], 'max_age_hours', 1)
    layers = unique(contract['required_layers'], 'required layers')
    require(layers <= LAYERS, 'Unknown required layer')
    if contract['profile'] == 'runtime':
        require({'unit', 'integration', 'e2e'} <= layers, 'Runtime profile requires three independent test layers')
    require(isinstance(contract['cells'], list) and bool(contract['cells']), 'Acceptance cells missing')
    cells: dict[str, dict[str, Any]] = {}
    coordinates: set[tuple[str, ...]] = set()
    for cell in contract['cells']:
        keys(cell, {'id', 'layer', 'metric', 'component', 'platform', 'build_profile',
                    'universe', 'critical', 'minimum_percent', 'obligation_source', 'check_ids'}, 'cell')
        cid = text(cell['id'], 'cell ID')
        require(cid not in cells, 'Duplicate cell ID')
        require(cell['layer'] in layers and cell['metric'] in METRICS, 'Unknown cell layer or metric')
        for field in ('component', 'platform', 'build_profile', 'obligation_source'):
            text(cell[field], field)
        coordinate = tuple(cell[x] for x in ('layer', 'metric', 'component', 'platform', 'build_profile'))
        require(coordinate not in coordinates, 'Duplicate measurement coordinate')
        coordinates.add(coordinate)
        universe = unique(cell['universe'], 'universe')
        critical = unique(cell['critical'], 'critical obligations', nonempty=False)
        require(critical <= universe, 'Critical obligations outside universe')
        threshold = integer(cell['minimum_percent'], 'minimum_percent', 85)
        require(threshold <= 100, 'Threshold exceeds 100')
        unique(cell['check_ids'], 'required check IDs')
        cells[cid] = cell
    require({x['layer'] for x in cells.values()} == layers, 'Required layer has no measurement cells')
    if contract['profile'] == 'runtime':
        for layer in ('unit', 'integration', 'e2e'):
            metrics = {c['metric'] for c in cells.values() if c['layer'] == layer}
            require({'line', 'branch', 'function', 'obligation'} <= metrics,
                    f'{layer}: runtime structural/behavioral measurement missing')
    return cells


def check_payload(payload: dict[str, Any], cell: dict[str, Any], contract: dict[str, Any],
                  now: datetime, contexts: dict[str, str]) -> dict[str, Any]:
    keys(payload, {'version', 'cell_id', 'subject', 'layer', 'metric', 'component', 'platform',
                   'build_profile', 'universe_sha256', 'mode', 'record_kind', 'context',
                   'created_at', 'producer', 'command', 'exit_code', 'result', 'covered',
                   'check_results', 'selected', 'executed', 'passed', 'failed', 'skipped',
                   'errors', 'flaky', 'suite_layers'}, 'payload')
    require(payload['version'] == '2.0' and payload['cell_id'] == cell['id'], 'Wrong payload identity')
    require(payload['subject'] == contract['subject'], 'Wrong repository/revision/target')
    for field in ('layer', 'metric', 'component', 'platform', 'build_profile'):
        require(payload[field] == cell[field], f'Wrong {field}')
    expected = canonical_digest(sorted(cell['universe']))
    require(payload['universe_sha256'] == expected, 'Denominator identity mismatch')
    require(payload['mode'] == 'measured', 'Mock/canned/inferred verdict is not measurement')
    allowed = {'measured'} if contract['purpose'] == 'live_submission' else {'synthetic_fixture'}
    require(payload['record_kind'] in allowed, 'Evidence kind incompatible with contract purpose')
    context = text(payload['context'], 'measurement context')
    require(context not in contexts or contexts[context] == cell['layer'], 'Cross-layer accumulator reused')
    contexts[context] = cell['layer']
    require(unique(payload['suite_layers'], 'suite layers') == {cell['layer']}, 'Mixed test layers cannot satisfy an independent layer')
    seen = timestamp(payload['created_at'])
    require(seen <= now + timedelta(minutes=5), 'Evidence timestamp is in the future')
    require(now - seen <= timedelta(hours=contract['max_age_hours']), 'Evidence has expired')
    text(payload['producer'], 'producer/version')
    command = payload['command']
    require(isinstance(command, list) and bool(command), 'Command argv missing')
    for arg in command:
        text(arg, 'command argument')
    require(integer(payload['exit_code'], 'exit_code') == 0 and payload['result'] == 'pass', 'Execution did not pass')
    for field in ('selected', 'executed', 'passed'):
        integer(payload[field], field, 1)
    for field in ('failed', 'skipped', 'errors', 'flaky'):
        require(integer(payload[field], field) == 0, f'{field}: unresolved non-passing execution')
    require(payload['selected'] == payload['executed'] == payload['passed'], 'Selected, executed and passed counts must agree')
    results = payload['check_results']
    require(isinstance(results, dict) and set(results) == set(cell['check_ids']), 'Required check set mismatch')
    require(all(v == 'pass' for v in results.values()), 'Required check did not pass')
    covered = unique(payload['covered'], 'covered IDs', nonempty=False)
    universe = set(cell['universe'])
    require(covered <= universe, 'Coverage outside denominator')
    require(set(cell['critical']) <= covered, 'Critical obligation is uncovered')
    require(100 * len(covered) >= cell['minimum_percent'] * len(universe), 'Coverage below independent floor')
    return {'id': cell['id'], 'layer': cell['layer'], 'metric': cell['metric'],
            'numerator': len(covered), 'denominator': len(universe),
            'percent': 100 * len(covered) / len(universe), 'required_percent': cell['minimum_percent']}


def evaluate(contract: dict[str, Any], report: dict[str, Any], root: Path,
             trusted_sha256: str, now: datetime | None = None) -> dict[str, Any]:
    cells = check_contract(contract, trusted_sha256)
    now = now or datetime.now(timezone.utc)
    require(now.tzinfo is not None, 'Evaluation clock must have timezone')
    keys(report, {'version', 'contract_sha256', 'subject', 'measurements'}, 'report')
    require(report['version'] == '2.0', 'Unknown report version')
    require(report['contract_sha256'] == trusted_sha256, 'Report bound to wrong contract')
    require(report['subject'] == contract['subject'], 'Report bound to wrong subject')
    require(isinstance(report['measurements'], list), 'Measurements must be a list')
    seen: set[str] = set()
    contexts: dict[str, str] = {}
    outcomes: list[dict[str, Any]] = []
    for receipt in report['measurements']:
        keys(receipt, {'cell_id', 'path', 'sha256'}, 'receipt')
        cid = text(receipt['cell_id'], 'receipt cell ID')
        require(cid in cells and cid not in seen, 'Unknown or duplicate measurement')
        seen.add(cid)
        digest(receipt['sha256'])
        path = contained(root, receipt['path'])
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == receipt['sha256'], 'Payload checksum mismatch')
        payload = json.loads(raw.decode('utf-8'), object_pairs_hook=_no_duplicates, parse_constant=_no_constant)
        outcomes.append(check_payload(payload, cells[cid], contract, now, contexts))
    require(seen == set(cells), 'Missing required measurement')
    return {'verdict': 'RECORDS_CONSISTENT', 'purpose': contract['purpose'],
            'lifecycle_approval': False, 'authenticated_producer': False,
            'contract_sha256': trusted_sha256, 'subject': contract['subject'],
            'cells': outcomes,
            'limits': ['Denominator completeness must be independently reviewed.',
                       'Normalized payloads require trusted native-report adapters.',
                       'Claims, execution, approvals and producer identity are not authenticated by this checker.']}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--evidence-root', type=Path, required=True)
    parser.add_argument('--contract-sha256', required=True, help='Canonical digest independently pinned by controller')
    args = parser.parse_args(argv)
    try:
        verdict = evaluate(load(args.contract), load(args.report), args.evidence_root,
                           args.contract_sha256)
        print(json.dumps(verdict, sort_keys=True))
        return 0
    except (Invalid, OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({'verdict': 'REJECTED', 'error': str(exc), 'lifecycle_approval': False}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
