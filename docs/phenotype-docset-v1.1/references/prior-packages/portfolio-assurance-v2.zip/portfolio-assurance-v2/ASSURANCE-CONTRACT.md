# Portfolio assurance contract v2.0

**Policy date:** September 9, 2026, America/Los_Angeles. **Role:** additive acceptance contract for the existing portfolio program. **Not:** a new product, a new universal database, a replacement for AgilePlus, or permission to mutate repositories. The latest human coverage directive governs the floor. Existing stronger accepted policies remain in force.

## 1. Parent mission and bounded acceptance

The outcome remains evidence-backed polyrepo shaping, approved absorption/decomposition/integration/retention, and then a usable, stable, demonstrated bounded target. A capability moved to a new folder is not integrated; a PR is not a release; a named tool invocation is not verified adoption. Keep source, target and consumers in a joint acceptance map. Preserve exact human intent and research horizons even when delivery is incremental.

Use separate status for work package, PR, integration, bounded release, migration/consumer adoption, and portfolio disposition. A worker may complete one repair and continue with the next authorized work package. A true external blocker must retain an ID, owner, next action and wakeup condition. Originating on main does not make a required defect somebody else’s responsibility.

## 2. Independent coverage floors

For a runtime/product target, each of **unit, integration and E2E** must independently meet at least 85% of its accepted structural and behavioral obligations. The structural measures are executable lines, branches/decisions, and functions where supported by the selected instrumentation. Behavioral coverage tracks specified obligations with meaningful oracles. None substitutes for another.

The acceptance coordinate is:

`target × capability/component × language × platform × build/feature profile × test family × metric`.

The support matrix defines the required cells. Every required cell is evaluated independently. Aggregates are useful for navigation but cannot hide a low-performing component, platform, family or metric. A merged 98% line report cannot offset integration branch coverage of 62%. A library-only run cannot establish a packaged GUI, CLI, service, FFI or mobile path.

For cell k:

`coverage(k) = unique evidenced items(k) / unique approved eligible items(k)`.

Evaluate the integer counts without rounding the result upward. Freeze the denominator before evaluating the numerator. Inventory eligible zero-hit files, functions, edges and scenarios as well as those discovered by execution. A denominator inferred from observed successes is invalid.

The minimum is `max(85%, existing accepted stricter floor)`. Aim beyond the minimum where risk and maintainability justify it; 90–95% is a useful planning band, not a replacement floor. All finite enumerated critical obligations must be covered. Newly changed critical logic must receive direct tests and failure controls even when aggregate statistics already exceed the minimum.

### Structural and behavioral boundaries

Unit tests exercise bounded logic with controlled dependencies. Integration tests exercise real component boundaries, protocols, storage or process interactions. E2E exercises the packaged public workflow through its real entrypoint and the relevant deployable components. A subprocess smoke test is E2E only for the bounded CLI behavior it actually covers; it does not become an E2E proof of unrelated product capabilities.

The same code may legitimately be exercised in several families. Each family must independently produce its report. Shared test data and fixture setup are allowed. Relabelling one execution three times, combining accumulators across families, or treating mocked internal behavior as an actual integration is not allowed.

### Inapplicability and unsupported measurement

An inapplicable family requires a reviewed role/architecture rationale and replacement evidence obligations where appropriate. A metric unsupported by a native tool is **MEASUREMENT_BLOCKED**, not N/A or 100%. Use another instrument, an approved explicit proxy, or an authorized exception. Do not advertise proxy coverage as native branch/function coverage. The worker may propose scope or instrumentation changes but cannot lower a floor or remove a denominator item to pass.

A native branch count of zero may legitimately mean no branch opportunities in a tiny function. Show the underlying eligible-item list and the reviewed applicability result. Do not treat `0/0` as a success percentage. A missing denominator is UNKNOWN.

## 3. Coverage is not a passing-test quota

All mandatory selected tests/checks must execute and pass. Known failures, skips, timeouts, collection errors, crashes, empty selections and quarantined flakes do not count as passes. A passing retry is recorded with the failed attempt and does not erase instability. Rerun only under a declared policy; report first-attempt outcomes and failure rate as well as final result.

The obligation inventory can contain uncovered noncritical items within the permitted numeric gap, but a known broken required capability remains a blocker. Every remaining uncovered item is visible and has a disposition. Security, correctness, privacy, data integrity and release invariants are never relaxed merely because the chosen numeric floor is 85%.

Separate four facts: **instrumented execution**, **asserted behavior**, **oracle sensitivity**, and **observed user outcome**. Line hits establish only the first. Mutation/negative controls support the third. Pilots/case studies support the fourth. None is a complete proof of arbitrary correctness.

## 4. QA, QC and QE as independently evidenced disciplines

For this program, QA means preventive process/quality planning; QC means evaluating concrete artifacts; QE means building and verifying the engineering machinery that enables quality. These are operational definitions, not a claim of one universal industry taxonomy.

Every applicable discipline gets a reviewed obligation inventory and independent breadth coverage of at least 85%. Every mandatory control in that inventory must be satisfied. Examples include spec/ADR discipline, review completeness, test-run selection, deterministic fixtures, seeded defects, dependency/supply-chain policy, release provenance, performance instrumentation, branch protection behavior and recovery drills.

Fuzzing and model checking do not have a finite “all inputs” denominator. Record finite target/hazard/grammar/state coverage, resource/time budgets, seeds, corpus and crash triage. Property testing needs declared properties, boundaries and counterexamples. Mutation adequacy uses unique eligible non-equivalent mutant IDs; invalid mutants and infrastructure failures are separate statuses. A timeout is not automatically a killed mutant unless a reliable oracle and run policy support that classification. Equivalent mutants need evidence and review, not bulk dismissal of survivors.

## 5. Critical obligations and hard vetoes

At least these require complete evidence within the accepted target: authorization/isolation boundaries; protection of secrets and private source material; data-loss prevention; externally promised backward compatibility or accepted migration handling; required public interfaces and installation paths; required check execution; custody and rollback; current operator constraints; and terminal lifecycle actions.

No unresolved high/critical security finding may silently pass. A reviewed risk acceptance or bounded release exception remains a visible exception, not CLEAN or full conformance. Severity, exploitability, reachability and compensating controls are recorded separately; a transitive dependency advisory must be investigated rather than guessed to be a one-line fix.

Mandatory floors, invariant checks, required platform builds and actual release-artifact checks are conjunctive. They cannot be traded against a high average score.

## 6. Documentation assurance

Every applicable artifact class must exist with substantive target-specific content or an accepted N/A rationale: intent, charter/PRD, FR/NFR/system contracts, architecture HLD/ALD/LLD, ADRs, APIs/schemas, work/WBS/DAG/PERT, research/SOTA, threat/risk model, test/acceptance plan, installation/operations/recovery, migration/consumers and pilot/case-study material.

Assess content over the approved capability/contract/journey inventory, not file count or word count. Report each applicable artifact family separately: strong specifications cannot compensate for missing operations, architecture, intent or SOTA coverage. Within each family, apply the independent content floor and complete all mandatory/critical obligations. All critical/publicly promised contracts, major decisions and mandatory user journeys need complete documentation and executable examples where appropriate. Broader noncritical topic coverage must independently reach at least 85%. A file labelled SPEC is not evidence that its contents describe implemented behavior accurately.

Every in-scope requirement needs provenance, scope, an owner, acceptance criteria, verification method and current status. Maintain both directions: requirements with no implementation/evidence and implemented public behavior with no contract. Every significant change must reconcile affected documents and invalidated evidence. Generated metadata cannot silently become another editable authority.

Mandatory examples/quickstarts must run against the claimed version in a clean consumer context. Distinguish runnable examples, illustrative pseudocode and speculative API designs. Build the documentation site, verify internal paths/anchors, navigation, search, language/version labels, diagrams, media, accessibility and private/public publication boundaries. An unavailable external URL check is UNKNOWN or a policy-governed transient error, not a fabricated pass.

## 7. Actual toolchain adoption

Use the real versions and contracts of PhenoDocs, AgilePlus, phenotype-journeys, Benchora and other applicable local tools. Record tool identity, binary/package version or source commit, command/API capabilities, input identity, outputs, exit behavior, negative controls and source-to-consumer integration evidence.

Do not infer functioning tool adoption from README mentions or manifests. The inspected sources contain no-op/fail-open paths; see [source findings](docs/tooling/SOURCE-FINDINGS.md). Until repaired and reproduced, these paths are not acceptable authorities for the affected verdicts. Use independently qualified native reports through a narrow adapter where authorized; do not block every useful product until an entire platform is rebuilt.

AgilePlus’s inspected repository-state contract stores mutable state under the subject repository’s `.agileplus/` and materializes review artifacts under `docs/agileplus/`. Verify the installed/deployed contract and actual session root before use. Query real MCP/engine state when state is required; a generated status file does not prove an engine transition. Do not edit materialized projections as the authoritative state. Keep the SQLite database and runtime locks out of ordinary Git commits. Preserve reviewed import ownership and audit evidence during migration.

PhenoDocs is a federation/publication layer, not a replacement authority for every product’s source documentation. Demonstrate version-pinned ingestion, correct source links, rendered navigation/search, real link checks and visibility filtering. A private source must not leak through a public static bundle, search index, embedded artifact or LLM index.

## 8. Intent acquisition and SOTA

Preserve available exact human wording separately from normalized text, redacted publication and LLM synthesis. Acquire relevant authorized session records across named devices/tools as needed; do not enumerate arbitrary private histories or guess unavailable wording. Capture source IDs, session/turn, parser version, observed time, source timestamp confidence, repository context, source digests, redaction and extraction errors. Short corrections without a repository name remain meaningful through session context. Track missing/unreadable sources honestly.

SOTA is source-backed, dimensional and current. Retain the existing technical/DX/UX/AX/security/ops/cost framework and add applicable accessibility, interoperability, maintainability, resource/energy, resilience, distribution and licensing dimensions. A minimum 25-candidate category search applies where required and relevant; at least three serious alternatives per applicable dimension can be drawn from that category corpus. Shared research avoids repeating an identical longlist in 146 repos. No invented maximum, fake competitors or padded variants.

Record proposed versus observed advantages. Every material claim points to dated/versioned evidence; vendor claims are labelled. Prefer primary sources for technical assertions. Reopen research when contracts, dependencies, costs, new alternatives or pilot results materially change. “Optimal” is bounded by stated users, constraints and evidence—not an unqualified global assertion.

## 9. Pilots, case studies and the user-facing result

Design pilots during planning; execute them against a stable bounded slice. Compare the nearest rational alternatives, including direct/manual/no-framework or composed workflows. A case study must demonstrate an outcome a real intended user can accomplish, not just installation and a screenshot.

Predeclare jobs, baseline versions, acceptance oracle, mandatory invariants, non-inferiority margins, material superiority effects, budgets and stopping criteria. Match models, prompts/tool contracts where the experimental question calls for them, hardware, network, caches, retry policy and task difficulty. Use separate fairness-controlled and idiomatic-best-practice tracks when their goals differ. Preserve failures, confidence intervals, nondeterminism, measurement exclusions and negative cases.

For an Agentora coding-agent pilot, begin with a reproducible bounded repo task: inspect, patch, run tests, handle tool failure, preserve approval boundaries and report a result. Compare against pinned OpenAI Agents SDK, LangGraph/LangChain, CrewAI and a direct SDK implementation when they fit the job. Measure task correctness and completion first; then implementation burden, API/concept complexity, latency, memory, concurrency, recovery, provenance and maintenance. Native Rust versus Python results are whole-stack results unless a design isolates framework overhead. Do not attribute the language/runtime difference entirely to the framework.

Qualitative ease-of-use, architectural fitness, brand and accessibility judgments need calibrated rubrics or human evidence. An LLM judge is an assistant to evaluation, not the sole trusted oracle. No canned scores, mock results or default-true fallback may support acceptance.

## 10. Role and stage profiles

G0 recovers role, scope and evidence. G1 closes applicable pre-implementation artifacts and the verification/pilot plan, not claimed runtime behavior. G2 qualifies meaningful red oracles and pipeline failure propagation. G3 requires independently measured implementation and contract coverage for the bounded target. G4 requires the comparative pilot and a justified result. G5 requires usable packaging/operations and required integrations. G6 requires accepted topology, consumers and lifecycle disposition.

A narrow emergency/security repair need not wait for every G1–G6 issue in the entire product. Follow existing authorized merge/release policies and mandatory checks; record remaining target gaps. Never relabel the repository as fully compliant because the repair was useful.

For an archived/reference source, verify preservation, role truth, provenance, consumers, attribution and authorization; do not modernize dead code merely to reach runtime coverage. For a migration, every source capability and retained obligation receives a disposition; required parity, compatibility, custody and rollback are fully evidenced. For an incubator, prove the agreed experiment and graduation/absorption/stop decision rather than claiming production maturity.

## 11. Authority, exceptions and evidence freshness

Current explicit operator permissions override old audit-only defaults only for the actions actually granted. This contract does not enlarge write leases, approve merges, archive repositories, publish packages, alter security gates or collect private data outside authorized scope.

An exception records metric/obligation, exact scope, why measurement or compliance is blocked, rejected alternatives, risk, compensating checks, authorized issuer, expiry, repair work package and recheck trigger. Workers cannot self-approve metric removal. An excepted release remains labelled as excepted. Preserve absolute and ratcheted floors; showing improvement from 20% to 70% is progress, not 85% compliance.

Evidence is bound to repository identity, immutable source revision, artifact, dependency/configuration/toolchain/profile, suite selection and timestamp. Content changes invalidate the relevant evidence by impact analysis. Never reuse a unit report as E2E evidence. Reuse valid prior evidence rather than rerun expensive stable tests blindly; state the exact reuse basis. Run complete required acceptance at the final accepted integration/release baseline or through the approved merge-queue contract.

## 12. Scheduling, closure and tools that verify tools

Plan around the smallest useful target, not isolated cosmetic changes. Repair inherited local blockers in narrow follow-on PRs. Coordinate shared-tool defects with the owning worker; callers can prepare consumer-side fail-closed adapters without stealing another repo’s lease. Distinguish hard prerequisites, priority, resource exclusions and external authority blockers.

Reserve resources for foreground gaming, audio and interactive work. Measure uninstrumented performance separately from heavily instrumented tests. Schedule GPU, physical-device, emulator, exclusive-port and audio tests under leases; cap build concurrency, RAM and I/O. A local maximum of three repos per worker is not permission to overload the whole fleet.

Before trusting a checker, demonstrate seeded failure, wrong revision, missing artifact, empty selection, mixed suite, stale context, malformed report, and failure-propagation tests. A valid JSON document or matching checksum is not proof that the producer honestly measured anything. The supplied reference checker intentionally returns RECORDS_CONSISTENT rather than APPROVED. Authenticate producer and reviewer identities and inspect the domain oracle in the actual trusted pipeline.

## 13. Immediate worker response

Return a compact per-repository matrix: accepted role/target; source and installed tooling versions; unit/integration/E2E structural and behavioral counts; other applicable assurance families; critical obligations; docs/intent/SOTA/pilot coverage; actual tool integrations; inherited blockers; evidence IDs; owner and next executable task. Report UNKNOWN/BLOCKED honestly. Preserve current PRs and do a delta closure pass, not another indiscriminate documentation regeneration.
