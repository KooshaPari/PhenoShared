# Targeted assurance work packages

Generated from [WORK-PACKAGES.json](WORK-PACKAGES.json). Owner roles are proposed, not claimed or assigned. All tasks are planned; source findings are static and reference tests do not complete these native repairs.

**Important:** specialize the graph by actual consumers and required integrations. AS-15 is a roll-up; a consumer of only PhenoDocs does not wait for Benchora. No global all-tools barrier. Estimates are intentionally unset pending bounded native reproduction.

| ID | Work | Proposed owner | Hard prerequisites | Acceptance |
|---|---|---|---|---|
| AS-01 | Reconcile accepted target, floor and scope | coordinator | None | Per-target acceptance matrix and independently reviewed denominator; no new portfolio audit |
| AS-02 | Qualify AgilePlus FR coverage job | AgilePlus owner | AS-01 | Actual FR inventory/evidence check, seeded missing-FR rejection and CI failure propagation |
| AS-03 | Replace PhenoDocs stub link check | phenodocs owner | AS-01 | Real links/anchors/media/privacy checks, known-bad docs fixture rejected |
| AS-04 | Repair journey semantic verdict derivation | phenotype-journeys owner | AS-01 | Live response parsed and validated; mock/error/absent evidence never accepted |
| AS-05 | Fail closed on journey assertion-engine errors | phenotype-journeys owner | AS-01 | Missing/error/zero-assertion required path fails process and consumer gate |
| AS-06 | Qualify Benchora native-denominator/mutation accounting | Benchora owner | AS-01 | Native denominator fixture parity; duplicate mutation transitions cannot inflate score |
| AS-07 | Qualify exact intent extraction and acquisition ledger | actual intent-tool owner | AS-01 | Raw/normalized/redacted separation, timestamps and errors, short-followup fixtures |
| AS-08 | Implement per-language independent coverage adapters | existing quality-tool owner | AS-01 | Suite-isolated native reports, complete eligible source map and malformed-report negatives |
| AS-09 | Measure target unit/integration/E2E baseline | assigned repository worker | AS-08 | Independent per-cell baseline including unknowns, zero-hit items, critical obligations and exact artifact IDs |
| AS-10 | Close under-covered and weak-oracle capability slices | assigned repository worker | AS-09 | Useful narrow implementations/tests with positive/negative acceptance; all target floors satisfied or owned blockers |
| AS-11 | Qualify PhenoDocs consumer federation | source-doc and phenodocs owners | AS-03 | Versioned rendered docs/search and private-public isolation; required examples execute |
| AS-12 | Bind real AgilePlus state and evidence transitions | assigned repo and AgilePlus owners | AS-01 | Correct repo/session root, real engine query/receipt, generated artifacts not hand-approved |
| AS-13 | Refresh category SOTA and product-specific hypotheses | family research owner | AS-01 | Dated 25-candidate category breadth where applicable, dimensional alternatives and experiment protocol |
| AS-14 | Run bounded comparative pilot and case study | pilot worker/verifier | AS-10, AS-13 | Actual matched/idiomatic runs with raw failures, uncertainty and user outcome; no fixed score |
| AS-15 | Requalify affected toolkit consumers | affected consumer owners | AS-02, AS-03, AS-04, AS-05, AS-06 | Only affected verdicts revalidated with repaired tools; independent unrelated work preserved |
| AS-16 | Run final target support/release/operations gates | target verifier | AS-10 | Clean install, platform/consumer support, recovery, critical invariants and immutable independent metrics |
| AS-17 | Accept bounded target and maintain residual portfolio work | authorized acceptance owner | AS-11, AS-12, AS-14, AS-16 | Conjunctive acceptance or explicit blocked/excepted state; parent migration/lifecycle ownership retained |

Migration, incubation and reference outcomes retain their actual accepted profile. Do not revive a donor to satisfy a runtime measurement template. Use AgilePlus’s deployed state APIs; this JSON is a plan projection, not engine state.
