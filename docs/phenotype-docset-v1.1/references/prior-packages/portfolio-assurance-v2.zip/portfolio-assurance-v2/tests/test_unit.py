from __future__ import annotations
import copy
import unittest
from datetime import datetime, timezone
from reference import assurance as a
from tests.support import fixture, invalid_cases, sha

class PrimitiveTests(unittest.TestCase):
    def test_hash_and_scalar_contracts(self):
        self.assertEqual(a.canonical_digest({'b':2,'a':1}), a.canonical_digest({'a':1,'b':2}))
        self.assertEqual(a.text('x','x'),'x'); self.assertEqual(a.integer(1,'x'),1)
        self.assertEqual(a.digest('a'*64),'a'*64)
        self.assertEqual(a.unique([], 'ids', False),set())
        self.assertEqual(a._no_duplicates([('a',1)]),{'a':1})
        self.assertIsNotNone(a.timestamp('2026-09-09T00:00:00Z').tzinfo)
        for fn,args in [(a.text,('', 'x')), (a.integer,(True,'x')), (a.digest,('A'*64,)),
                        (a.unique,('not-list','x')), (a.unique,([1],'x')), (a.keys,([],set(),'x')),
                        (a.keys,({'x':1},set(),'x')), (a._no_duplicates,([('a',1),('a',2)],)),
                        (a._no_constant,('NaN',)), (a.timestamp,('wrong',)), (a.timestamp,('2026-01-01',))]:
            with self.subTest(fn=fn.__name__,args=args),self.assertRaises(a.Invalid):fn(*args)
    def test_subject_formats(self):
        a.subject({'repo_id':'repo:1','commit':'f'*64,'target':'v1'})
        with self.assertRaises(a.Invalid): a.subject({'repo_id':'','commit':'a'*40,'target':'v1'})
        with self.assertRaises(a.Invalid): a.subject({'repo_id':'r','commit':'short','target':'v1'})
    def test_contract_digest_is_external(self):
        c,_=fixture()
        with self.assertRaises(a.Invalid): a.check_contract(c,'0'*64)
    def test_role_specific_contract(self):
        c,p=fixture(); c['profile']='role_specific'; c['required_layers']=['unit'];c['cells']=c['cells'][:4]
        self.assertEqual(len(a.check_contract(c,sha(c))),4)
    def test_payload_positive_and_exact_floor(self):
        c,p=fixture();p[0]['covered']=p[0]['covered'][:85]
        result=a.check_payload(p[0],c['cells'][0],c,datetime.now(timezone.utc),{})
        self.assertEqual(result['percent'],85);self.assertEqual(result['denominator'],100)
    def test_live_record_is_not_fixture(self):
        c,p=fixture(); c['purpose']='live_submission';p[0]['record_kind']='measured'
        self.assertEqual(a.check_payload(p[0],c['cells'][0],c,datetime.now(timezone.utc),{})['numerator'],90)
    def test_independent_negative_vectors(self):
        for name,c,p in invalid_cases():
            with self.subTest(case=name),self.assertRaises((a.Invalid,ValueError,TypeError)):
                cells=a.check_contract(c,sha(c));contexts={}
                for item in p:
                    self.assertIn(item['cell_id'],cells) if item['cell_id'] in cells else a.require(False,'unknown cell')
                    a.check_payload(item,cells[item['cell_id']],c,datetime.now(timezone.utc),contexts)
    def test_payload_empty_covered_never_vacuously_passes(self):
        c,p=fixture();p[0]['covered']=[]
        with self.assertRaises(a.Invalid): a.check_payload(p[0],c['cells'][0],c,datetime.now(timezone.utc),{})
    def test_missing_contract_field(self):
        c,p=fixture();del c['subject']
        with self.assertRaises(a.Invalid):a.check_contract(c,sha(c))


class MockedBoundaryTests(unittest.TestCase):
    """Unit tests of orchestration with filesystem/execution boundaries replaced."""
    def test_evaluate_routing_with_mocked_io(self):
        import hashlib,json
        from pathlib import Path
        from unittest.mock import patch,Mock
        c,p=fixture();rows=[];payload_by_path={}
        for index,item in enumerate(p):
            raw=json.dumps(item).encode();name=f'p{index}.json'
            payload_by_path[name]=Mock(read_bytes=Mock(return_value=raw))
            rows.append({'cell_id':item['cell_id'],'path':name,'sha256':hashlib.sha256(raw).hexdigest()})
        r={'version':'2.0','contract_sha256':sha(c),'subject':c['subject'],'measurements':rows}
        with patch.object(a,'contained',side_effect=lambda root,name:payload_by_path[name]):
            self.assertFalse(a.evaluate(c,r,Path('/dummy'),sha(c))['lifecycle_approval'])
            for case in ('missing','duplicate','unknown','hash','subject','version','measurements','clock'):
                candidate=copy.deepcopy(r);now=None
                if case=='missing':candidate['measurements'].pop()
                if case=='duplicate':candidate['measurements'].append(candidate['measurements'][0])
                if case=='unknown':candidate['measurements'][0]['cell_id']='unknown'
                if case=='hash':candidate['measurements'][0]['sha256']='0'*64
                if case=='subject':candidate['subject']['target']='other'
                if case=='version':candidate['version']='wrong'
                if case=='measurements':candidate['measurements']={}
                if case=='clock':now=datetime(2026,9,9)
                with self.subTest(case=case),self.assertRaises(a.Invalid):a.evaluate(c,candidate,Path('/dummy'),sha(c),now)
    def test_load_with_fake_file(self):
        from unittest.mock import Mock
        path=Mock();path.is_file.return_value=True;path.stat.return_value.st_size=10;path.read_text.return_value='{"a":1}'
        self.assertEqual(a.load(path),{'a':1})
        path.read_text.return_value='{"a":1,"a":2}'
        with self.assertRaises(a.Invalid):a.load(path)
        path.read_text.return_value='{"a":NaN}'
        with self.assertRaises(a.Invalid):a.load(path)
        path.stat.return_value.st_size=a.MAX_BYTES+1
        with self.assertRaises(a.Invalid):a.load(path)
        path.is_file.return_value=False
        with self.assertRaises(a.Invalid):a.load(path)
    def test_path_policy_with_fake_filesystem(self):
        from pathlib import Path
        from types import SimpleNamespace
        from unittest.mock import patch
        for name in ('../out','/root/out','C:/out','a\\b','a\x00b','missing'):
            with self.subTest(name=name),self.assertRaises(a.Invalid):a.contained(Path('/evidence'),name)
        with patch.object(Path,'resolve',lambda self:self),patch.object(Path,'is_file',return_value=True),patch.object(Path,'stat',return_value=SimpleNamespace(st_size=3)):
            self.assertEqual(a.contained(Path('/evidence'),'record.json'),Path('/evidence/record.json'))
        with patch.object(Path,'resolve',lambda self:self),patch.object(Path,'is_file',return_value=True),patch.object(Path,'stat',return_value=SimpleNamespace(st_size=a.MAX_BYTES+1)):
            with self.assertRaises(a.Invalid):a.contained(Path('/evidence'),'record.json')
    def test_main_with_fake_adapters(self):
        from unittest.mock import patch
        args=['--contract','c.json','--report','r.json','--evidence-root','.', '--contract-sha256','a'*64]
        with patch.object(a,'load',return_value={}),patch.object(a,'evaluate',return_value={'lifecycle_approval':False}),patch('sys.stdout'):
            self.assertEqual(a.main(args),0)
        with patch.object(a,'load',side_effect=a.Invalid('bad')),patch('sys.stderr'):
            self.assertEqual(a.main(args),2)

if __name__=='__main__':unittest.main()
