"""Tests of the assurance reference using synthetic records."""
