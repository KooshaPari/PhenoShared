from __future__ import annotations
import hashlib
import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from reference import assurance as a
from tests.support import fixture, invalid_cases, write_bundle

class EvidenceIntegration(unittest.TestCase):
    def test_positive_snapshot(self):
        with tempfile.TemporaryDirectory() as d:
            c,r,h=write_bundle(Path(d));result=a.evaluate(a.load(Path(d)/'contract.json'),a.load(Path(d)/'report.json'),Path(d),h)
            self.assertEqual(result['verdict'],'RECORDS_CONSISTENT');self.assertFalse(result['lifecycle_approval']);self.assertFalse(result['authenticated_producer'])
    def test_all_semantic_negative_vectors(self):
        for name,c,p in invalid_cases():
            with self.subTest(case=name),tempfile.TemporaryDirectory() as d:
                c,r,h=write_bundle(Path(d),c,p)
                with self.assertRaises((a.Invalid,ValueError,TypeError)):a.evaluate(c,r,Path(d),h)
    def test_receipt_and_report_failures(self):
        for case in ('missing','duplicate','unknown','bad-digest','tamper','wrong-report','wrong-subject','bad-version','not-list','receipt-extra','wrong-clock'):
            with self.subTest(case=case),tempfile.TemporaryDirectory() as d:
                root=Path(d);c,r,h=write_bundle(root);now=None
                if case=='missing':r['measurements'].pop()
                if case=='duplicate':r['measurements'].append(dict(r['measurements'][0]))
                if case=='unknown':r['measurements'][0]['cell_id']='absent'
                if case=='bad-digest':r['measurements'][0]['sha256']='not-hash'
                if case=='tamper':(root/r['measurements'][0]['path']).write_text('{}')
                if case=='wrong-report':r['contract_sha256']='0'*64
                if case=='wrong-subject':r['subject']['target']='different'
                if case=='bad-version':r['version']='x'
                if case=='not-list':r['measurements']={}
                if case=='receipt-extra':r['measurements'][0]['extra']=True
                if case=='wrong-clock':now=datetime(2026,9,9)
                with self.assertRaises(a.Invalid):a.evaluate(c,r,root,h,now)
    def test_containment_and_missing(self):
        for path in ('../outside','/etc/passwd','C:/outside','C:\\outside','a\x00b','notthere'):
            with self.subTest(path=path),tempfile.TemporaryDirectory() as d:
                with self.assertRaises(a.Invalid):a.contained(Path(d),path)
        with tempfile.TemporaryDirectory() as d,tempfile.TemporaryDirectory() as other:
            root=Path(d);outside=Path(other)/'x';outside.write_text('x');(root/'link').symlink_to(outside)
            with self.assertRaises(a.Invalid):a.contained(root,'link')
    def test_json_and_limits(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for idx,raw in enumerate((b'{"x":1,"x":2}',b'{"x":NaN}',b'{bad',b'\xff')):
                path=root/f'bad{idx}';path.write_bytes(raw)
                with self.assertRaises((a.Invalid,ValueError,UnicodeError)):a.load(path)
            with self.assertRaises(a.Invalid):a.load(root/'missing')
            (root/'big').write_text('1234567890')
            with patch.object(a,'MAX_BYTES',4):
                with self.assertRaises(a.Invalid):a.load(root/'big')
                with self.assertRaises(a.Invalid):a.contained(root,'big')
    def test_cli_function_exit_not_approval(self):
        # An in-process entrypoint integration test, not an E2E claim.
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);c,r,h=write_bundle(root)
            with patch('sys.stdout'),patch('sys.stderr'):
                args=['--contract',str(root/'contract.json'),'--report',str(root/'report.json'),'--evidence-root',d,'--contract-sha256',h]
                self.assertEqual(a.main(args),0)
                self.assertEqual(a.main(args[:-1]+['0'*64]),2)

if __name__=='__main__':unittest.main()
