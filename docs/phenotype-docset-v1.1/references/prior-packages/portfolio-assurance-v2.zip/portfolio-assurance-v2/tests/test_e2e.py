"""Real subprocess/CLI tests of the reference checker, using synthetic evidence only."""
from __future__ import annotations
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from tests.support import fixture, invalid_cases, write_bundle

ROOT=Path(__file__).resolve().parents[1]

def command():
    if os.environ.get('ASSURANCE_MEASURE_E2E')=='1':
        return [sys.executable,'-S','-m','coverage','run','--parallel-mode','--branch','--source=reference',str(ROOT/'reference/assurance.py')]
    return [sys.executable,'-S',str(ROOT/'reference/assurance.py')]

def invoke(root,h,extra=None):
    args=['--contract',str(root/'contract.json'),'--report',str(root/'report.json'),'--evidence-root',str(root),'--contract-sha256',h]
    return subprocess.run(command()+args+(extra or []),cwd=ROOT,text=True,capture_output=True,timeout=15)

class CLIAcceptance(unittest.TestCase):
    def test_valid_cli_is_consistency_not_approval(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);_,_,h=write_bundle(root);out=invoke(root,h)
            self.assertEqual(out.returncode,0,out.stderr)
            result=json.loads(out.stdout);self.assertEqual(result['verdict'],'RECORDS_CONSISTENT')
            self.assertFalse(result['lifecycle_approval']);self.assertFalse(result['authenticated_producer'])
            self.assertEqual(len(result['cells']),12);self.assertEqual(result['purpose'],'demonstration')
    def test_every_negative_vector_fails_process(self):
        for name,c,p in invalid_cases():
            with self.subTest(case=name),tempfile.TemporaryDirectory() as d:
                root=Path(d);_,_,h=write_bundle(root,c,p);out=invoke(root,h)
                self.assertEqual(out.returncode,2,out.stdout+out.stderr)
                self.assertEqual(json.loads(out.stderr)['verdict'],'REJECTED')
    def test_transport_integrity_failures(self):
        for case in ('contract-hash','missing-payload','tampered','bad-json','dup-json','nan-json','utf8',
                     'missing-report','extra-receipt','missing-cell','dup-cell','unknown-cell','wrong-report','report-subject','report-version','not-list',
                     'path-traversal','absolute','windows','backslash','nul','symlink','too-large','payload-too-large','bad-digest'):
            with self.subTest(case=case),tempfile.TemporaryDirectory() as d,tempfile.TemporaryDirectory() as other:
                root=Path(d);c,r,h=write_bundle(root);receipt=r['measurements'][0];path=root/receipt['path']
                if case=='contract-hash':h='0'*64
                if case=='missing-payload':path.unlink()
                if case=='tampered':path.write_text('{}')
                if case in ('bad-json','dup-json','nan-json','utf8'):
                    raw={'bad-json':b'{bad','dup-json':b'{"x":1,"x":2}','nan-json':b'{"x":NaN}','utf8':b'\xff'}[case]
                    path.write_bytes(raw);receipt['sha256']=hashlib.sha256(raw).hexdigest()
                if case=='extra-receipt':receipt['extra']=True
                if case=='missing-cell':r['measurements'].pop()
                if case=='dup-cell':r['measurements'].append(dict(receipt))
                if case=='unknown-cell':receipt['cell_id']='absent'
                if case=='wrong-report':r['contract_sha256']='0'*64
                if case=='report-subject':r['subject']['target']='other'
                if case=='report-version':r['version']='x'
                if case=='not-list':r['measurements']={}
                badpaths={'path-traversal':'../elsewhere','absolute':'/etc/passwd','windows':'C:/outside','backslash':'folder\\outside','nul':'a\x00b'}
                if case in badpaths:receipt['path']=badpaths[case]
                if case=='symlink':
                    target=Path(other)/'external';target.write_text('{}');(root/'escape').symlink_to(target);receipt['path']='escape'
                if case=='bad-digest':receipt['sha256']='x'
                if case=='payload-too-large':
                    with path.open('wb') as f:f.truncate(32*1024*1024+1)
                (root/'report.json').write_text(json.dumps(r))
                if case=='missing-report':(root/'report.json').unlink()
                if case=='too-large':
                    with (root/'report.json').open('wb') as f:f.truncate(32*1024*1024+1)
                out=invoke(root,h)
                self.assertEqual(out.returncode,2,out.stdout+out.stderr)
    def test_help_and_missing_arguments(self):
        out=subprocess.run(command()+['--help'],cwd=ROOT,text=True,capture_output=True,timeout=15)
        self.assertEqual(out.returncode,0);self.assertIn('--contract-sha256',out.stdout)
        out=subprocess.run(command(),cwd=ROOT,text=True,capture_output=True,timeout=15)
        self.assertEqual(out.returncode,2)
    def test_role_specific_and_live_record_shapes(self):
        for role in ('role_specific','runtime'):
            with self.subTest(role=role),tempfile.TemporaryDirectory() as d:
                c,p=fixture();c['profile']=role
                if role=='role_specific':c['required_layers']=['unit'];c['cells']=c['cells'][:4];p=p[:4]
                else:c['purpose']='live_submission';[x.update(record_kind='measured') for x in p]
                root=Path(d);_,_,h=write_bundle(root,c,p);out=invoke(root,h)
                self.assertEqual(out.returncode,0,out.stderr)
                # This proves accepted record shapes, NOT authentication of an actual live run.
                self.assertFalse(json.loads(out.stdout)['authenticated_producer'])

if __name__=='__main__':unittest.main()
