"""Synthetic fixture builder. No fixtures represent a real repository test run."""
from __future__ import annotations
import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def fixture():
    subject = {'repo_id': 'fixture://assurance-reference', 'commit': 'a' * 40, 'target': 'synthetic-demo'}
    cells = []
    for layer in ('unit', 'integration', 'e2e'):
        for metric in ('line', 'branch', 'function', 'obligation'):
            cid = f'{layer}-{metric}'
            cells.append({'id': cid, 'layer': layer, 'metric': metric, 'component': 'demo-core',
                          'platform': 'fixture-platform', 'build_profile': 'fixture-profile',
                          'universe': [f'{metric}-{n:03}' for n in range(100)],
                          'critical': [f'{metric}-{n:03}' for n in range(10)],
                          'minimum_percent': 85, 'obligation_source': 'fixture://predeclared-inventory',
                          'check_ids': ['positive-case', 'negative-control']})
    contract = {'version': '2.0', 'purpose': 'demonstration', 'profile': 'runtime', 'subject': subject,
                'authority_ref': 'fixture://NOT-AN-APPROVAL', 'max_age_hours': 24,
                'required_layers': ['unit', 'integration', 'e2e'], 'cells': cells}
    payloads = []
    for cell in cells:
        payloads.append({'version': '2.0', 'cell_id': cell['id'], 'subject': copy.deepcopy(subject),
                         **{key: cell[key] for key in ('layer', 'metric', 'component', 'platform', 'build_profile')},
                         'universe_sha256': sha(sorted(cell['universe'])), 'mode': 'measured',
                         'record_kind': 'synthetic_fixture', 'context': f"fixture-{cell['layer']}",
                         'created_at': datetime.now(timezone.utc).isoformat(),
                         'producer': 'synthetic-fixture-generator/1', 'command': ['fixture-only', '--not-a-product-run'],
                         'exit_code': 0, 'result': 'pass', 'covered': cell['universe'][:90],
                         'check_results': {key: 'pass' for key in cell['check_ids']},
                         'selected': 2, 'executed': 2, 'passed': 2, 'failed': 0, 'skipped': 0,
                         'errors': 0, 'flaky': 0, 'suite_layers': [cell['layer']]})
    return contract, payloads


def write_bundle(root: Path, contract=None, payloads=None):
    if contract is None:
        contract, payloads = fixture()
    root.mkdir(parents=True, exist_ok=True)
    (root / 'payloads').mkdir(exist_ok=True)
    receipts = []
    for idx, payload in enumerate(payloads):
        relative = f'payloads/p-{idx:02}.json'
        raw = json.dumps(payload, sort_keys=True).encode()
        (root / relative).write_bytes(raw)
        receipts.append({'cell_id': payload['cell_id'], 'path': relative, 'sha256': hashlib.sha256(raw).hexdigest()})
    report = {'version': '2.0', 'contract_sha256': sha(contract), 'subject': copy.deepcopy(contract['subject']), 'measurements': receipts}
    (root / 'contract.json').write_text(json.dumps(contract), encoding='utf-8')
    (root / 'report.json').write_text(json.dumps(report), encoding='utf-8')
    return contract, report, sha(contract)


def invalid_cases():
    """Independent negative expectations; mutations are data, not self-derived outcomes."""
    cases = []
    def payload_case(name, key, value):
        c, p = fixture(); p[0][key] = value; cases.append((name, c, p))
    for key, value in [
        ('version', '1.0'), ('cell_id', 'absent'), ('subject', {'repo_id':'wrong','commit':'b'*40,'target':'wrong'}),
        ('layer','integration'),('metric','branch'),('component','other'),('platform','other'),('build_profile','other'),
        ('universe_sha256', 'b'*64), ('mode','mock'), ('record_kind','measured'), ('context',''),
        ('suite_layers',['unit','integration']), ('suite_layers',[]),
        ('created_at','2000-01-01T00:00:00Z'), ('created_at','2099-01-01T00:00:00Z'),
        ('created_at','not-time'), ('created_at','2026-01-01T12:00:00'),
        ('producer',''), ('command',[]), ('command',['ok','']), ('command','shell command'),
        ('exit_code',1),('exit_code',True), ('result','unknown'),
        ('selected',0), ('selected',True), ('selected',3), ('executed',1), ('passed',1),
        ('failed',1), ('skipped',1), ('errors',1), ('flaky',1),
        ('check_results',{}), ('check_results',{'positive-case':'pass','negative-control':'fail'}),
        ('covered',['line-000']*90), ('covered',['not-in-universe']),
        ('covered',[f'line-{n:03}' for n in range(84)]),
        ('covered',[f'line-{n:03}' for n in range(10,100)]),
    ]:
        payload_case(f'payload-{key}-{len(cases)}',key,value)
    c,p=fixture(); p[4]['context']=p[0]['context']; cases.append(('cross-layer-context',c,p))
    c,p=fixture(); p[0]['extra']='unrecognized'; cases.append(('extra-payload-field',c,p))
    c,p=fixture(); del p[0]['mode']; cases.append(('missing-payload-field',c,p))
    c,p=fixture(); c['purpose']='live_submission'; cases.append(('synthetic-not-live',c,p))
    for key,value in [('version','1.0'),('purpose','invented'),('profile','invented'),
                      ('authority_ref',''),('max_age_hours',0),('required_layers',[]),
                      ('required_layers',['unit','unit']),('required_layers',['not-real']),('cells',[])]:
        c,p=fixture(); c[key]=value; cases.append((f'contract-{key}-{len(cases)}',c,p))
    for key,value in [('universe',[]),('universe',['same','same']),('critical',['unknown']),
                      ('minimum_percent',84),('minimum_percent',101),('minimum_percent',True),
                      ('check_ids',[]),('component',''),('metric','unknown'),('layer','unknown')]:
        c,p=fixture(); c['cells'][0][key]=value; cases.append((f'cell-{key}-{len(cases)}',c,p))
    c,p=fixture(); c['subject']['commit']='abcd'; cases.append(('short-commit',c,p))
    c,p=fixture(); c['cells'][1]['id']=c['cells'][0]['id']; cases.append(('duplicate-cell',c,p))
    c,p=fixture(); c['cells'][1]['metric']='line'; cases.append(('duplicate-coordinate',c,p))
    c,p=fixture(); c['cells']=c['cells'][1:]; p=p[1:]; cases.append(('missing-structural-metric',c,p))
    c,p=fixture(); c['cells']=[x for x in c['cells'] if x['layer']!='e2e']; p=[x for x in p if x['layer']!='e2e']; cases.append(('missing-layer-cells',c,p))
    c,p=fixture(); c['required_layers']=['unit','integration']; c['cells']=c['cells'][:8]; p=p[:8]; cases.append(('runtime-no-e2e',c,p))
    c,p=fixture(); p[0]['covered']=p[0]['covered'][:85]; c['cells'][0]['universe'].append('line-100'); p[0]['universe_sha256']=sha(sorted(c['cells'][0]['universe'])); cases.append(('no-rounding-85-over101',c,p))
    return cases
