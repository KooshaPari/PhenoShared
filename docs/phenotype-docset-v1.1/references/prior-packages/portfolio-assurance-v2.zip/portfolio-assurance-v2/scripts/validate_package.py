#!/usr/bin/env python3
"""Validate this documentation/reference package; does not certify portfolio products."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote, urlsplit
import jsonschema
import yaml

ROOT=Path(__file__).resolve().parents[1]

def main():
    errors=[];parsed_json=0;parsed_yaml=0;links=0
    for path in ROOT.rglob('*'):
        if not path.is_file() or '__pycache__' in path.parts:continue
        if path.suffix=='.json':
            try:json.loads(path.read_text(encoding='utf-8'));parsed_json+=1
            except (UnicodeError,ValueError) as exc:errors.append(f'JSON {path}: {exc}')
        if path.suffix in ('.yaml','.yml'):
            try:yaml.safe_load(path.read_text(encoding='utf-8'));parsed_yaml+=1
            except (UnicodeError,yaml.YAMLError) as exc:errors.append(f'YAML {path}: {exc}')
        if path.suffix=='.md':
            text=path.read_text(encoding='utf-8')
            if not text.strip():errors.append(f'Empty Markdown: {path}')
            # Validate ordinary relative Markdown links; URLs and in-page anchors remain separate checks.
            for target in re.findall(r'\]\(([^)\s]+)(?:\s+"[^"]*")?\)',text):
                target=target.strip('<>');u=urlsplit(target)
                if u.scheme or target.startswith('#'):continue
                rel=unquote(u.path)
                if not rel:continue
                links+=1
                if not (path.parent/rel).exists():errors.append(f'Missing link {path.relative_to(ROOT)} -> {target}')
    schemas={}
    for path in (ROOT/'schemas').glob('*.schema.json'):
        value=json.loads(path.read_text());jsonschema.Draft202012Validator.check_schema(value)
        schemas[path.name]=jsonschema.Draft202012Validator(value,format_checker=jsonschema.FormatChecker())
    example=ROOT/'examples'/'synthetic-bundle'
    for filename,schema in [('contract.json','acceptance-contract.schema.json'),('report.json','measurement-report.schema.json')]:
        errors.extend(f'Schema {filename}: {e.message}' for e in schemas[schema].iter_errors(json.loads((example/filename).read_text())))
    for path in (example/'payloads').glob('*.json'):
        errors.extend(f'Schema {path.name}: {e.message}' for e in schemas['measurement-payload.schema.json'].iter_errors(json.loads(path.read_text())))
    catalog=json.loads((ROOT/'docs/coverage/METRIC-CATALOG.json').read_text())['metrics']
    ids=[m['id'] for m in catalog]
    if len(ids)!=len(set(ids)):errors.append('Duplicate metric IDs')
    if any(m['minimum_percent']<85 for m in catalog):errors.append('Metric below 85')
    tasks=json.loads((ROOT/'work/WORK-PACKAGES.json').read_text())['tasks'];index={t['id']:t for t in tasks}
    if len(index)!=len(tasks):errors.append('Duplicate work IDs')
    order=[];remaining=set(index)
    while remaining:
        ready=sorted(t for t in remaining if set(index[t]['hard_dependencies'])<=set(order))
        if not ready:errors.append('Work graph cyclic or missing prerequisite');break
        order.extend(ready);remaining-=set(ready)
    for t in tasks:
        if t['assignment_status']!='UNASSIGNED_PROPOSAL' or t['state']!='PLANNED_NOT_EXECUTED':errors.append('Unexpected fabricated work status')
    src=(ROOT/'reference/assurance.py').read_bytes()
    results=json.loads((ROOT/'validation/reference-results.json').read_text())
    if hashlib.sha256(src).hexdigest()!=results['source_sha256']:errors.append('Source changed after coverage run')
    for row in results['independent_suites']:
        path=ROOT/row['native_report']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=row['native_report_sha256']:errors.append('Native coverage report modified')
    raw=(ROOT/'provenance/captured-phenodocs-link-check.py').read_bytes()
    repro=json.loads((ROOT/'validation/phenodocs-stub-reproduction.json').read_text())
    if hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()!=repro['source_git_blob']:errors.append('Captured source Git blob mismatch')
    if repro['actual_exit_code']!=0:errors.append('Reproduction result changed')
    output={'scope':'Documentation, machine-record structure and own reference evidence; no product approval',
            'json_files_parsed':parsed_json,'yaml_files_parsed':parsed_yaml,'relative_file_links_checked':links,
            'schema_definitions_checked':len(schemas),'synthetic_schema_instances_checked':14,
            'metrics':len(catalog),'planned_work_packages':len(tasks),'work_topological_order':order,
            'coverage_source_and_payload_digests_match':not any('coverage' in x.lower() for x in errors),
            'errors':errors,'passed':not errors,
            'limits':['No full Markdown anchor parser, live external-link crawler or security scanner in this package validator.',
                      'Native source repositories, deployed services and actual engine state are not validated by this command.',
                      'Schema consistency is not producer authentication or semantic correctness proof.']}
    (ROOT/'validation/package-validation.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2));return 0 if not errors else 1

if __name__=='__main__':raise SystemExit(main())
