#!/usr/bin/env python3
"""Measure each reference-checker suite independently. Does not assess user repos."""
from __future__ import annotations
import ast
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
import coverage

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'validation'

def run(args,env,log):
    result=subprocess.run(args,cwd=ROOT,env=env,text=True,capture_output=True,timeout=180)
    log.write_text('$ '+ ' '.join(args)+'\n'+result.stdout+result.stderr,encoding='utf-8')
    if result.returncode:
        raise RuntimeError(f'{args} failed ({result.returncode}); see {log}')

def main():
    OUT.mkdir(exist_ok=True)
    # Each fresh run receives a distinct directory. Never clean the user's Git worktree.
    import tempfile
    run_root=Path(tempfile.mkdtemp(prefix='reference-',dir=OUT))
    records=[]
    tree=ast.parse((ROOT/'reference/assurance.py').read_text())
    entry_lines=[]
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            body=list(node.body)
            if body and isinstance(body[0],ast.Expr) and isinstance(body[0].value,ast.Constant) and isinstance(body[0].value.value,str):body=body[1:]
            if body:entry_lines.append((node.name,body[0].lineno))
    for layer in ('unit','integration','e2e'):
        directory=run_root/layer;directory.mkdir()
        env=dict(os.environ);env['COVERAGE_FILE']=str(directory/'.coverage')
        env['PYTHONPATH']=str(ROOT)+os.pathsep+str(Path(coverage.__file__).resolve().parent.parent)
        if layer=='e2e':
            env['ASSURANCE_MEASURE_E2E']='1'
            args=[sys.executable,'-m','unittest','tests.test_e2e','-v']
        else:
            args=[sys.executable,'-m','coverage','run','--branch','--source=reference','-m','unittest',f'tests.test_{layer}','-v']
        run(args,env,directory/'test-run.log')
        if layer=='e2e':
            run([sys.executable,'-m','coverage','combine',str(directory)],env,directory/'combine.log')
        json_path=directory/'coverage.json'
        run([sys.executable,'-m','coverage','json','-o',str(json_path)],env,directory/'export.log')
        native=json.loads(json_path.read_text());filedata=native['files']['reference/assurance.py'];summary=filedata['summary']
        hit=set(filedata['executed_lines']);missing_functions=[name for name,line in entry_lines if line not in hit]
        metrics={
            'line':{'covered':summary['covered_lines'],'total':summary['num_statements']},
            'branch':{'covered':summary['covered_branches'],'total':summary['num_branches']},
            'function_entry_proxy':{'covered':len(entry_lines)-len(missing_functions),'total':len(entry_lines)},
        }
        for metric in metrics.values():metric['percent']=100*metric['covered']/metric['total']
        records.append({'layer':layer,'metrics':metrics,'native_report':str(json_path.relative_to(ROOT)),
                        'native_report_sha256':hashlib.sha256(json_path.read_bytes()).hexdigest(),
                        'test_log':str((directory/'test-run.log').relative_to(ROOT)),
                        'missing_functions':missing_functions,
                        'missing_lines':filedata['missing_lines'],'missing_branches':filedata['missing_branches']})
    result={'scope':'reference/assurance.py only; tests use synthetic evidence, not portfolio product results',
            'coverage_tool':f'coverage.py {coverage.__version__}',
            'function_metric_note':'Derived AST first-executable-line entry proxy, not a native coverage.py function report.',
            'independent_suites':records,
            'threshold':85,'threshold_met':all(v['percent']>=85 for r in records for v in r['metrics'].values()),
            'source_sha256':hashlib.sha256((ROOT/'reference/assurance.py').read_bytes()).hexdigest()}
    (OUT/'reference-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 0 if result['threshold_met'] else 1

if __name__=='__main__':raise SystemExit(main())
