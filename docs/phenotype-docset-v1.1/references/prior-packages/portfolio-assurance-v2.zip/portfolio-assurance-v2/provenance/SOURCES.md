# Source register

Inspected on September 9, 2026 (America/Los_Angeles). GitHub file pins are immutable observations, not proof of runtime deployment. Primary web pages are version-sensitive. Refresh before implementation.

## GH-AP-FR

[AgilePlus nominal FR workflow](https://github.com/KooshaPari/AgilePlus/blob/82130cae162d6743b9c7271c8fdef441f0f20ade/.github/workflows/fr-coverage.yml)

Status: `source-inspected`. Commit: `82130cae162d6743b9c7271c8fdef441f0f20ade`.

Workflow checks out source and echoes a message; this workflow does not compute requirement coverage.

## GH-AP-STATE

[AgilePlus repository-state contract](https://github.com/KooshaPari/AgilePlus/blob/82130cae162d6743b9c7271c8fdef441f0f20ade/docs/agileplus/repo-state-contract.md)

Status: `source-inspected`. Commit: `82130cae162d6743b9c7271c8fdef441f0f20ade`.

Repository-local mutable state and generated docs/agileplus review artifacts; not a global cross-project database.

## GH-PD-PKG

[PhenoDocs package scripts](https://github.com/KooshaPari/phenodocs/blob/c70fc899ddb1da334b11333e8d48f4051fc4a18d/package.json)

Status: `source-inspected`. Commit: `c70fc899ddb1da334b11333e8d48f4051fc4a18d`.

check invokes lint/typecheck and the link-check script; accessibility/locale/alt scripts also exist, but were not run here.

## GH-PD-LINK

[PhenoDocs link checker](https://github.com/KooshaPari/phenodocs/blob/c70fc899ddb1da334b11333e8d48f4051fc4a18d/scripts/check_docs_links.py)

Status: `source-inspected`. Commit: `c70fc899ddb1da334b11333e8d48f4051fc4a18d`.

Placeholder prints stub OK and returns zero; must not support link-correctness claims.

## GH-PD-README

[PhenoDocs declared federation model](https://github.com/KooshaPari/phenodocs/blob/c70fc899ddb1da334b11333e8d48f4051fc4a18d/README.md)

Status: `declared-contract-not-executed`. Commit: `c70fc899ddb1da334b11333e8d48f4051fc4a18d`.

Multi-project VitePress federation, audience layers and docs_engine integration claims. Some commands/URLs remain placeholders; capability-probe before use.

## GH-JOURNEY-VERIFY

[Journey single-manifest verifier](https://github.com/KooshaPari/phenotype-journeys/blob/f5764d33c549984d21531a09d05a3ab55ca156a5/crates/phenotype-journey-core/src/verify/mod.rs)

Status: `source-inspected`. Commit: `f5764d33c549984d21531a09d05a3ab55ca156a5`.

Mock fixed success is labelled mock. Feature-gated live path also returns fixed scores/all_intents_passed after reading but not interpreting judge response; screenshot supplied as path text.

## GH-JOURNEY-CLI

[Journey CLI verify dispatch/error handling](https://github.com/KooshaPari/phenotype-journeys/blob/f5764d33c549984d21531a09d05a3ab55ca156a5/bin/phenotype-journey/src/main.rs)

Status: `source-inspected-lines380-585`. Commit: `f5764d33c549984d21531a09d05a3ab55ca156a5`.

Single-manifest dispatch reaches verify_with_root. Assertion-engine error is stored as assertions_error; end checks false verdict/false report but not that error field.

## GH-BENCH-MUT

[Benchora mutation/coverage tracker](https://github.com/KooshaPari/Benchora/blob/8520ca49db1d4da3e42fea2a11c243aff9112eb4/src/mutation/mod.rs)

Status: `source-inspected`. Commit: `8520ca49db1d4da3e42fea2a11c243aff9112eb4`.

Observed-line fallback denominator; an observed line past recorded LOC returns 1.0; repeated kill_mutation increments killed count again; aggregate branch report uses zero placeholders.

## GH-HEX-INTENT

[HexaKit intent specification](https://github.com/KooshaPari/HexaKit/blob/a848a7160079cf063f3653b080af26097f5465e4/docs/genesis/INTENT_SPEC.md)

Status: `source-inspected`. Commit: `a848a7160079cf063f3653b080af26097f5465e4`.

Turn-level original prompts, source/session provenance, prompt hash, separate synthesis, assumptions and refresh policy.

## GH-HEX-SCRAPER

[HexaKit intent extraction implementation](https://github.com/KooshaPari/HexaKit/blob/a848a7160079cf063f3653b080af26097f5465e4/scripts/extract-intent-prompts.py)

Status: `source-inspected-lines1-235`. Commit: `a848a7160079cf063f3653b080af26097f5465e4`.

Inspected extraction strips text and joins blocks; uses file-mtime fallback; logs can be silently skipped. Byte-preserving provenance needs explicit raw/normalized distinction.

## GH-HEX-SOTA

[HexaKit dimensional SOTA specification](https://github.com/KooshaPari/HexaKit/blob/a848a7160079cf063f3653b080af26097f5465e4/docs/genesis/SOTA_SPEC.md)

Status: `source-inspected`. Commit: `a848a7160079cf063f3653b080af26097f5465e4`.

Technical/DX/UX/AX/security/ops/cost dimensions, minimum three alternatives per applicable dimension, fork rationale and evolution triggers.

## WEB-COVERAGE

[Google code coverage practices](https://testing.googleblog.com/2020/08/code-coverage-best-practices.html)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Execution coverage is not assertion adequacy; no universal percentage proves quality. The 85% policy here is an operator-selected floor.

## WEB-LLVM

[LLVM source-based coverage](https://clang.llvm.org/docs/SourceBasedCodeCoverage.html)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Source coverage, regions/branches and instrumentation capabilities; toolchain profile must be pinned.

## WEB-RUST-COV

[cargo-llvm-cov documentation](https://github.com/taiki-e/cargo-llvm-cov)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Explicit test selection, external-process instrumentation, profile collection and toolchain constraints; --tests is not an integration-only guarantee.

## WEB-PY-CONTEXT

[coverage.py measurement contexts](https://coverage.readthedocs.io/en/latest/contexts.html)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Static/dynamic contexts support separation; classification and correct collection remain integrator responsibilities.

## WEB-GO-COV

[Go integration coverage](https://go.dev/doc/build-cover)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Instrumented builds, GOCOVERDIR and explicit package selection for integration coverage.

## WEB-PLAYWRIGHT

[Playwright Coverage API](https://playwright.dev/docs/api/class-coverage)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Built-in JavaScript/CSS coverage is Chromium-only; it does not measure every browser or server-side implementation.

## WEB-MUTANTS

[cargo-mutants](https://mutants.rs/)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Mutation testing checks whether injected behavioral changes are detected; not the same as execution coverage.

## WEB-GH-CHECKS

[GitHub protected branch checks](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Required checks may accept success, skipped or neutral conclusions; product acceptance must additionally validate required execution.

## WEB-A11Y

[W3C accessibility evaluation tools](https://www.w3.org/WAI/test-evaluate/tools/selecting/)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Automated tools do not establish all accessibility conformance; knowledgeable evaluation remains required.

## WEB-EVALS

[OpenAI evaluation best practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices)

Status: `primary-source-read`. Commit: `not pinned; web documentation`.

Task-specific evaluation and calibration principles for stochastic systems; not permission to trust a fixed or uncalibrated judge score.

## GH-JOURNEY-ENTRY

[Journey library entrypoint](https://github.com/KooshaPari/phenotype-journeys/blob/f5764d33c549984d21531a09d05a3ab55ca156a5/crates/phenotype-journey-core/src/lib.rs)

Inspected lines1–280 confirm verify_manifest dispatches to verify::run after deserializing the input. This links the inspected CLI to the fixed-verdict path; no native service call was executed.
