# Research, competitive assurance, pilots and case studies

A written SOTA argument, a benchmark and a user case study answer different questions. Preserve all three. This plan extends the existing [HexaKit dimensional framework](../../provenance/SOURCES.md) rather than replacing it.

## 1. Category research versus product-specific verdict

A shared category dossier contains the longlist of relevant products, frameworks, protocols, adapters, prior art and no-product workflows. Investigate at least 25 when the actual category supports that breadth and the assignment requests it. Explain smaller bounded results, exclusions and search gaps rather than inventing competitors or “proving” a global maximum from a few queries. Count materially distinct implementations; do not inflate with every wrapper or hosted tier.

Each product keeps a scoped comparison derived from this dossier. For each applicable dimension, consider at least three serious alternatives where available, including best direct/manual/composed choices. The nearest shortlist may vary by user job. A repository can consume a versioned category record without copying an entire dossier into its own tree.

Required dimensions include technical architecture, correctness, performance, scale, resource/energy cost, DX, UX, agent experience, accessibility, security/privacy, interoperability, deployment/operations, licensing, portability, maintenance, lock-in and migration. Mark scope-specific N/A explicitly. Do not set a dimension aside merely because the current product loses there.

## 2. Claims and evidence ledger

For each claim record: user job, requirement, product version/commit, comparison version, dimension/metric, claim type (vendor assertion, static observation, measured result, hypothesis or qualitative assessment), evidence source, retrieval/run date, constraints, exclusions, confidence and reopening trigger.

A primary source describing feature support establishes documented support, not measured superiority. A README promising 120 Hz does not prove tail latency under a saturated GPU. A source-level argument about simpler APIs does not establish actual onboarding effort. Keep those distinctions visible.

Broad novelty is not mandatory for every repository. Internal libraries, maintained forks, package-manager satellites and compatibility adapters may justify themselves by reuse, operational control, lower maintenance or a necessary distribution contract. An independent public product needs a defensible user job or meaningful improvement. Do not invent novelty to preserve every brand.

## 3. Pilot preregistration

Before coding the comparison, freeze the experimental question, accepted scope, baseline shortlist and versions, target users, mandatory invariants, non-inferiority margins, material superiority threshold, budgets, workload distribution and stopping rule. The denominator is the declared comparison cells, not only metrics that favor the candidate.

Keep two tracks where appropriate:

- **Controlled comparison:** match model, prompts, tasks, tool permissions, hardware, dependency versions, network, retries, cache policy and budgets to isolate the effect of interest.
- **Idiomatic solution comparison:** competent best-practice implementation in each stack, with transparent tuning/setup budgets, to compare the experience an actual adopter can obtain.

Do not mix the tracks into a winner headline. A Python versus Rust result may be a valid whole-stack deployment comparison; it is not automatically a causal framework-only comparison. Similar-looking apps can have different acceptance semantics or hidden scaffolding costs.

Measure end-to-end latency/completion, cold/warm behavior, tail latency, resources, error/recovery, determinism, integration burden, configuration, code written/maintained, conceptual/API complexity, testability, debugging, migration and operating cost. Lines of code alone are not an ease-of-use metric. Time attribution must separate human implementation, agent generation, tool waiting, tuning, run time and review.

## 4. Stochastic-agent evaluation

Use held-out tasks appropriate to the claim and repeat independent runs. Record provider/model identifier and revision where available, request options, tool schemas, budgets, retry/cancellation policy, seed support, cache state, conversation/context policy and environment. Do not pretend a model name pins a provider’s immutable behavior when it does not.

Use executable oracles for patch correctness, test results, data invariants, file changes, permission boundaries and resource budgets. Use calibrated qualitative review for nuanced planning, explanation quality or ease of adoption. A second LLM seeing the same flawed story is not automatically independent verification. Include seeded failures, adversarial traces and known negatives to evaluate judge specificity and false-pass behavior.

Predeclare uncertainty and statistical methods. A single favorable run is a demonstration, not a stable win. Report effect sizes, distributions and confidence intervals as appropriate. Retain failed runs, unresolved inputs and reproduction limitations. Avoid tuning on the same held-out set used for the final claim; disclose unavoidable contamination.

## 5. Agentora bounded coding-agent pilot

The minimal useful job is not a complete Codex clone. Define a small repository with a realistic seeded defect and acceptance suite. The agent must inspect the task, obtain relevant files, propose or apply an authorized patch, run the prescribed tests, recover from a tool failure, avoid touching protected files, respect budgets, and emit a traceable result.

Candidate paths: Agentora at a pinned build; nearest compatible OpenAI Agents SDK, LangGraph/LangChain or CrewAI implementation; and direct SDK/tool loop. Select only those fitting the actual language and runtime question. Keep a shared tool contract, fixture repository and external acceptance harness. Baseline implementations need competent effort and fair tuning, not strawmen built to lose.

Primary result: correct and safe task completion. Secondary results: framework overhead, setup/review/maintenance effort, configuration, concepts required, cancellation/resumption, durable state, provenance, provider portability and scale. Add multi-agent/context-pressure cases only after the single-task baseline is reliable. For user-facing workbench/CLI products, separately evaluate the actual UI, keyboard/workflow, installation and recovery experience.

## 6. Performance and interactive contention

The portfolio runs on machines that may simultaneously handle compilers, LLM inference, game E2E, games and Ableton. An idle-host benchmark is only one operating point. Include representative CPU, GPU, VRAM, RAM, filesystem and network contention profiles. Record thermals, power mode, scheduling, encoder occupancy and other material configuration where relevant.

Instrumented coverage runs distort timing and memory. Use them for attribution; use matched uninstrumented release builds for performance conclusions. A telemetry/benchmark harness itself must be measured for overhead. Do not saturate the operator’s audio or display path without an explicit test window and recovery plan. Synthetic contention profiles should have capped resources and deterministic termination.

For the compute/data/I/O fabric, keep capture-to-enqueue, glass-to-glass, input-to-photon, audio round trip and clock drift as separate boundaries. Preserve HDR/chroma/transfer-function and scaling settings. No generic “latency” number substitutes for all of them. The current package does not execute these hardware tests or establish any performance result.

## 7. Case-study deliverable

A case study includes the user problem and former workflow, bounded target, exact installation and configuration, task walkthrough, actual artifacts/recordings, failures encountered, fixes, controlled results, user/qualitative observations, limits and reproducibility. Pair human-readable narrative with machine-readable run and outcome records. Screenshots of a shell command are not proof of exit status, actual state or complete behavior; capture structured results alongside visual evidence.

Mandatory intended user journeys need complete demonstrated success; broader pilot-dimension execution can use the 85% breadth floor only for explicitly noncritical exploratory cells. Every mandatory comparison result must be collected, and no critical parity failure can be hidden in the untested 15%.

Allowed outcomes: validated advantage, strategic parity, accepted trade-off, distinct user job, no demonstrated advantage, baseline/composition wins, inconclusive, or scope redefinition requiring a decision. A negative pilot is valuable evidence, not a reason to fabricate scores or quietly remove the losing dimension.

## 8. Lifecycle consequences

A G1 artifact can close the pilot protocol, not the empirical result. G4 requires actual runs and interpretation. A failed/inconclusive pilot can close the experiment while leaving product graduation open. Use the result to retain/refocus, integrate, absorb, defer research or retire under the accepted authority. Preserve the original hypothesis and failed evidence so the portfolio does not repeat the same unsupported argument in a new repository.
