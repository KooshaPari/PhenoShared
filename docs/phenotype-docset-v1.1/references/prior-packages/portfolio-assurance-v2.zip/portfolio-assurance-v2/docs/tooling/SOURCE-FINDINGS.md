# Targeted source findings: qualify the assurance tools before trusting them

These are **static source findings** unless a narrowly scoped reproduction is explicitly identified below. The inspected main tips for AgilePlus, PhenoDocs, phenotype-journeys and Benchora matched the pinned revisions returned by GitHub during this response. No repository edits, hosted CI reruns or full native product suites were performed. Local agents must refresh tips, reproduce narrowly, preserve existing fixes and coordinate the real owner. References are in [SOURCES.md](../../provenance/SOURCES.md).

## QE-01 — AgilePlus FR workflow does not measure FR coverage

**Source:** GH-AP-FR, `.github/workflows/fr-coverage.yml`, `82130cae162d6743b9c7271c8fdef441f0f20ade`.

The workflow checks out the repository and executes an echo describing a prospective integration. There is no requirement inventory comparison or evidence validation in this workflow. A green conclusion from it cannot prove FR coverage. Other workflows may provide separate useful checks; this finding is scoped to the named job.

**Repair acceptance:** replace the placeholder through the existing owner’s work package; bind requirements to tests/evidence, reject orphan/missing/duplicate/unexecuted checks, and prove a known missing FR or bad evidence causes nonzero failure. Verify both local command and actual CI invocation. Preserve engine authority boundaries.

## QE-02 — PhenoDocs link gate is a success-returning stub

**Sources:** GH-PD-LINK and GH-PD-PKG, `c70fc899ddb1da334b11333e8d48f4051fc4a18d`.

The link checker explicitly describes itself as a placeholder, prints `stub OK`, and returns zero. The package’s `check`/`check-links` commands invoke it. This establishes command wiring, not link validation.

**Isolated reproduction:** the captured script bytes were verified against Git blob `ddca435f62b5d0f5fe8721584f220c28e3bf7697`. Running that exact script in a temporary directory containing a seeded broken Markdown link returned exit 0 and the stub-success message. This is a script-level reproduction, not a full PhenoDocs build or CI result. See [the reproduction record](../../validation/phenodocs-stub-reproduction.json).

**Repair acceptance:** broken relative file, broken anchor, wrong case, missing media, invalid generated source link and private-public leakage fixtures must fail. Valid links and deliberate versioned redirects pass. External transient failures, auth-required links and deliberate exclusions need typed policy, not unqualified success. Test the built site and generated search/navigation paths, not only Markdown filenames. Avoid unnecessary network crawling on every unit test.

## QE-03 — Journey single-manifest “live” semantic verdict is fixed

**Source:** GH-JOURNEY-VERIFY, `f5764d33c549984d21531a09d05a3ab55ca156a5`.

The mock function returns a fixed 0.92 overall score and `all_intents_passed=true`, correctly labelled mock. The feature-gated live function sends requests, reads response text, then returns the same fixed success values with mode `api`; it does not derive the final verdict from the response. The describe prompt includes a screenshot path string rather than actual screenshot pixels in this inspected path.

**Impact boundary:** this specific result cannot justify a live semantic approval. It does not mean every batch pipeline, manifest validator or separate hard assertion in the repository is ineffective. Identify downstream callers of this result and reclassify only affected receipts.

**Repair acceptance:** HTTP error, malformed result, missing result field, explicit negative verdict, missing visual evidence and unavailable live mode must produce error/inconclusive/rejection rather than success. Send the actual intended evidence through a validated input contract. Separate structured deterministic assertions from calibrated qualitative judging. Preserve raw response and verdict derivation without leaking private data. Never promote mock evidence to a real user-journey outcome.

## QE-04 — Journey assertion-engine errors can avoid the failure predicate

**Source:** GH-JOURNEY-CLI, the same commit, `cmd_verify_with_root`.

Single-manifest dispatch reaches this path. An assertion-engine error is stored in `assertions_error`; final failure checks inspect `all_intents_passed` and an optional `assertions.passed=false`, but do not reject the error field. When no report exists and the semantic verifier supplies fixed success, this path can return success by inspection of its control flow.

**Repair acceptance:** missing/corrupt keyframe, assertion backend failure, unavailable required tool, malformed assertion result, zero required assertions and missing docs root must fail or be explicit non-accepting states according to the approved invocation contract. Prove process exit and consumer gate both reject them. Do not merely change the printed JSON while leaving exit status successful.

## QE-05 — Benchora measurement logic can overstate assurance

**Source:** GH-BENCH-MUT, `8520ca49db1d4da3e42fea2a11c243aff9112eb4`.

The tracker falls back to highest observed line for total LOC. If an observed line exceeds the recorded LOC, per-file coverage returns 1.0; the source includes a test expecting this for two observed lines against a recorded 100-line file. This is not a defensible executable-source denominator. `kill_mutation` increments killed count on each call without checking an already-killed status. Thus calling it twice for a single mutant would compute 2/1 by source-level reasoning; this response did not execute that native path. Repeated equivalent marking also needs idempotence review. Aggregate report branch counts are zero placeholders in the inspected conversion.

**Repair acceptance:** native inventory supplies denominators; inconsistent counts reject rather than clamp to perfection. Mutant IDs are unique for actual mutation sites/operators and terminal transitions are idempotent or explicitly illegal. Repeated kill/equivalent operations cannot inflate scores or erase unrelated mutants. Empty runs are not perfect. Preserve explicit unknown branch measurements. Round-trip native reports and compare against known fixtures.

## QE-06 — Intent specification exceeds the inspected scraper’s fidelity guarantees

**Sources:** GH-HEX-INTENT and GH-HEX-SCRAPER, `a848a7160079cf063f3653b080af26097f5465e4`.

The intent specification has valuable turn-level provenance and a clear original-versus-synthesis distinction. Preserve it. The inspected scraper portion strips text, combines text blocks, substitutes file-mtime-derived timestamps when message time is absent, and silently skips some unreadable/invalid input. Those transformations require declared provenance; normalized text is not original bytes.

**Repair acceptance:** retain immutable raw evidence in its authorized private location, decoded source text and normalized/redacted projections separately. Record timestamp origin/confidence, parse errors and source coverage. Include whitespace, Unicode, multi-block, short correction, missing timestamp, malformed JSON and duplicate-session fixtures. Do not assume every session tool uses the same message envelope or current on-disk path.

## AP-01 — Current AgilePlus contract is repo-local

**Source:** GH-AP-STATE, `82130cae162d6743b9c7271c8fdef441f0f20ade`.

This is a integration-contract update, not a defect finding. It locates mutable records under the subject Git root and declares `docs/agileplus` files materialized review artifacts. Previous generic global/kitty-spec assumptions must be mapped to the deployed version. A file saying DONE does not substitute for querying the current scoped engine state. Do not bulk-migrate historical records by guessing destination from a feature name.

## Repair sequence and scope

Qualification of a particular checker is a hard prerequisite for trusting its affected verdicts—not for every unrelated product task. Owners of the shared repositories repair these paths in narrow PRs and test negative cases. Consumer workers keep developing approved capabilities and collecting independent native evidence. The coordinator records dependency adoption and schedules an affected-evidence revalidation window. No source code is changed by this package itself.
