# Actual integration, not ceremonial tooling adoption

Sources: [SOURCES.md](../../provenance/SOURCES.md). These rows distinguish declared role, inspected implementation and proposed acceptance. They do not establish that an installed service has the same revision as GitHub.

| System | Intended use in this program | Required adoption evidence | Not sufficient |
|---|---|---|---|
| AgilePlus | Repo-scoped governed features/work packages and gate state | Probe installed contract; bind canonical repo root; query real scoped state; submit/check through supported API; materialize tracked projections; test root mismatch and cross-session isolation | Writing DONE to a generated file or assuming a global database |
| PhenoDocs | Versioned federation/publication of product-local documentation | Pin source revisions; generate/build actual site; test source backlinks, search/navigation, private filtering and links; validate packaged site | README mention, a successful stub link check, or a folder copied into a hub |
| phenotype-journeys | Capture and evidence manifests for real user flows | Actual release/public entrypoint, raw recording/event evidence, meaningful assertions, correct failure status, calibrated optional visual judgment | Mock 0.92, path-as-image, default-true live fallback, or merely schema-valid manifest |
| Benchora | Benchmark baselines, regression reporting and reusable evaluation tooling | Validate native input adapters; immutable baseline/run IDs; correct denominators/mutant state; failed-run retention; genuine CLI/consumer test | A ratio computed from incomplete observed lines or double-counted mutation events |
| HexaKit/local genesis tools | Preserve richer intent/SOTA/templates where authoritative | Actual schema/version, source lineage and adapter; deterministic extraction and reviewed normalized representations | Replacing rich local captures with empty template folders |
| Tracera | Evidence/requirement relationships and accepted traceability projection where integrated | Contract-versioned ingest/query, provenance/freshness and negative checks, explicit evidence-source ownership | Assuming an export file proves accepted ingestion |
| SessionLedger | Relevant operational session capture/replay provenance | Authorized session inventory, stable run/turn IDs, capture completeness and correct source binding | Treating unobserved sessions as captured |
| ResearchLedger | Reusable category research corpus and source provenance | Source/version/claim linkage, retrievable evidence, expiry triggers, project-specific projections | Copying an unsupported summary into every repo |
| RepoLedger/portfolio registry | Observed inventory, accepted role/proposal separation, progress projection | Stable host IDs, snapshot/ref identity, before/transition/after map, owned blockers | Re-sorting names into new IDs or treating proposals as approvals |
| Existing shared CI/ops tools | Enforced workflow, policies and release integrity | Pinned workflow/action refs, actual protected-branch/rules behavior, negative gate tests and release receipts | Green labels, disabled checks, skipped/neutral runs or unsupported completion percentages |

For the last four named authorities, role definitions are drawn from the supplied portfolio context rather than a fresh full implementation audit in this response. Probe and cite their actual versions before claiming compatibility. Do not make one universal data store merely to simplify integration.

## Minimal adoption receipt

A receipt identifies producer/tool version or source commit, subject repository/commit, target profile, operation, schema/contract version, input/artifact digests, selected checks, actual outcome, execution environment, timestamp and consumer acknowledgment where applicable. Distinguish local export, accepted remote ingest, visible query result and gate transition. An exporter invocation cannot imply all four happened.

At least one positive and one meaningful negative contract test must exercise the deployed integration. For example, a wrong repository root must not query or mutate another repo’s state; a private source must not appear in a public search index; a failed journey must not be accepted because an artifact filename ends in `.verified.json`.

## Tool failure policy

When an integration is required, a broken tool produces an owned blocker and a bounded repair—not silent substitution with an unverified script. A temporary adapter may use trusted native reports when explicitly approved and contract-compatible; it must keep original results and limitations. Optional integration can remain open while a standalone bounded product ships under its own acceptance policy. Required integration cannot be relabelled optional solely to close the task.

## Documentation federation safety

Keep canonical product content in its accepted source home. PhenoDocs consumes pinned references/projections and exposes the right audiences. Test frontmatter/schema preservation, requirement anchors, broken version links, search results, diagrams, media paths, dark/light/high-contrast presentation and keyboard navigation. Test generated `llms.txt`/machine indexes for correct source ownership, privacy and stale content. Treat publication/deployment as a separate authorized operation.

## AgilePlus state safety

The inspected contract separates mutable SQLite state, ignored runtime data and generated Git review artifacts. Do not share one writable worktree across workers, guess root from a directory label or commit a live DB. Observe the actual engine’s feature/work-package state and audit chain through the available scoped interface. If the service is unavailable, produce an explicitly offline proposal and blocker rather than inventing engine transitions.

The coordinator can own portfolio-level decisions without making its checkout the mutable authority for every child repo. Cross-repo execution requires linked work packages and accepted source-target-consumer owners. Real permissions are distinct from the JSON or Markdown assertion that somebody approved a task.

## No forced new framework

Adopt this contract through the existing versioned schema/validator or a narrow adapter. The reference checker in this package is illustrative and tested, but not a reason to create an additional portfolio product. Move reusable logic into an existing accepted owner only after reviewing its responsibilities, consumers and integration tests.
