# Test the tests and the reporting gates

The portfolio needs a product oracle and a meta-oracle. A product oracle judges actual behavior; a meta-oracle checks whether the product oracle, evidence collector and gate detect deliberate mistakes. They are complementary, not an infinite chain of “proof by another LLM.”

## Required failure controls

| Seeded defect / bad input | Required response |
|---|---|
| One required test family absent | Reject target acceptance; no combined-report substitution |
| 84% E2E with 100% unit/integration | Fail the E2E cell |
| Empty eligible inventory / 0 tests selected | UNKNOWN/invalid, not 100% |
| Missing eligible zero-hit source file | Inventory reconciliation fails |
| Changed source/target/platform/profile | Reject stale or mismatched evidence |
| Mixed unit/integration accumulator | Reject independent attribution |
| Assertion fails but process exits zero | Gate qualification fails |
| Assertion backend unavailable | Block/error; never default success |
| Canned semantic verdict labelled live | Reject semantic acceptance and invalidate affected receipt type |
| Duplicate mutation kill/equivalent updates | Preserve consistent idempotent counts or reject illegal transition |
| Fabricated/unknown coverage item | Reject numerator outside denominator |
| Test skips, timeouts, crashes or errors | Non-passing; retain failure cause |
| Required check omitted or neutral/skipped | Not accepted merely because hosting platform permits it |
| Payload changed after checksum | Reject integrity mismatch |
| Unapproved denominator or threshold edit | Reject contract digest/authority mismatch |
| Missing critical obligation despite 85% total | Hard fail |
| Broken doc link/anchor/media | Nonzero failure with specific source location |
| Secret/private capture in public docs/search | Block publication and surface the privacy violation |
| API error or malformed judge response | Error/inconclusive, not fabricated pass |
| Wrong AgilePlus root/session | Reject access/state mutation for the wrong subject |

## Independence and trust

The same implementation agent should not be sole author of specification, test, expected answer, denominator and approval. Obtain independent review of critical contract/oracle changes. Preserve a known-good and known-bad fixture set with provenance. A verifier can use the same test framework but must examine failure sensitivity, source identity, fixture semantics and counterexamples.

Native reports need explicit adapters. Round-trip known native fixtures, malformed exports, missing objects, unsupported tool versions and collection failures. Test path normalization, generated/source maps, UTF-8, integer overflow/rounding, duplicated identities, subprocess profile merging and source revision binding.

Signed/checksummed evidence is useful custody, not truth. Authenticate the trusted CI producer and actual reviewer in the real deployment. Keep raw reports and command results. No human-approval string or JSON schema alone is a sufficient authorization boundary.

## Evidence invalidation and repair

A discovered checker bug does not mean every prior artifact is false. Identify which verdict types, versions, call paths and consumers used the faulty logic. Mark those receipts unqualified, reproduce the narrow defect, fix the owner’s implementation, add regression controls and revalidate affected consumers. Preserve unrelated evidence and useful product work.

The current package documents specific static findings in the existing assurance tooling. It executes synthetic tests of its own reference checker only. The work graph assigns native reproductions to the respective owners; it does not claim they have happened.
