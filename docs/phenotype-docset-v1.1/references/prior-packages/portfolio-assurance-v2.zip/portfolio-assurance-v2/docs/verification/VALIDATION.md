# Validation results and scope

Policy package dated September 9, 2026, America/Los_Angeles. This report distinguishes static repository inspection, a narrow exact-script reproduction, and tests of the supplied reference checker. It does not declare any portfolio repository complete.

## Reference checker execution

Commands: `python -m unittest tests.test_unit tests.test_integration tests.test_e2e -q` and `python scripts/measure_reference.py`. The first completed 24 unittest test methods successfully. The suites include data-driven negative cases; do not confuse method count with coverage percentage.

The shared semantic negative corpus contains 70 distinct invalid-record vectors, executed independently in each suite. Additional integrity, filesystem, parser, entrypoint and positive cases are included. Unit tests isolate boundaries; integration tests use real temporary evidence files; E2E tests launch the actual CLI in child processes. Native product repositories were not tested by these suites.

| Suite | Line covered/eligible | Line % | Branch covered/eligible | Branch % | Derived function-entry proxy |
|---|---:|---:|---:|---:|---:|
| unit | 193/194 | 99.48% | 29/30 | 96.67% | 17/17 |
| integration | 193/194 | 99.48% | 27/30 | 90.00% | 17/17 |
| e2e | 194/194 | 100.00% | 29/30 | 96.67% | 17/17 |

Source: `reference/assurance.py`, SHA-256 `2b1f560d428c911b9a7b90fb3147f43d5ca812a457ffeecb091f3201c8cf1e90`. Tool: `coverage.py 7.13.3`. The function metric is a derived AST first-executable-line entry proxy, not native coverage.py function reporting. It is labelled rather than silently claimed as native instrumentation.

[Machine-readable results and native evidence paths](../../validation/reference-results.json). All three suites meet 85% independently on this source module. These percentages are not measurements of the portfolio, the whole package, test quality in general, or all possible behaviors. The coverage module’s `__main__` branch is structurally different in import versus CLI execution; no source lines were excluded to inflate the result.

## Narrow source reproduction

The PhenoDocs placeholder link script was copied from the inspected connector content; its Git blob identity was recomputed and matched. The exact script returned 0 in a temporary docs root containing a link to an absent file. No external service or source repository was changed. [Raw reproduction record](../../validation/phenodocs-stub-reproduction.json).

## Documentation and records

Run `python scripts/validate_package.py`. It parses JSON/YAML, validates three reference schemas and synthetic example instances, checks unique metric/work IDs, floors, relative file links, DAG structure and source/report digest consistency. Actual results are in [package-validation.json](../../validation/package-validation.json).

It is intentionally not advertised as a complete link/anchor crawler, secret scanner or product-conformance engine. Missing production tooling must be reported, not replaced with unsupported “all checks passed” claims.

## Not performed

No fleet-wide new audit, native builds/tests of the inspected repositories, hosted workflow reruns, real benchmark/model calls, source repository repairs, live AgilePlus MCP queries/transitions, publication, migration or archive actions. No subagents were launched. The toolkit findings are source-scoped with the one script-level reproduction stated above. The planned work packages remain unassigned proposals.

## Integrity is not authority

The reference validates compatible records against a caller-pinned contract. It does not authenticate the producer or reviewer. A fabricated but self-consistent record can still be untrue; actual acceptance needs a trusted native-report adapter, independently reviewed denominator, authenticated receipts and domain-specific oracles.
