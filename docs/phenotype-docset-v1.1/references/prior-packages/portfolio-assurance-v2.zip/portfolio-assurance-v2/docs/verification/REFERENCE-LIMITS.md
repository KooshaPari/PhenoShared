# Reference checker: capabilities and limits

`reference/assurance.py` is a read-only consistency checker for a deliberately small normalized record format. It is not an AgilePlus engine, identity provider, native coverage instrument, sandbox or product acceptance authority.

## Implemented checks

A controller supplies an independently pinned canonical contract digest. Runtime contracts require unit, integration and E2E, each with line, branch, function and obligation cells. Each cell declares a finite nonempty eligible universe, critical subset, >=85% threshold, source and required check IDs. Reports must carry all cells exactly once, matching repo/full commit/target/platform/component/profile/metric, a declared execution context, recent timestamps, intact payload digests, known covered IDs and passing execution counts/check IDs. Families cannot reuse the same accumulator identity. Mock/inferred modes reject. Required critical IDs must be covered. Integer arithmetic prevents upward rounding.

Input JSON rejects duplicate keys and non-finite values. Payload paths must be relative and contained after symlink resolution, with bounded file sizes. The checker hashes and parses the same payload bytes. It does not execute commands carried in evidence. It returns `RECORDS_CONSISTENT` and explicitly sets `lifecycle_approval=false` and `authenticated_producer=false`.

## Deliberately not implemented

- Discovering the complete requirement/source denominator, every repo or every consumer.
- Authenticating a reviewer, operator approval, tool execution or cryptographic attestation.
- Verifying that a claimed native measurement actually occurred.
- Parsing every language’s LCOV/LLVM/Jacoco/Go/V8 report format.
- Engine writes, repository mutations, check bypasses, migrations or deployment.
- A complete exception/waiver engine, support-matrix solver or dependency invalidation engine.
- Race-resistant hostile-filesystem containment or a security sandbox. Evaluate an immutable controlled evidence snapshot. File paths and error messages may expose local details; control log visibility.
- Proving all security invariants, uncertainty/CI math or qualitative judgments.

A malicious producer who controls the approved contract and all claimed records can fabricate self-consistent data. The external trusted digest matters only when the actual controller reviews and pins the correct contract outside that producer’s authority. This helper cannot prevent a human from approving a bad denominator. `role_specific` is not permission to misclassify a runtime project; role selection belongs to the actual accepted contract.

## Fixture and result boundaries

The tests build synthetic evidence bundles. These bundles intentionally contain invented fixture identities and counts. Their `purpose=demonstration` and `record_kind=synthetic_fixture` are mandatory labels. A schema-path test also constructs a `live_submission` shape to show that the checker distinguishes formats; it remains a synthetic test and explicitly proves no producer authentication.

The reference’s own unit suite isolates components and mocks external IO; integration suite uses real temporary files and orchestration; E2E suite starts the actual CLI in child processes and checks exit status/output. All three measure the same source module independently. The normalized fixtures are not evidence about KooshaPari repositories. Successful reference validation must never promote any repository target.

## Integration guidance

Reuse the semantics in the accepted existing owner or an adapter. Pin schema/version, native producer and artifact identity. Add authenticated CI/engine receipts, actual reviewer permission checks, denominator/source inventory adapters and policy-specific exceptions in their appropriate systems. Do not create a new repository or broad framework merely because this reference exists.
