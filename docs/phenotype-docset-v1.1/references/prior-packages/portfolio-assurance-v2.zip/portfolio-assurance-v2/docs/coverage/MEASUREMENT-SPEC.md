# Independent measurement specification

Normative floors are in [ASSURANCE-CONTRACT.md](../../ASSURANCE-CONTRACT.md). Tool-specific statements here are grounded in [the source register](../../provenance/SOURCES.md). Native command syntax must be capability-probed and version-pinned before deployment.

## 1. The coverage tensor, not one score

A record belongs to a target revision, capability/component, language/runtime, platform, feature/build profile, assurance family and metric. The applicability manifest declares every required coordinate before measurement. This keeps a successful Linux core library run from concealing an untested Windows CLI or macOS app integration.

Use three independent perspectives:

| Perspective | Numerator | Denominator | What it establishes |
|---|---|---|---|
| Structural execution | Unique executable lines/functions/branches observed | Full eligible structural inventory for that profile | Instrumented execution breadth |
| Behavioral assurance | Obligations with passed meaningful assertions and valid evidence | Approved behaviors, boundaries, failures and invariants | Contract coverage |
| Oracle sensitivity | Unique seeded defects/mutants correctly rejected | Eligible non-equivalent defects under a declared experiment | Ability of tests/gates to detect selected faults |

Also publish all mandatory selected checks and their result. A 100/100 test pass report can still cover only 12/100 obligations. An execution report can hit 98% of lines while asserting almost nothing. A mutation score from a tiny unrepresentative slice does not establish repository-wide adequacy.

## 2. Denominator authority and anti-gaming

Inventory the subject from accepted intent, public exports, build manifests, generated interfaces, dependency boundaries, operations and actual code. The inventory cannot be derived only from files loaded during tests. Include eligible zero-hit modules. Keep generated, vendored, platform-ineligible and obsolete content separately accounted for, with rationale and provenance. Never exclude a file because its tests fail or it is difficult to instrument.

Maintain two scopes: the full retained product/capability inventory and the bounded target release/experiment. Deferrals remain visible in the full inventory; they are not erased by publishing a smaller target. Migrations carry requirement IDs and evidence lineage to the destination. A new path is not a new clean denominator.

Approve denominator changes before recomputing a score: source/module addition, legitimate removal, supported-platform change, dead-code deletion, codegen regeneration, compiler branch accounting, or a new critical obligation. Preserve old/new manifests and review rationale. Check deletion of tests and reduction of exclusions as carefully as code additions.

For small denominators use counts, not rounded reassurance. 17/20 is exactly 85%; 5/6 is 83.33% and fails. 85/101 is below 85. Branchless code yields an explicit no-opportunity review, not a fabricated 100% branch figure.

## 3. Per-family structural attribution

Run suites independently into distinct output roots. Preserve a test inventory associating each test with its family based on what boundaries are exercised, not its filename. A test named `integration` can still mock every boundary. Conversely, a CLI-level test can be a meaningful E2E test of a small CLI product.

Within a family, merge shards only when source commit, binary IDs, toolchain, architecture, profile and denominator agree. This produces the family’s full report. Across families, publish an optional union only as a separate combined view; it never satisfies the individual floors. Do not merge across platform profiles into a fictional universally covered binary.

Use distinct instrumented build/coverage directories per family and target. Clean only owned instrumentation outputs; never `git clean` or remove another worker’s files. Cached profiles are evidence only when their identities and reuse policy are valid. A changed source map or binary ID invalidates the old profile.

Capture child/server processes, plugin hosts, FFI implementations and browser workers where they belong in the scoped workflow. Flush profiles on graceful shutdown and record crashed/unflushed processes as incomplete. Frontend-only JavaScript coverage cannot stand in for the backend. E2E measured against uninstrumented remote services needs service-side instrumentation or explicit measurement blockers.

## 4. Language/tool adapters

| Family | Measurement adapter | Important qualification |
|---|---|---|
| Rust | Pinned cargo-llvm-cov/LLVM native profiles and JSON/LCOV | `--tests` is not synonymous with integration-only. Select actual integration targets and classify suites. Branch support/toolchain restrictions must be verified. |
| Rust application E2E | Instrumented build, public CLI/service/UI execution, collected child profiles | Running a unit-test binary from a shell does not create an application E2E journey. |
| Python | coverage.py branch data with separate family databases/contexts, subprocess collection | Dynamic/static contexts facilitate separation but do not decide test type. Native function coverage may need an explicitly defined additional adapter. |
| JS/TS | Pinned V8/Istanbul tooling and source maps, separate frontend/backend reports | Include unexecuted eligible files and validate source maps. Browser coverage is not whole-system coverage. |
| Web E2E | Playwright plus browser and server instrumentation | Built-in Playwright JS/CSS coverage is Chromium-only. Firefox/WebKit behavior must still be tested; mark structural measurement gaps separately. |
| Go | `go build -cover`/GOCOVERDIR and selected `-coverpkg` packages | Native standard reporting is statement-oriented, not universal branch coverage. Do not rename it branch coverage. |
| C/C++/FFI | Compatible LLVM/gcov instrumentation and executable identifiers | Check compiler/object compatibility and generated binding coverage separately. |
| JVM/.NET | Pinned native ecosystem coverage exporters | Probe exact supported branch/function semantics and child-process collection; no assumed interchangeability. |
| Native mobile/desktop/game | Toolchain-native coverage plus real app instrumentation and platform test harness | Emulators, real devices, engines, drivers and accessibility trees have distinct capability/support requirements. |

These are adapter choices, not a mandate to replace a better local tool. Implement one narrow normalized record adapter per actual report format/version and round-trip test it with saved native fixtures, including malformed and empty reports. Do not infer a missing denominator from “highest line seen.”

## 5. Branches, functions and paths

A branch edge, source region, Boolean condition, MC/DC obligation and full execution path are different units. Report the native unit honestly. A compiler’s source mapping can introduce or eliminate countable opportunities. Pin compiler/instrumentation versions and explain changes before interpreting trends.

Function-entry coverage does not mean every behavior in the function is tested. Branch coverage does not establish all combinations of conditions. Full path coverage may be unbounded with loops. For critical decision logic, add explicit decision tables, state models, MC/DC where appropriate, and property/fault tests. The user’s 85% branch floor is preserved, not extrapolated into an unsupported “all paths” claim.

For this package’s Python reference checker, function entries are a derived AST first-executable-line proxy. The result is labelled as such. It is not claimed to be a native coverage.py function export.

## 6. Beyond the three primary test layers

**Contract/API:** enumerate endpoints, commands, schema variants, consumer/provider versions, error envelopes and compatibility transitions. Test real provider/consumer boundaries. Schema-only acceptance is insufficient for runtime semantics.

**Property/model:** enumerate invariants, input partitions, state transitions and boundaries. Record generator constraints, seeds, shrinking and known counterexamples. An invariant with no generated examples is not covered.

**Mutation:** unique stable mutants; outcomes killed/survived/equivalent/invalid/unbuildable/timed-out/infrastructure-error/not-run. Denominator and mutation-operator families are explicit. Repeated status updates must be idempotent. Count only reliable semantic rejection as kill; investigate survivors and infrastructure errors.

**Fuzz:** all high-risk parsers/decoders/protocol boundaries receive fuzz targets and regression corpora. Track target coverage independently from discovered code coverage. Preserve crashes and minimized inputs. State budgets; absence of crashes during one run does not prove safety.

**Security:** enumerate attack surfaces, authorization transitions, data classifications, adversary actions and supply-chain controls. Code scans, dependency scans, secret scans, malformed inputs and runtime abuse tests are complementary. Required security invariants and unresolved serious findings are hard gates.

**Reliability/chaos:** restart, crash, disconnect, persistence failure, partial writes, timeouts, cancellation, backpressure, resource exhaustion and recovery. Assert durable state and user-visible behavior, not merely process survival.

**Performance/scaling:** enumerate critical operations, offered load, concurrency, cold/warm/cache states, input sizes and failure modes. Measure distributions and tail latency, resources, saturation, sustained load and recovery. Required performance budgets all pass; “85% benchmark coverage” does not permit 15% of mandatory budgets to fail.

**Compatibility/migration:** explicit supported platform/dependency/configuration/consumer matrix. Use pairwise/risk-based designs for combinatorial exploration but do not claim every untested combination passed. Preserve source-target parity and rollback evidence.

**Accessibility/visual:** automated semantics, keyboard/focus, screen-reader, contrast, zoom, reduced motion, responsive rendering, screenshots and calibrated qualitative review. Automated scores alone do not establish WCAG or aesthetic conformance.

**Packaging/operations:** clean install, upgrade, configuration migration, backup/restore, uninstall, rollback, help/version, provenance and actual release assets. Developer-checkout success is not installed-consumer success.

## 7. Honest exceptions and strong stop conditions

A required metric below 85 remains FAIL, even when other families reach 100. A missing report remains UNKNOWN/BLOCKED. A failed mandatory check vetoes acceptance. A deferred noncritical obligation remains in the target/full-product ledger with authorized disposition. An exception is attached to the exact contract/revision and has a real issuer, scope, risk, compensating evidence, expiry and repair owner.

Do not use a blanket exception such as “all integration coverage is hard.” Discover the practical missing instrument or unavailable platform and make that the work package. Do not invent an exception approval in a Markdown template. Legitimate local repairs can proceed while the bounded repository target remains visibly open.
