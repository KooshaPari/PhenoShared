# Metric catalog

Generated from [METRIC-CATALOG.json](METRIC-CATALOG.json). These are default contract obligations, not measured product results. Scope, native capability and criticality require review before deployment.

| ID | Family/metric | Floor | Eligible denominator |
|---|---|---:|---|
| UNIT-LINE | unit / line | 85% | Approved eligible line identities for this independent family/component/platform/profile |
| UNIT-BRANCH | unit / branch | 85% | Approved eligible branch identities for this independent family/component/platform/profile |
| UNIT-FUNCTION | unit / function | 85% | Approved eligible function identities for this independent family/component/platform/profile |
| UNIT-OBLIGATION | unit / obligation | 85% | Approved eligible obligation identities for this independent family/component/platform/profile |
| INTEGRATION-LINE | integration / line | 85% | Approved eligible line identities for this independent family/component/platform/profile |
| INTEGRATION-BRANCH | integration / branch | 85% | Approved eligible branch identities for this independent family/component/platform/profile |
| INTEGRATION-FUNCTION | integration / function | 85% | Approved eligible function identities for this independent family/component/platform/profile |
| INTEGRATION-OBLIGATION | integration / obligation | 85% | Approved eligible obligation identities for this independent family/component/platform/profile |
| E2E-LINE | e2e / line | 85% | Approved eligible line identities for this independent family/component/platform/profile |
| E2E-BRANCH | e2e / branch | 85% | Approved eligible branch identities for this independent family/component/platform/profile |
| E2E-FUNCTION | e2e / function | 85% | Approved eligible function identities for this independent family/component/platform/profile |
| E2E-OBLIGATION | e2e / obligation | 85% | Approved eligible obligation identities for this independent family/component/platform/profile |
| CONTRACT-OBL | contract / obligation | 85% | Approved provider/consumer endpoints, schema cases, compatibility and error obligations |
| PROPERTY-OBL | property / obligation | 85% | Approved invariants, boundaries, partitions and state-transition properties |
| FUZZ-OBL | fuzz / obligation | 85% | Declared fuzzable risk targets/grammars/hazards; not all possible inputs |
| MUTATION-KILL | mutation / mutation_kill | 85% | Unique eligible non-equivalent mutants; invalid/errored outcomes separately reported |
| SECURITY-OBL | security / obligation | 85% | Reviewed attack surfaces and security control obligations |
| RELIABILITY-OBL | reliability / obligation | 85% | Fault, exhaustion, cancellation, restart and recovery scenarios |
| PERFORMANCE-OBL | performance / obligation | 85% | Declared operations and load/size/concurrency/contention profiles |
| COMPAT-OBL | compatibility / obligation | 85% | Declared supported platform/version/consumer scenarios |
| A11Y-OBL | accessibility / obligation | 85% | Applicable automated and qualitative accessibility checks |
| VISUAL-OBL | visual / obligation | 85% | Declared UI states, rendering profiles and visual/qualitative outcomes |
| DOCS-OBL | documentation / obligation | 85% | Approved noncritical topic/contract/journey inventory |
| SOTA-OBL | sota / obligation | 85% | Applicable researched dimensions and scoped comparison obligations |
| PILOT-OBL | pilot / obligation | 85% | Predeclared noncritical exploratory experimental cells |
| QE-OBL | quality_engineering / obligation | 85% | Instrumentation, fixtures, hermeticity, failure controls and adapter contracts |
| QA-OBL | process / obligation | 85% | Approved preventive quality and review controls |
| INTENT-LINKS | intent / obligation | 100% | Every material in-scope requirement/decision with valid source or labelled engineering derivation |
| DOCS-MANDATORY | documentation / obligation | 100% | Mandatory artifact classes and critical/publicly promised contracts/examples |
| TOOLING-REQUIRED | tooling / obligation | 100% | Actually required integrations, including positive/negative consumer contracts |
| STATIC-REQUIRED | static_analysis / obligation | 100% | Mandatory compiler/linter/type/security static checks and actual selections |
| OPERATIONS-REQUIRED | operations / obligation | 100% | Mandatory install/release/upgrade/rollback/recovery scenarios |
| MIGRATION-REQUIRED | migration / obligation | 100% | All source capability dispositions and retained consumer/parity/custody obligations |

Every critical subset is 100% and mandatory checks all pass. Unsupported native metrics remain blocked or explicitly excepted; they are not silently dropped. Denominator discovery, judgment and actual approval are outside the reference checker.
