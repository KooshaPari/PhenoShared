# Applying the contract to the reported three-repository batch

This is an acceptance design, not new measurement of these repositories. Existing PR details come from the supplied prior handoff and correction; refresh current heads, accepted decisions and actual evidence before execution. Do not treat older provisional topology proposals as approvals.

## PhenoProc: a library can have real E2E tests

The earlier PR #75 bounded framed UDS messages. That is a useful repair but not the denominator for the whole retained process/IPC target. Recover the actual accepted target: process lifecycle/pools, queues, shared memory and Unix sockets only where those components are genuinely retained and released.

**Unit coverage:** each component's native line/function/branch report and behavioral obligations, including framing length validation, overflow/conversion, queue policy, lifetime ownership, state transitions and cancellation logic. Explicitly test message boundaries at zero, exact maximum, one beyond maximum and protocol extremes. Critical allocation-before-validation and state-preservation behavior needs complete direct assertion coverage.

**Integration coverage:** real runtime and OS boundary interactions: socket fragmentation, truncated length/payload, peer closure, invalid encoding, persistence/backpressure, process exit, cancellation and cleanup. For an oversized frame, specify whether the connection is discarded, poisoned or safely recoverable; rejecting the length alone does not define subsequent stream synchronization. Use unique temporary paths and explicit teardown to avoid parallel-suite collision. Timeouts must cause test failure, not be discarded.

**E2E coverage:** compile or install a real consumer fixture against the candidate artifact and exercise its public API/CLI/service contract across actual processes. For a library without a GUI, the user journey is consuming the package: build, configure, run legitimate messages/work, reject unsafe inputs and recover as promised. Instrument relevant consumer-loaded implementation without relabelling mocked unit code as E2E. Public ABI/API and protocol changes need consumer compatibility checks. Do not invent a CLI that the product does not promise merely to obtain an E2E test name.

**Other obligations:** mutation of bounds and cleanup, fuzzing of risky framing/parsing, concurrency/property invariants, supported platform behavior, memory/throughput/tail latency and contention, clean package consumption, examples, diagnostics, and integration docs. Report each metric separately. A maximum-message policy should appear in the public contract, negative tests and examples where relevant.

**Pilot:** compare one bounded application job against a competent direct implementation or relevant process/IPC alternative. Evaluate correctness and failure semantics before raw throughput. Account for code/configuration/recovery burden and testability. Do not pretend a single socket microbenchmark proves every process-library advantage.

## phenotype-gfx: package and consumer paths, not only lib tests

The earlier PR #20 protects resident data when persistence fails. Retain and integrate that repair through the actual permitted workflow. The scope question is whether the target is a retained shared graphics library, an incubation experiment, or a decomposition into product owners; resolve that from current accepted decisions.

For retained capabilities, map native source inventory, public APIs, persistence/streaming/state invariants, and actual supported bindings/engine consumers. If C ABI, Unity, Bevy or another integration is in the accepted contract, include its build/consumer path explicitly; the presence of a feature flag alone is not validated support.

Unit tests should directly assert state on failed persistence/eviction and count/priority invariants. Integration tests exercise actual storage and relevant engine/binding boundaries. E2E uses a packaged consumer loading/streaming/rendering or otherwise consuming the capability through the advertised path. Pair structured state/output assertions with visual evidence; a screenshot alone does not establish persistence safety or correct frame content.

Independently collect at least 85% line/branch/function and obligation coverage per required suite/profile where measurable. Include concurrency, crash/restart, corrupted assets, pressure/backpressure, high/low detail transitions and consumer compatibility where promised. The list is a design seed, not permission to expand the product arbitrarily.

A shared-library incubation pilot must demonstrate its accepted consumer/use-case criterion and a reason to retain a shared boundary. Historical “two consumers” suggestions are not automatically a binding mandate. Measure any engine/graphics performance in matched uninstrumented builds and separate correctness runs from contention benchmarks.

## phenotype-gateway: do not revive a historical donor for a numeric score

If the currently accepted role is a historical mirror after completed absorption, runtime unit/integration/E2E percentages are not the right new-work target. Verify source capability inventory, exact successor evidence, provenance, history/attribution, contract/consumer migration, trustworthy redirects, conflicting authority claims and authorized lifecycle state. Required preservation and migration obligations are fully accounted for; no silent loss in an uncovered 15%.

A working link into HexaKit does not itself prove functional parity, accepted ownership or GitHub archive state. Reuse valid prior absorption evidence rather than repeat work. If unique live capability remains, record the contradiction and assign an actual source-target-consumer work package. Do not decide the successor solely by the newest README or this package's example.

## Required report

For each of the three: accepted role/target, current baseline, claimed and independently verified work, independent metric counts, critical gaps, documentation/provenance/SOTA/pilot status, tool-adoption receipts, remaining integration/consumer/lifecycle actions, named owners and next ready authorized task. Missing measurements are UNKNOWN or BLOCKED. A small complete repair is a child result, not a repository completion percentage.
