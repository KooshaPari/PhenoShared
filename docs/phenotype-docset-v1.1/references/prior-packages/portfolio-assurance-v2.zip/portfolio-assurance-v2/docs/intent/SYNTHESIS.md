# Intent synthesis and interpretation boundary

The human source is [USER-PROMPT.md](USER-PROMPT.md). Earlier outcome-ownership rules are retained in [the prior correction](../../provenance/EXECUTION-CORRECTION.v1.md).

## Confirmed directives

The 85% floor applies independently to unit, integration, end-to-end, and other applicable assurance families. Combined coverage is not a substitute. The direction is toward 85–100%, not a cosmetic “has tests” gate. Documentation, intent provenance, current SOTA research, actual adoption of PhenoDocs/AgilePlus and related systems, and comparative case studies remain part of the delivered outcome. Use concrete repository evidence and preserve superior existing systems. Continue the portfolio-shaping and usable-product mission rather than restarting a fleet-wide documentation exercise.

## Operational interpretations proposed here

Coverage requires independently defined denominators. Structural line/branch/function coverage, behavioral obligation coverage, actual test success, and oracle adequacy are different records. The 85% minimum is retained; critical obligations and mandatory checks require 100%. A noncritical numeric floor does not permit knowingly broken required behavior. Every contract must be predeclared, versioned and protected against unilateral denominator shrinkage.

Existing stronger thresholds remain stronger. A below-floor baseline remains open while repair work progresses. An authorized narrow PR can be a useful child deliverable without implying repository closure. Unsupported instrumentation is a visible measurement blocker or separately approved exception, not permission for a worker to omit the metric.

## Not inferred or authorized

This instruction does not authorize edits to other agents’ repositories, bypassing checks, new service subscriptions, secret disclosure, arbitrary personal-history scraping, remote repository creation/retirement, merges, deployments, or unlimited load on foreground machines. It does not establish that all existing toolkit commands implement their advertised semantics. It does not create a universal claim that all possible behaviors are now known or tested.

## Competing interpretations considered

1. One aggregate percentage for all tests: rejected; contradicts “EACH”.
2. 85% pass rate: rejected; coverage is breadth, not tolerance for failed required checks.
3. 85% journey enumeration replacing E2E code coverage: rejected as a silent weakening; retain both where measurable and report unsupported structural metrics explicitly.
4. Demand 85% of every arbitrary Cartesian platform/input combination: rejected as an undefined universe; enumerate and review the support/obligation matrix first.
5. Require every archived donor to become a production application: rejected; preservation, parity and lifecycle acceptance are the relevant gates.
6. Force all ecosystem backends online before a small tool can ship: rejected; required integration must be real, but optional integrations remain separately gated.

## Delta-only adoption

Each coordinator reads this contract once, maps it onto the current version of local standards, and dispatches missing measurements or repairs. Do not rewrite passing, higher-fidelity artifacts. Do not erase accepted capability scope to reach a numerical target. All currently unsupported closure claims must be corrected while valid work stays intact.
