# Human source — latest coverage and assurance instruction

Source: current conversation, user message received for this response. No original per-message timestamp was supplied. This is not a device scrape. The body below preserves the visible user text; the surrounding metadata is generated.

## Verbatim body

I skimmed correction so forgive me, agents should also be ensuring 85-100% coverage level against any evaluation\QA QC QE\test type; e.g. for tests EACH of e2e\integ\unit\othr at 85%+, 

similar sort of case for docs + usage of our phenodocs, agileplus, and other tooling\sytems\proceesses also docs/sota docs/intent scraping as needed for the later and research for the former, and so on, + the case study \ pilot and other items we discussed and more you can and should derive from our GitHub, web, and chats\memories heavily.

if allowed in this session use subagents otherwise just take as long as you need and collect as much and refine\iter as much as possible b4 return
