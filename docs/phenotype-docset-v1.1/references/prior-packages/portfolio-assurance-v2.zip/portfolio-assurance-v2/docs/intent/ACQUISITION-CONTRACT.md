# Intent acquisition, recovery and freshness

The existing HexaKit intent model is a strong starting point; preserve its turn-level sources, synthesis and assumptions [GH-HEX-INTENT in SOURCES](../../provenance/SOURCES.md). Make fidelity and acquisition coverage explicit rather than assuming that a scrape command succeeded completely.

## 1. Scope acquisition before reading data

The worker receives authorized device/tool roots, repository or project context, relevant time window and permitted output destinations. Current repository instructions and explicit permissions control access. The existence of a broad user home directory does not authorize bulk collection of unrelated messages or credentials. Use legitimate export/connectors and access controls; no bypasses.

Resolve actual installed versions and log schemas. Cursor, Forgecode, Codex, Claude and other tools do not guarantee identical paths or envelopes. Where source access is unavailable, record the limitation and the exact acquisition request. Never reconstruct original human wording from memory or an assistant’s old summary.

## 2. Four representations, four identities

1. **Raw source evidence:** immutable bytes or a source-native export, retained in its authorized private store.
2. **Decoded human message:** exact source text with ordered content blocks and contextual metadata; decoding/version recorded.
3. **Normalized/redacted projection:** explicit transformation pipeline for search or safe publication; separate digest and source links.
4. **Synthesis/requirements:** model/human interpretation with provenance, confidence, supersession and authority status.

A hash detects later changes to the representation it covers. It does not prove the representation is faithful to a source that was never captured. Do not call stripped/joined text byte-verbatim. Do not publish hashes of secret values as a substitute for secret handling. The public artifact may need to omit raw identifiers or retain only a protected reference.

## 3. Required record fields

Use existing richer schemas or an explicit adapter. Minimum semantic fields: source tool/version, device/source identifier, repository ID/context, session ID, turn/event ID, source timestamp plus origin/confidence, capture timestamp, raw/source digest/reference, extracted representation digest, parser version, normalization/redaction flags, authorization scope, relevant related prompt IDs and extraction errors.

Capture `message_created_at` separately from file modified time, scrape time and ingestion time. Never reorder two unknown-time messages by invented precise timestamps. A short “yes”, “not that”, or “85% each” inherits context from its relevant session; keyword-only filtering can lose decisive corrections. Preserve explicit human versus agent roles and tool outputs as different sources.

## 4. Acquisition coverage and reconciliation

Declare the discoverable authorized source inventory. Count accessible sources, sources scanned, records parsed, selected user messages, duplicates, rejected noise, malformed records, unreadable inputs and missing exports. Coverage can be measured against that bounded inventory. It cannot assert possession of every conversation ever held on every device.

Deduplicate by stable source/event identity where possible, not only text hash: identical text in different turns may carry different context or approval meaning. Preserve relationships rather than deleting history. Mark old goals superseded only by evidence of an actual decision; chronological recency alone is not sufficient authority.

Map all in-scope material requirements and major scope changes to explicit human sources, accepted decisions, or clearly labelled engineering-derived obligations. Safety/compatibility requirements derived from engineering need their own rationale, not a fabricated user quote. Every confirmed goal has valid grounding; every inference remains identifiable.

## 5. Triggers and negative tests

Refresh when a new major feature, scope correction, migration decision, charter change, significant source gap or discovered historical divergence matters. Use incremental cursors/digests to avoid repeated full-device scrapes. Document both successful refresh and scope not covered.

Required tests include: whitespace and Unicode fidelity; multi-block ordering; omitted or ambiguous timestamps; cross-platform time zones; malformed/truncated JSONL; identical turns in multiple exports; short follow-up correction; false-positive repository keyword; assistant text misidentified as human; secret-bearing message; missing permissions; and generated output attempting to overwrite the original source.

A parse error or inaccessible source must lower the coverage status or produce a blocker, not silently disappear. The system must detect the seeded missing-source fixture before it can claim a reliable acquisition gate.
