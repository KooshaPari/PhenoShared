# Delivery, scheduling and acceptance under the stronger quality floor

## 1. No restart and no shrinking parent scope

Apply this as a delta to existing work. Keep the useful repair PRs, accepted architecture, valid tests, exact prompt captures and stronger local standards. Do not regenerate every document or re-run a complete historical audit if its evidence remains applicable. Find the missing assurance cells and trustworthy-tool gaps, assign them, and continue.

Coordinator-owned target records link accepted disposition, immutable baseline, bounded release/migration/experiment, source-target-consumer owners, capabilities, applicable test families, numeric floors, hard invariants, tool integrations, pilot, authorized actions and closure reviewer. A worker’s “three repositories” is a write/WIP envelope, not a self-contained migration graph.

## 2. Ready work versus blocking work

Use separate fields for hard artifact/contract dependencies, priority, resource exclusion, write lease, review action and external service block. Do not encode a preferred alphabetical or smallest-first order as a false dependency chain. A blocker must identify the exact unavailable credential, owner decision, device, shared repair or authorization and its wakeup condition.

Local inherited defects that block the target remain in the target backlog. Put them in separate focused PRs where appropriate. An unchanged file on main proves neither harmlessness nor that the same hosted failure occurred under comparable conditions. Reproduce or retain comparable base/head evidence before attribution.

A task can finish while a repository remains open. An agent waiting on one PR can continue another safe ready task under its existing scope. When no useful authorized task remains, return an owned blocker packet and release the slot. The coordinator retains residual responsibility until another owner acknowledges it.

## 3. Incremental delivery and 85% floors

The target-compliance bar does not require every first repair PR to magically raise a large legacy product from 15% to 85%. It does require honest status and a plan that gets there. Existing required CI and security controls must not be bypassed. Under already accepted incremental-merge policy, a non-regressing useful patch with necessary direct tests may integrate while the target is explicitly below floor. This is progress, not G3/G5 closure.

Do not create an informal coverage waiver. Approval belongs to the existing authorized gate/exception owner. Keep whole-target, changed-code and critical-path metrics separately. A high changed-line percentage cannot substitute for the low whole-target independent families.

Before accepting a target, validate the final integrated/release revision under its declared support matrix. A pull-request synthetic merge, commit head, default-branch head and packaged release are different artifacts; record which was measured. Reuse evidence only through an explicit compatibility/impact policy.

## 4. Roles determine terminal work

- Retained product/library: meaningful contract, independent unit/integration/E2E and other applicable assurance, installable result, operations and bounded case study.
- Migration donor: complete capability/provenance inventory and accepted disposition; retained behavior parity, consumer cutover, rollback, licenses and lifecycle. No revival just to add production tests to dead code.
- Migration destination: imported capability is reachable, tested and packaged, with source history and contracts carried forward.
- Incubator: agreed experiment, honest evidence, cost/TTL and accepted graduation/absorption/stop decision. No fake production claim.
- Reference/fork: accurate role, upstream/delta, bounded compatibility/security/support obligations; evaluate only what is promised.
- Docs/tooling home: actual publication/control/tool contracts and examples, not invented application features to populate tests.

## 5. Resource scheduling

Global admission counts active targets, review backlog, simultaneous heavy tests and shared services—not just agents. One operator with nine workers does not have nine isolated GPUs, interfaces, package registries or deployment windows. Protect interactive work, game/audio latency and sufficient disk/RAM.

Use leases for GPU/display/audio device, ports, shared mutable test accounts, emulator instances and deployment fixtures. Give heavy compiler/coverage/mutation/fuzz jobs bounded CPU, memory, I/O, duration and cleanup rules. Pause or route background work elsewhere under the agreed operating policy. Never clean unrelated worktrees to free space. Capture timing but do not turn estimates into fabricated completion predictions.

## 6. Gate cadence

Fast feedback: deterministic unit/static/contract selection and meaningful changed-scope checks. Before acceptance: independent full required-family reports for the target. Scheduled depth: fuzz, mutation, load/soak, recovery and supported-platform jobs under explicit expiry/reuse. Production/hosted controls remain enforced as configured; no file-exists surrogate.

A scheduled result counts only for its bound revision/profile or approved reuse window. A stale nightly report cannot silently validate newly changed critical code. Missing tool/data/hardware is BLOCKED, never “assumed pass.”

## 7. Coordinator acceptance record

For each outcome, record: exact subject and target; accepted role; all required families and metric counts; critical obligations; current and inherited defects; doc/provenance/SOTA/pilot status; actual integration receipts; test provenance and negative controls; immutable PR/integration/release references; remaining approved deferrals/exceptions; final authorized reviewer result.

A strict target acceptance is the conjunction of all required results, not an average grade. The reference checker verifies only normalized records and integrity; it cannot authenticate this review, discover missing requirements, prove the native producer truthful, or perform remote lifecycle actions.
