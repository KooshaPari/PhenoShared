# Outcome-gap report — use actual facts, leave unknowns explicit

Repository ID / immutable subject / target / role / accepted decision / owner:

| Family | Metric | Component/platform/profile | Covered / eligible | Floor | Critical gaps | Required test outcomes | Native evidence | Status |
|---|---|---|---|---|---|---|---|---|
| unit | line / branch / function / behavior (separate rows) | UNKNOWN | UNKNOWN | >=85, stricter if accepted | UNKNOWN | NOT_RUN | Missing | OPEN |
| integration | separate metrics | UNKNOWN | UNKNOWN | >=85 | UNKNOWN | NOT_RUN | Missing | OPEN |
| e2e | separate metrics | UNKNOWN | UNKNOWN | >=85 | UNKNOWN | NOT_RUN | Missing | OPEN |

Add all other applicable QA/QC/QE and test families. Do not collapse rows to averages.

Docs/intent/SOTA/pilot coverage and actual tool-adoption receipts:

Work-package / PR / integration / repository-target / migration / portfolio statuses:

Inherited and new blockers, owner, exact next action and wakeup condition:

Next ready authorized work package, required negative oracle, permission and resource limit:

Closure/exception reviewer and actual decision receipt (not a typed approval claim):
