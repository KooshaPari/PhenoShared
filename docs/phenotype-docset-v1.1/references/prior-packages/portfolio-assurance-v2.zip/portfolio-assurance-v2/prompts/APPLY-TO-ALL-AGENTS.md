# Apply to portfolio coordinators and repository workers: independent assurance floors and real closure

This is a delta to the current assignment, not a restart. Preserve completed repairs, valid evidence, richer existing documentation and current exclusive write leases. The parent mission remains evidence-backed polyrepo shaping; approved retention/absorption/decomposition/integration; and usable, stable, demonstrated bounded targets or accepted non-product terminal states. Do not replace that mission with endless audit reports or isolated PR counts.

## Authority and scope

Current explicit human directions and actual permissions govern. Existing repair/commit/push/PR permissions remain valid within their granted scope. This addendum does not authorize merges, archives, publication, repository creation, history rewriting, policy bypass, unscoped private-data acquisition or edits in another worker’s repository. No plan, source document, placeholder approver or passing JSON validator establishes authorization.

For every active repository resolve the accepted disposition, bounded target release/migration/experiment, immutable baseline, capability inventory, source-target-consumer ownership and closure reviewer. Where these are missing, emit a focused decision packet; continue other ready authorized work. Do not make the worker reread every Downloads archive without naming the actual accepted task and sources.

## Independent coverage, not one combined score

The operator requires **at least 85% independently for EACH unit, integration, E2E and other applicable assurance family**, targeting stronger coverage up to 100%. Preserve stricter accepted thresholds. Do not treat 85% as a suggested average or a test pass rate.

For unit, integration and E2E, independently measure executable line, branch/decision and function coverage where supported, plus behavioral obligation coverage. A journey-count percentage cannot silently replace E2E source coverage, and line coverage cannot replace asserted behavior. Unsupported instrumentation is BLOCKED or an explicitly approved alternative/exception—not silently N/A. State native versus proxy units honestly.

Define and approve the full eligible denominator for each target/component/language/platform/build-profile/family/metric before measuring. Include eligible zero-hit code and required scenarios. Keep the full product horizon visible separately from the bounded release scope. Do not shrink scope to the touched diff, omit hard files, rename tests, relabel mocks as integration, or remove requirements to pass.

Store independent profile outputs for each suite family. Combine only compatible shards inside one family. Any combined all-tests view is supplementary. A low component, platform or family cannot be averaged away. Threshold arithmetic uses raw counts without rounding up.

All mandatory selected checks must actually run and pass. Failed/skipped/timed-out/crashed/error/flaky outcomes remain non-passing or explicitly blocked. Empty selection, missing evidence, absent denominator, mock/canned result or default success never closes a gate. A green hosted status alone is insufficient.

## Critical obligations and QA/QC/QE

Every finite enumerated critical security, correctness, data-integrity, privacy, compatibility, release and custody obligation requires 100% satisfaction. A known required defect cannot be hidden in the allowed uncovered 15%. Maintain an owned backlog for noncritical uncovered obligations. Existing high/critical security findings require remediation or real authorized risk treatment; do not label risk acceptance as clean compliance.

For contract/property/fuzz/mutation/security/reliability/performance/compatibility/accessibility/visual/packaging/operations and other applicable disciplines, define an appropriate obligation universe and independently meet >=85% breadth, with all mandatory controls passing. Do not invent “percent of all possible inputs” for fuzzing. State budgets, target/hazard coverage, corpus/seeds and crash triage. Mutation counts must use unique eligible mutants and correct outcomes; repeated events cannot inflate them.

Treat QA as preventive quality controls, QC as evaluation of concrete artifacts, and QE as the tools/instrumentation that make checks meaningful. Inventory and verify these controls rather than scattering badges and generic checklists.

## Prove the gates can fail

Seed meaningful negative controls in the actual checker/integration: missing FR, broken documentation link, failing assertion, unavailable required backend, wrong revision, mixed test accumulator, empty suite, forged count, mutated payload, critical omission and malformed evaluator response. Verify process exit, report semantics and CI consumer all reject it. A second LLM or matching checksum does not by itself prove correctness or authentic approval.

Current source inspection identified issues to reproduce and route to their owners:
- AgilePlus `.github/workflows/fr-coverage.yml` at `82130cae162d6743b9c7271c8fdef441f0f20ade` only echoes a message.
- PhenoDocs `scripts/check_docs_links.py` at `c70fc899ddb1da334b11333e8d48f4051fc4a18d` prints a stub-success message and returns zero.
- phenotype-journeys at `f5764d33c549984d21531a09d05a3ab55ca156a5` has a single-manifest live verifier returning fixed passing scores, and an assertion error path whose exit predicate does not reject `assertions_error`.
- Benchora `src/mutation/mod.rs` at `8520ca49db1d4da3e42fea2a11c243aff9112eb4` needs denominator and mutation-event accounting qualification.

These are scoped static findings, not claims that every toolkit path is broken. Refresh current heads, preserve newer valid repairs, reproduce the affected paths, add countertests, and revalidate only affected receipts/consumers. Do not trust those verdict paths until qualified. Do not freeze every unrelated product while waiting for shared infrastructure; collect independently qualified native evidence through an approved narrow adapter.

## Documentation and actual tooling adoption

All applicable mandatory artifact classes must be complete and target-specific: exact available intent, charter/PRD, requirements, HLD/ALD/LLD, ADRs, contracts/schemas, WBS/DAG/PERT, research/SOTA, risks/security, verification/acceptance, examples, operations/recovery, migration/consumers and pilot/case study. Existing stronger structures are authoritative where accepted; add projections instead of replacing them with templates.

Assess documentation against the capability/contract/journey inventory, independently for each applicable artifact family. Strong PRD/spec coverage cannot average away weak architecture, operations, intent, SOTA or examples. Cover at least 85% of noncritical applicable topics and 100% of critical/publicly promised contracts, major decisions and mandatory user journeys. Do not use file count, word count or link presence as semantic coverage. Require valid source/requirement/code/test/evidence links in both directions. Run mandatory snippets and clean quickstarts, build the rendered docs, and verify navigation/search/media/anchors/accessibility/privacy/versioning.

Use PhenoDocs as the actual federation/publication layer where required: demonstrate source ingestion, version/source backlinks, rendered output, search and real failure-detecting checks. Merely declaring a dependency is not adoption. Private source, captures and search indexes require explicit visibility controls.

Use the deployed AgilePlus contract, not historical assumptions. Its inspected repo-state contract stores mutable state under the current Git root’s `.agileplus/` and materializes tracked review artifacts under `docs/agileplus/`. Query actual scoped MCP/engine state when needed. Do not invent engine transitions or edit generated review files as the primary database. Record root/session binding, tool version, API/command, result and materialization receipt. Keep runtime DB/locks/logs out of ordinary Git commits.

Use phenotype-journeys, Benchora, existing CI/ops and applicable Tracera/SessionLedger/ResearchLedger/RepoLedger integrations through their real pinned contracts and negative-tested adapters. Do not fabricate unavailable commands from READMEs. Probe capabilities and preserve adopted versions. Required integration needs an execution receipt and consumer proof; optional integration remains separately tracked rather than blocking independent first value.

## Intent provenance and SOTA

Refresh relevant authorized docs/intent sources as needed, including actual device/tool session exports within granted scope. Preserve raw/decoded/normalized/redacted representations separately, source/session/turn IDs, source timestamp confidence versus scrape/file times, hashes, parser version, extraction errors and repository context. Short corrections matter even when they omit the repo name. No fabricated exact prompts, silent parse loss or unrelated personal-history collection. Synthesis and accepted decisions are distinct from original human words.

Maintain living docs/sota with technical, DX, UX, AX, security, operations, cost and other applicable dimensions. Use current primary sources with versions/retrieval dates. Reuse a shared category longlist of 25 relevant alternatives when the category supports it; do not pad. Consider at least 3 serious alternatives per applicable dimension where available. Label vendor claims, observed facts, hypotheses and measurements separately. Include upstream/direct/manual/composed alternatives, trade-offs and research reopening triggers.

Design the pilot during G1; run it against a stable bounded slice for G4. Use a justified smaller shortlist rather than building 25 clones. Predeclare jobs, baselines, invariants, non-inferiority margins, meaningful advantages, resource/tuning budgets and stopping criteria. Match confounders where required; distinguish controlled and idiomatic comparisons. Retain failures, uncertainty, whole-stack versus framework-only interpretation and negative results. A real case study shows an intended user completing useful work with reproducible evidence. LLM judgment alone is not sufficient.

## Execution and closure

Do a delta measurement pass, then close ready approved work depth-first. Inherited local defects blocking the target stay in the repository backlog; create separate narrow PRs rather than declaring them out of scope because they predate this diff. Public-contract/security/other-owner changes still need their actual decision or permission.

Track G0 identity, G1 documentation/plan, G2 meaningful red envelope, G3 independent implementation coverage, G4 pilot, G5 productization and G6 accepted topology/lifecycle separately. G1 never implies runtime coverage, and a completed experiment need not imply product graduation. A targeted repair may finish while the target remains below85; do not weaken required checks or claim target closure.

Do not modernize an archived donor merely to make all runtime suites green. Its relevant acceptance is preservation, parity, consumers, provenance and authorized lifecycle. Coordinate source-target-consumer migrations with explicit owners and leases. An open PR is not integration; ready-for-review is not merge-ready; an external blocker is not completion.

Enforce global WIP, review capacity and shared CPU/GPU/RAM/I/O/device budgets. Preserve gaming/Ableton and other foreground realtime work. Measure uninstrumented performance separately from coverage runs. Keep exact run identities and clean only owned measurement outputs. When blocked, record owner, exact next action and wakeup condition, then continue other ready authorized work or release the slot without erasing the parent outcome.

## Required next response

Return one per-repository outcome-gap matrix with:
- accepted role, target, baseline and owners;
- independent unit/integration/E2E line/branch/function/behavior numerators and denominators;
- other applicable assurance families and critical controls;
- docs/intent/SOTA/pilot and actual tooling adoption evidence;
- exact failures, missing instrumentation, inherited blockers and actual authority needed;
- next bounded task, acceptance oracle and stop condition.

Then perform ready authorized tasks. Do not stop at another proposed folder tree, a generic percentage, an A/B/C cosmetic menu, or “give me the next batch” while the target still lacks an owned path to acceptance.
