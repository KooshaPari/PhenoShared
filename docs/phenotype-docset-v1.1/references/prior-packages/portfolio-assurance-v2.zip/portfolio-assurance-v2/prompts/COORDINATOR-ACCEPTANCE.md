# Coordinator acceptance and dispatch

Use the [agent addendum](APPLY-TO-ALL-AGENTS.md) with the accepted existing task contract. This checklist helps the coordinator supply facts workers should not guess.

## Before dispatch

Resolve current operator permissions and cross-worker leases. Name the accepted role/target and immutable baseline. Identify all retained capabilities, source/target/consumer responsibilities and the reviewer. Provide authoritative files and engine/API state references, not an unbounded instruction to read all Downloads.

Approve the measurement contract: required cells across component/language/platform/profile/family/metric; eligible inventory and exclusions; critical obligations; floor `max(85, accepted stronger policy)`; mandatory checks; tool versions; evidence format; expiry/impact reuse; negative controls. Keep the full product scope visible alongside the bounded release.

For actual AgilePlus records, verify root binding and current version. Do not centrally overwrite product-local engine state or treat a generated file as a transition receipt. For PhenoDocs and other integrations, state which are required now and which remain separately optional; do not let the worker reclassify them after failure.

## Dispatch envelope

An actionable packet contains subject repository ID and full commit, accepted target/decision ID, capability/obligation IDs, source and destination ownership if applicable, exclusive write scope, next bounded work package, prerequisites, authorized actions, resource limits, expected native reports and negative controls, review/merge/publication owner, rollback and abort conditions.

If there is no accepted disposition, dispatch a bounded decision investigation rather than pretending a proposed source-target map is approved. Let other safe useful repairs continue. Do not block the entire fleet on the complete future RepoLedger product.

## Acceptance order

1. Confirm correct subject/artifact/profile and valid permissions.
2. Confirm complete applicable inventory and no unapproved denominator shrinkage.
3. Inspect raw native reports and exact test selection/execution; reject skipped/empty/error/default-success paths.
4. Enforce independent coverage floors, every critical obligation and every mandatory check.
5. Verify oracle sensitivity, not only executed line percentages.
6. Check truthful docs/intent/SOTA, actual required integrations, pilot/case study and release/operations for the target stage.
7. Confirm source-target-consumer obligations and accepted lifecycle action where relevant.
8. Record independent review and remaining deferrals/exceptions without converting them into perfect status.

The outcome is accepted only for the named target, source/artifact/profile and stage. A lower stage can close while a later stage remains open. A useful task can close while its repository remains below floor. No average grade may hide a required failed cell.

## Required portfolio roll-up

Show admitted active targets, immutable baselines, child work, coverage matrix, failed critical controls, tooling blockers, review queue, migration owners and next wakeups. Count completed useful targets and actual consumer value—not files written or number of PRs. Separate raw repository count from operational burden and canonical authority. Revisit topology only when new evidence requires it.
