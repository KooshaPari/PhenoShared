# Synthetic normalization example

The bundle contains synthetic measurement records and fictitious fixture identities. It is NOT a report about portfolio coverage and grants no approval. The controller-digest example below is illustrative; in production the trusted digest must originate outside worker-controlled evidence. Regenerate timestamps using the fixture builder before trying it after its 24-hour demonstration window.

Use `tests/support.py:write_bundle` only for reference tests. Do not publish these fixture counts as real results.
