# Portfolio assurance v2 — independent coverage, trustworthy gates, real product closure

This package strengthens the existing portfolio execution correction. It does not replace the portfolio’s product boundaries, repository-local SSOTs, or worker permissions. Read [the contract](ASSURANCE-CONTRACT.md), then use [the self-contained agent addendum](prompts/APPLY-TO-ALL-AGENTS.md).

The operator’s floor is preserved: **unit, integration and E2E each independently >=85%**, with separately defined structural and behavioral metrics. Other applicable assurance families also receive their own inventories and floors. Required checks and critical obligations need 100% satisfaction. Combined coverage, source-file counts, successful command invocation and mock scores cannot substitute.

## Start here

1. Coordinator: reconcile this delta against existing accepted targets and stronger local policies. Use [coordinator acceptance](prompts/COORDINATOR-ACCEPTANCE.md).
2. Worker: inventory missing measurements and follow ready authorized work, preserving useful repairs and richer docs. Do not restart the whole audit.
3. Shared-tool owner: inspect [source findings](docs/tooling/SOURCE-FINDINGS.md) and qualify the gates before downstream adoption.
4. Verifier: run negative controls and assess scoped evidence, not completion claims.

## Main documents

- [Applying this to the three-repository batch](docs/coverage/THREE-REPO-APPLICATION.md)
- [Measurement specification](docs/coverage/MEASUREMENT-SPEC.md)
- [Metric catalog](docs/coverage/METRIC-CATALOG.md)
- [Tool integration map](docs/tooling/INTEGRATION-MAP.md)
- [Intent acquisition](docs/intent/ACQUISITION-CONTRACT.md)
- [SOTA and pilots](docs/research/SOTA-AND-PILOTS.md)
- [Scheduling and release gates](docs/operations/DELIVERY-AND-SCHEDULING.md)
- [Meta-oracle tests](docs/verification/META-ORACLE-TEST-PLAN.md)
- [Actual validation results](docs/verification/VALIDATION.md)
- [Source register](provenance/SOURCES.md)
- [Targeted work packages](work/WORK-PACKAGES.md)

## Reference checker

`reference/assurance.py` is a small normalization/integrity reference, not a replacement for native coverage tools, AgilePlus, Benchora, or an authenticated CI gate. Its runtime profile requires all three test layers with line, branch, function and obligation cells. The controller must independently approve and pin the denominator contract. Native adapters and actual producer identity remain outside this checker.

```sh
python -m unittest discover -s tests -t . -v
python scripts/measure_reference.py
python scripts/validate_package.py
```

The examples are deliberately synthetic. A generated valid fixture is not a real product test receipt. See [reference limits](docs/verification/REFERENCE-LIMITS.md) before integrating. No command here authorizes GitHub mutation or queries a live AgilePlus engine. Install `coverage` and `jsonschema` in an isolated environment for measurement/schema validation; the core CLI uses only Python’s standard library.

## Delivery facts

Targeted read-only GitHub inspection was performed; the actual portfolio products were not built, benchmarked or scored in this session. Four relevant main tips were checked against the inspected revisions. The reference checker’s own unit, integration and real-process CLI suites were run separately; logs/native coverage exports are included. The archive is a strengthened execution handoff and targeted repair plan—not a declaration that the portfolio passes.
