# Validation report

Date: 2026-09-09 policy date. Executed in the attached artifact workspace, not the source repositories.

## Executed

- Python 3.13.5; jsonschema 4.26.0.
- `python scripts/validate_package.py`: structure consistent; all parsed JSON, four planning schemas/examples, unique IDs, source/work/spec/obligation references, relative Markdown file targets, intent hash, and two source-capture hashes checked.
- Hard dependency graph and the conservative union of conditional dependencies are acyclic. Real PERT forecast is intentionally unavailable because packet estimates remain uncalibrated. The formula and slack computation were tested on a labelled synthetic DAG.
- `python -m unittest discover -s tests -v`: **31 tests passed**. Tests cover schema rejection, required references, concept-versus-evidence distinction, capture/privacy claims, release/install/provenance references, normalized routes, missing/invalid estimates, graph errors, relative links and CLI failure propagation.
- Source captures' SHA-256 and Git blob OIDs match their recorded source identities. Prior assurance archive copy is byte-identical to its input hash.
- Final archive/member checks and the self-excluding inventory/checksum manifest are produced by packaging, with the exact counts in [package-summary.json](package-summary.json).

## Limits

This is **not** independent unit/integration/E2E qualification of a new deployed runtime, nor coverage certification of any source repository. The helper is package QC; [reference limits](../docs/verification/REFERENCE-LIMITS.md) remain explicit. No native product build or full hosted check suite was run. No real screenshots/creative assets, releases, signing, publication, provider settings changes, DNS updates, installed-consumer tests or infrastructure restores were produced here.

The package has 18 source findings/open questions, 28 bounded work packages, 62 finite acceptance obligations, 6 authored specification bundles and 8 ADRs. Findings include source-confirmed behavior, design/authority questions, historical revalidation and access/coverage gaps; they are not 18 proven runtime defects.

No external action is authorized by a valid manifest. Metadata integrity is not semantic truth or authenticated approval. Revalidate live heads, actual tool versions and granted permissions before execution.

## Rerun

Use an existing approved Python environment with `jsonschema` available. The tested validation dependency is pinned in [requirements-validation.txt](../requirements-validation.txt); no global installation is required by this package.

```sh
python scripts/validate_package.py
python -m unittest discover -s tests -v
```

Raw local test output: [tests.txt](tests.txt). Machine result: [package-validation.json](package-validation.json).
