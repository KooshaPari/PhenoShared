# Intent synthesis and decision boundary

The latest human direction changes the delivery scope, not the existing source-protection rules. PhenoDocs and AgilePlus are **reusable tools**, not canonical repositories of the whole portfolio. Product-owned documentation, intent and work state remain with their owners; deployable sites are configured consumers. This resolves their *role*, not the complete path-by-path extraction map.

The requested target is a reusable release and presentation system: PhenoDocs-generated docs on GitHub Pages and a `phenotype.space` subpath; the existing generic landing repository supplying the Vercel-hosted `phenotype.space` site; product-level deployments mapped under `pheno.studio`; real release builds and distribution; complete applicable CI/CD, GitOps/operations, QA, planning, research and traceability; private non-disruptive journey capture; and rich, editable brand/media assets including VHS demonstrations for non-GUI products.

## Explicit versus proposed

| Subject | Status |
|---|---|
| PhenoDocs/AgilePlus are tooling, not portfolio registries | Explicit human direction; reflected in AgilePlus source contract [G12] |
| Use existing generic landing repo with Vercel | Explicit; `phenotype-landing` is the identified source candidate [G02, G08] |
| Marketing/docs domain `phenotype.space`, product domain `pheno.studio` | Explicit target, not evidence of DNS or deployed account configuration |
| Exact route `/<slug>/docs/<version>/` | Proposed implementation convention |
| App host `<slug>.pheno.studio` | Proposed default; use approved existing app hosts where appropriate |
| Isolated journey captures and real product screenshots | Explicit; isolation is visible operational policy, not stealth |
| Blender and Adobe available on device | User-reported availability; installed paths, license entitlements and automation still require local probe |
| Independently >=85% per assurance family, critical/mandatory 100% | Retained from preceding explicit direction and assurance v2 |
| Production DNS, publishing, merges, paid services | No new execution authorization from this audit-and-plan request |

## Scope interpretation

“Everything but the code itself” means *everything surrounding domain-feature implementation*, not a prohibition on the engineering code needed to implement and verify tooling, pipelines, assets, schemas and adapters. A broken link checker must be fixed in code. PhenoDocs is itself a tool product: finishing its agreed generated/federated views is implementation work in that tool's delivery stream. Do not claim it can be completed by writing another plan alone.

We reject two extremes: waiting for every product feature before preparing delivery, and calling a synthetic release/screenshot a shipped product. Independent readiness work closes now; every implementation-dependent acceptance item remains attached to the specific product capability with an owner and trigger.

## Competing explanations to test

Some apparent pollution may be intentional self-dogfood, generic fixtures, historical custody, or a configured example. Classify before moving. Some future entries may already be implemented with stale prose. Trace each claim into source/build/tests before creating duplicates. The literal word “future” in an API comment is not a backlog item. A current app domain may already be correct; preserve it instead of forcing a cosmetic rename.

Source: [USER-PROMPT.txt](USER-PROMPT.txt), [PROVENANCE.json](PROVENANCE.json), and the preceding assurance contract preserved in the provenance archive. External and repository citations use IDs from [SOURCES.md](../../references/SOURCES.md).
