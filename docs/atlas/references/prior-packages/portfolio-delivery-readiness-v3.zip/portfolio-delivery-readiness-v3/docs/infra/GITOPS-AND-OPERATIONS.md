# Infrastructure, GitOps and operations completion

## Correct scope

Infrastructure includes runner images, machines/VMs, network, DNS/TLS, storage, artifact retention, secrets, package registries, deployment targets, observability, backup/restore and incident recovery. Writing a workflow file does not prove those resources exist or work.

OpenGitOps defines declarative, versioned/immutable desired state pulled and continuously reconciled by software [W14]. A one-shot Git-triggered push deployment is CI/CD; it should not be labelled full GitOps without reconciliation. Use GitOps where it fits. Do not add Kubernetes/Argo/Flux solely for a static docs portal or simple desktop installer.

## Required inventory and controls

Maintain actual resource IDs and current/desired state with provider, owner, region/trust zone, purpose, support cost, exposure, backups, retention, drift and last verified evidence. Existing infra/config repositories remain owners where accepted. This document does not award authority to whichever repo has the most generic name.

Before changes, capture provider settings and rollback, separate private state from public source, identify live dependencies and verify credentials through least-privilege capability probes. A dry-run/plan validates intent within its limits; it does not prove apply or recovery. Real apply/alias/DNS/service changes require scoped authority.

## Runner architecture

Use separate pools for untrusted PRs, trusted build/sign/publish, native GUI capture and large compute. Worktrees are not credential sandboxes. Do not mount the operator's full home, Docker socket, SSH agent, browser profile or production vault into capture/build containers. Use narrow read-only source mounts, owned writable outputs, ephemeral credentials, resource controls and explicit network allowlists where appropriate.

Bootstrap images reproducibly with versioned tool definitions. Native GUI/Adobe sessions require isolated authorized users/VMs and entitlements, not an assumption that every desktop app runs in Linux containers. At teardown, preserve required evidence first, revoke ephemeral credentials, clean only owned resources and prove no orphan process/port/device route remains.

## Backup and recovery

Define RPO/RTO for actual state classes as agreed targets. Test restore of scoped AgilePlus database state, artifact metadata, release manifests, critical runtime databases and config/DNS snapshots. A Git bundle preserves repository history within its limits; it does not preserve uncommitted files, database state, provider secrets, issues or every local reflog. Retain those separately under their allowed privacy policy.

A backup is not accepted until restore verifies integrity and a representative public workflow. Encrypted retention needs key custody and recovery. Migration cutover must preserve source until target verification and rollback windows close.

## Observability and GitOps health

Collect desired/current drift, sync failures, rollout status, service health, certificate expiry, external dependency failures, publication errors and resource saturation. Alerts need owner and action, not a wall of emails nobody reads. Record permission failures distinctly from product defects. Use cost/retention budgets and expiry for previews/captures to prevent abandoned cloud resources.

## Boundary and negative controls

No plan-generated record may claim a resource created, a DNS name owned, a license available, a service reachable, a secret rotated or a backup restored without a real receipt. Missing production credentials may block final deployment but not local package tests. Availability of a public URL says nothing about authenticated private workflows.

Test revoked token, lost network, backend unavailable, duplicate apply, configuration drift, deleted desired resource, stale lease, partial rollout, full disk, failed backup, corrupt restore and rollback. Maintain break-glass instructions without embedding credentials. All required results remain tied to environment and source baseline.
