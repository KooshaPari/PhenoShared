# Delivery risk and mitigation register

| ID | Risk | Control and owner |
|---|---|---|
| R01 | Tools remain polluted with active unrelated records | Subject owner map, external consumer, staged migration; tool/family owners |
| R02 | Raw private prompts/screens reach public site/index | Pre-render allowlist, private fixtures, derivative policy; publication/security owner |
| R03 | Green badge from ignored/empty checks | Native negative controls through final gate; QE/workflow owner |
| R04 | Dummy/wrong artifact attested and distributed | Expected subject inspection/digest chain, clean consumer; release owner |
| R05 | Domain reorganization breaks working apps/callbacks | Before/after map, staged parity, legacy aliases, rollback; infra/app owners |
| R06 | Native GUI/Adobe worker cannot run headless/containerized | Probe actual host/permissions/license; native profile; capture owner |
| R07 | Capture/render disrupts foreground games/audio | Global resource/session leases, queue admission, pause/abort; fleet owner |
| R08 | Fonts/stock/material rights invalid | Source inventory and item-specific rights; creative owner |
| R09 | 3D/animation damages performance/accessibility | Placement budgets, lazy load/poster/reduced motion, actual devices; design owner |
| R10 | Nine agents modify shared tool/lockfile simultaneously | Exclusive paths/leases, paired source/consumer WPs; coordinators |
| R11 | Registry/hosting plan does not permit intended use | Actual entitlement/plan read, no assumed free SaaS use; operator |
| R12 | Cancelling concurrent release leaves partial publication | Idempotent staged transaction, unique version lease; release owner |
| R13 | Database/central-state extraction loses audit history | Consistent backups, export/import reconciliation and restore; data owner |
| R14 | Synthetic canary or concept image called real product | Explicit origin/state, subject receipt, no marketing proof substitution; verifier |
| R15 | Docs source stale but deployed with new product | Source/artifact/version link and impact invalidation; docs/release owner |
| R16 | Repeated safety bureaucracy blocks all useful work | Minimum local contract, owned blockers, qualified adapters, depth-first closure; coordinator |
| R17 | Pipeline optimization drops platforms/coverage | Fixed support inventory, full final qualification and A/B checks; QE owner |
| R18 | Historical archive is needlessly revived for percent targets | Role-aware acceptance and donor/target parity; family adjudicator |

Risks are open planned controls, not assertions that a mitigation has been implemented. Add probability/impact estimates only after the scoped owner has real environment evidence; do not invent portfolio-wide monetary or calendar forecasts.
