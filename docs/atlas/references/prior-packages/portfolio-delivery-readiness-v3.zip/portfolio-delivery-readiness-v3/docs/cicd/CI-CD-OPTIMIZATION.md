# CI/CD correctness, optimization and workload admission

Optimization target: faster **trustworthy** delivery with less duplicate computation, not fewer visible failures. The inspected tool/site CI templates turn many failures into warnings and use weak root-only detection [G03, G09]. A quick green badge from skipped nested packages is not an optimization.

## Stage 1: make the dependency graph correct

Inventory real packages, nested sites, toolchains, reusable workflows and supported build profiles. Derive affected targets from source/config/lockfile/interface dependencies, not a single root manifest. A change to shared theme, renderer, schema, pipeline, lockfile or exported API expands its consumer closure. Unknown impact runs the conservative required set. Keep scheduled/full-final qualification as a backstop.

Expose one authoritative status per required obligation. Map each check name to exact behavior and evidence. Correct mismatched `needs` keys; fail on unexpected empty/unknown results; distinguish justified N/A from absent execution. Ensure an always-running aggregator actively tests dependency results rather than echoing success. Diagnostic advisory jobs may exist, but their output cannot satisfy required obligations.

## Stage 2: reuse only compatible work

Use frozen lockfiles, pinned toolchains/runners and explicit cache keys covering OS/arch/compiler/features/dependency/config/profile. Separate untrusted PR, trusted main and publication caches. Dependency caches and compiled-object caches are different; neither may contain credentials. Do not fall back from a deterministic install to an uncontrolled dependency update because the lock is stale. Repair the lock in a scoped reviewed task.

Preserve independent unit/integration/E2E accumulators. Combine shards only within a compatible family/revision/profile. Avoid reusing a stale coverage report for a new source file or namespace. Cache negative results only under an explicit policy; do not cache permanent success from a broken checker.

## Stage 3: remove duplicate overhead, not controls

Compare GitHub Actions, Vercel native builds, Trunk, other CI, Mergify and security services by the specific job they perform. Consolidate redundant format/lint/build passes where equivalent, retain specialized security/compatibility checks where useful. Do not indiscriminately disable all third-party controls to make required checks pass. One owner controls shared policy; platform-local enforcement remains where needed.

Run cheap syntax/schema/secret checks early. Batch independent package tests inside measured resource limits. Use cancellation for superseded untrusted preview/test work, not in-progress production publishing. Separate release artifacts from test scratch outputs. Keep native runners for required platform behavior and identify what cross-compilation does not verify.

## Stage 4: global resource budgets

The user's workstation can simultaneously run games, Ableton, agents and builds. Per-agent concurrency limits are insufficient: create global leases for GPU render/capture, native interactive sessions, audio devices, RAM-heavy linking, expensive tests and constrained storage. Default background work cannot seize keyboard focus, system speakers or microphone. Return thermal/memory pressure signals to the coordinator; pause queued noncritical renders rather than degrading live audio.

Measure queue wait, p50/p95 time-to-first-actionable-failure, final qualification duration, cache hit rates, retry/flake rate, worker utilization, CPU/GPU seconds, memory/I/O peak and bytes transferred. Estimate expected improvement before optimizing; keep an A/B baseline and a rollback. No unmeasured “10x faster” claims.

## Merge and final-head semantics

Review readiness, required-check success, merge readiness, actual merge, release qualification and product acceptance are separate. A merge queue must test the actual candidate composition or revalidate the final integrated source under the approved policy. A useful inherited-defect repair may proceed under existing incremental permissions without falsely certifying the whole repo at 85%.

## Required adversarial tests

Missing package discovery; nested-site failure; changed shared dependency; invalid lock; poisoned/untrusted cache; unknown dependency result; failed job masked by echo; empty test selection; branch-only report reuse; mixed suite profiles; superseded preview; concurrent release events; credential failure; private capture accidentally uploaded. The expected terminal result is an explicit failing/blocked gate, not cosmetic success.
