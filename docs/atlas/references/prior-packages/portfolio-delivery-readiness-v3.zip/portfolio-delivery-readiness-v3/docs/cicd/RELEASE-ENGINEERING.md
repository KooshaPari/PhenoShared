# Release engineering and packaging

## Define the real distribution units

A repository is not necessarily one package, and an application is not necessarily a hosted service. Inventory libraries/crates, CLI binaries, desktop installers, mobile packages, services/images, static sites, SDKs/bindings, examples and plugin bundles. Each has explicit supported OS/arch/runtime/ABI, version policy, installer/package identity, license notices, release owner, update/migration behavior and required consumer proof.

Do not publish a private root package merely to create a release badge. Do not attest a text placeholder as a real build. The inspected PhenoDocs attestation workflow currently builds `dist/artifact` containing a dummy string and supplies a shell expression as an action input [G04]. Fix the actual build subject and bind provenance to its digest through the provider's supported `subject-path` or precomputed output mechanism [W04].

## Release sequence

```text
approved source + dependency/toolchain/config lock
 -> unprivileged build
 -> independent unit/integration/E2E and other required checks
 -> package / native installer / image / static variant
 -> inventory + licenses + SBOM + artifact identity
 -> signing/notarization where required
 -> clean consumer install and update/rollback qualification
 -> staged channel and verification
 -> authorized publication / alias promotion
 -> external clean download/install verification
 -> release/case-study/docs evidence update
```

The exact order of package tests and platform signing differs by platform; record which subject was tested and ensure the actual distributed subject is checked. Keep timing/performance runs separate from heavy coverage instrumentation. Preserve failed runs and first-attempt status.

## Role-specific outputs

| Type | Mandatory useful artifacts | No automatic obligation |
|---|---|---|
| CLI | Supported archives/installers, checksums, completions/man/help/config, release notes, VHS proof | Always-on web app |
| Library/SDK | Published package or verified source-consumption contract, API docs, clean consumer projects, ABI/semver tests | Invented standalone UI |
| Desktop | Native supported packages, update/signing policy, permissions and clean-user install/launch/remove proof | Cross-compile-only proof of native runtime |
| Service | Immutable image/binary, config/secrets contract, health/readiness, migrations, graceful stop, backup/restore | Vercel hosting regardless of workload |
| Static docs/site | Qualified static artifact and deployment receipt | Fake binary/package release |
| Research/reference | Reproducible experiment/custody bundle and honest status | Production badge or all-platform installers |

Select native ecosystem tools rather than writing a universal packager. Existing release tooling has priority when it satisfies the contract. GoReleaser is a candidate for compatible binary packaging; verify the chosen feature set is in its available edition [W16]. Rust, Python and JS package publishers should use the actual package manager's dry-run/build/validation and trusted publishing mechanisms where supported. Exact provider features require source and installed-version checks; this plan does not authorize a new dependency or paid plan.

## Immutability, idempotency and rollback

One release coordinator per package/version/channel. A tag event and release event must not both independently produce divergent uploads for the same version. Do not cancel a production promotion midway just because a newer commit arrived. Use resumable staged operations and explicit locks. Never overwrite previously published bytes under the same immutable version. If withdrawal is necessary, follow registry policy and publish a corrected version/notice.

Rollback must identify binary/site/image predecessor and data compatibility. Restore databases from verified backups or use tested forward/backward schema steps; `git revert` is not data recovery. Preserve download URLs and upgrade paths during repository migration. Domain aliases and package identifiers have separate lifecycle obligations.

## Supply-chain evidence

Collect expected outputs, executable/package inspection, dependency inventory/SBOM, license/notice bundle, signed provenance where available, source-to-binary relationship and verifier invocation. A signature authenticates a signer or build lineage, not absence of vulnerabilities or truthful behavior. Secrets stay outside build logs, caches and artifacts. Review untrusted action code, scripts and event inputs before privileged use [W15].

Every required release target must complete clean-install and user-level verification at the actual candidate. Missing signing entitlements, unsupported OS runners or registry authority are named blockers, not silently “future work.” Fix independent scaffolding now and retain exact downstream blockers.
