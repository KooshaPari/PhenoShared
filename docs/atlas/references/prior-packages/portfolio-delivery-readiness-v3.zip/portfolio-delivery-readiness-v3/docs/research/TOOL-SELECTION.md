# Tool selection and local qualification

This is a focused adoption shortlist, not an assertion that every program is installed or that one product is universally best. Use pinned existing tools when they meet the contract. No installation or paid purchase happened in this session.

| Capability | Initial choice | Alternative or escape hatch | Qualification |
|---|---|---|---|
| Docs rendering/federation | PhenoDocs, existing VitePress components | Native VitePress adapter until blocked tool path is repaired | External consumer, real failure checks, path/version/privacy [G01–G07] |
| Scoped work/evidence | Actual AgilePlus engine | Read-only exported state while connection is blocked, not fabricated state | Correct root, two-project isolation, actual receipts [G11–G12] |
| Web screenshots/traces | Playwright | Browser/platform-native recorder for unsupported surface | Installed browser pin, semantics, isolation [W08–W09] |
| CLI recordings | VHS | Text transcript plus approved alternate terminal capture | Real binary, clean exit/output oracle [W10] |
| Native screen capture | Approved native capture or isolated OBS profile | Dedicated hardware/VM test display | No personal desktop exposure; capture API compatibility [W21] |
| 3D artwork | Blender background pipeline | Existing suitable licensed renderer | Editable source, deterministic inputs, safe runner [W11] |
| Layered pixel artwork | Krita or available Photoshop | Existing raster/vector tools after probe | Source projects, export and rights [W12, W20] |
| 2.5D/motion composition | Blender/compositor or available After Effects | Static poster plus simpler CSS/SVG animation | Actual export support, motion/accessibility budget [W11, W13] |
| Media derivatives | FFmpeg/ffprobe | Native export then inspected transformation | Color/alpha/audio metadata, source/master retention [W18] |
| Binary packaging | Existing native release tool; evaluate GoReleaser where compatible | Existing Rust/Python/JS native packagers | Edition, install/upgrade proof, no gratuitous registry publication [W16] |
| CI and publishing | Existing GitHub Actions + Pages/Vercel consumers | Existing qualified runner/provider adapters | Least privilege, exact source, real result [W01–W04, W15] |
| Infra reconciliation | Existing accepted infrastructure system | Minimal explicit deployment workflow if GitOps is unnecessary | Actual reconciliation/restore, no gratuitous orchestration [W14] |

Additional candidate tools to evaluate only when a concrete gap requires them include Inkscape/vector tooling, image batch processors, diagram renderers, SVG/glTF optimizers, offline package SBOM/signature generators, and compiler caches. Their current feature/license/install compatibility is not established here. Do not turn this into a shopping list or a mandate to replace functioning local tools.

## Free/open-source versus already licensed

A free/open-source executable does not imply free hosting, unlimited CI minutes, redistributable fonts, available signing certificates, or royalty-free stock assets. Existing Adobe access is user-reported; entitlement for automated/network execution must be verified. Vercel Hobby is restricted to non-commercial personal use [W05]. Keep plan/license/installation verification separate from a tool being technically capable.

## Probe record

Tool name, actual path, version, package/source identity, platform, installed plugins/fonts as references, supported CLI/API methods, license/plan entitlement, required privileges, network use, sample command results, a deliberate failure result, and consumers. Repair missing capability once in the appropriate owner and publish a compatible adapter; do not have nine agents install unpinned inconsistent stacks.
