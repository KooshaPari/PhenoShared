# Research, pilots and case studies for delivery

Retain living docs/intent and docs/sota as **subject-owned sources**, not a portfolio dump in the tools. Intent capture uses authorized relevant exports with raw/decoded/normalized/redacted/synthesized identities and complete skipped/error accounting. Keep short corrections and session context. A scraper command or empty prompts directory does not prove acquisition.

SOTA covers technical, DX, UX, agent experience, security, operations, cost, accessibility, interoperability, deployment, licensing and maintenance as applicable. Reuse category research instead of writing the same longlist in every repo. The existing breadth target of 25 relevant alternatives applies to material product categories; this targeted delivery audit is not claiming to have executed a new 25-way comparison for every renderer, recorder and packager. A tool-selection catalog and specific official-source checks are supplied; remaining category breadth belongs in the associated work package, with exclusions and bounded-search limitations.

## Delivery architecture pilot

Compare static composition and independently deployed rewrite federation for two representative docs subjects. Keep content, renderer/theme versions, base-path test cases and media equivalent. Measure build incremental/cold costs, source-to-public latency, cache correctness, private-content isolation, broken-link detection, deployment rollback, contributor effort and failure propagation. A smaller site that silently omits content does not win.

## Capture pilot

For a real CLI and a real GUI/web product, compare available private-environment profiles on reliability, determinism, visual accuracy, contention, privacy and reproducibility. Evaluate cold install, success, failure/recovery and publication. Retain failed captures. A mocked backend cannot prove actual end-to-end behavior; use stubs only for explicitly scoped harness tests.

## Product pilot

The delivery system supports the already-required product comparisons, such as Agentora's bounded coding-agent task versus rational frameworks/direct SDK. Freeze jobs, acceptance oracle, baselines, models where appropriate, budget, retry/cache settings, environment and statistical plan. Preserve controlled and idiomatic tracks and report whole-stack effects honestly. Do not attribute a runtime/language advantage solely to the framework.

## Case study

Each independently positioned product needs a real user job, why alternatives were insufficient, architecture/tradeoffs, installation/start-to-value, successful and adverse workflows, evidence-backed metrics, media and limitations. No repository percentage, screenshot count or vendor benchmark can substitute for its own result. Shared/internal libraries may demonstrate reuse or compatibility rather than inventing public novelty.

## Research outcome rules

An inconclusive or negative experiment can close the experiment work package while leaving product or architecture acceptance open. Invalidating a superiority claim requires updating the claim, not tuning the evaluator until it approves. “No worse in any imaginable way” is not an auditable universal requirement; preserve finite mandatory invariants, declared non-inferiority margins and a meaningful improvement or distinct job.

## Current findings as hypotheses to validate

The source-level CI/attestation/no-op issues in this dossier have direct paths and countertests. They should be reproduced at the then-current target head. Historical v2 journey/verifier/measurement findings remain revalidation tasks. Fresh unrelated fixes are preserved. Do not convert all prior findings into permanent accusations or all new badges into proven repair.
