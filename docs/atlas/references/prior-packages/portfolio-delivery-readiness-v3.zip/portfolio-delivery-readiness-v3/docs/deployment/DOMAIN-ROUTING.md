# Domain and publication routing plan

## Roles requested by the operator

Use `phenotype.space` for the existing generic landing/marketing site and its documentation subpages, backed by Vercel. Use GitHub Pages for the required public static docs surface. Use `pheno.studio` for product-level runtime mapping. These roles are accepted human intent; the following exact path convention is a **proposal**, not a performed cutover.

| Surface | Proposed route | Producer |
|---|---|---|
| Portfolio home | `https://phenotype.space/` | Existing `phenotype-landing` configured consumer |
| Product landing | `https://phenotype.space/<slug>/` | Reusable landing templates + owned product content |
| Product docs | `https://phenotype.space/<slug>/docs/<version>/` | PhenoDocs target-specific build |
| Docs discovery | `https://phenotype.space/docs/` | Generated navigation of approved docs subjects |
| Pages docs mirror/standalone | `https://kooshapari.github.io/<repo>/` with version structure inside | Subject-owned Pages consumer config |
| Hosted application | `https://<slug>.pheno.studio/` | Actual product deployment |
| API/service endpoint | Product-specific host/path only where contract requires it | Approved runtime/infra owner |
| CLI/library product | Landing, docs, artifacts; no invented always-on service | Subject repo release producer |

The public home currently exposes several product subdomain links [W17]. The landing README states subpath targets [G02]. Inventory both, including older application domains, API origins, email/DNS records, OAuth callbacks, webhooks, package URLs and bookmarks. Neither source proves the whole live routing topology. Do not redirect a working application URL to a marketing page.

## Prefer static composition, allow deliberate rewrites

Default: build approved docs artifacts with explicit target `site_origin` and `base_path`; compose them with the root landing output in one controlled deployment. Cache source/render work by stable inputs. Pages receives its own target variant. Retain common source and semantic page manifests plus per-variant digests.

Alternative: root Vercel project dispatches product/docs paths to separately deployed origins via explicit rewrites [W02]. This supports independent ownership, but requires verified asset paths, origin headers, redirects, cache isolation and backend availability. Do not point a rewrite at an authentication-bypassed preview and expose private content. A simple `vercel.json` in each subtree does not establish root routing [G08].

DNS routes hosts, not URL path prefixes. Domain/alias decisions belong in explicit provider configuration and tests, not README claims. Do not infer a Pages build from `GITHUB_ACTIONS=true`: GitHub Actions can build artifacts for many providers [G05].

## Security and privacy

Use separate app origins when independently deployed products have different trust/session lifecycles. Define exact CORS/CSRF origins, cookies, CSP, redirect policies and callback allowlists from configuration. A wildcard app host does not justify wildcard cookies or broad credentialed CORS. Preview domains must not have production secrets. Protect private previews with actual access controls; robots exclusions are not authorization.

## Before/transition/after route record

For each route record current observed provider/project/alias/DNS/TLS and evidence, desired target, content/functional parity, immutable candidate deployment, cache policy, approved redirect rule, DNS snapshot/TTL, rollback and owner. Route collisions, case/Unicode slug ambiguity and reserved namespaces fail validation. Unknown provider state remains UNKNOWN.

Cutover: verify candidate under its immutable staging address; test deep links, refresh, fonts/media, search, download integrity, login/logout/callbacks and APIs; approve authority; switch alias/DNS as applicable; verify public routing; monitor and retain previous working deployment. Revert aliases and restore snapshots on failure; data migrations have their own forward/backward plan.

## Hosting constraints

GitHub Pages is for static documentation, not live application backends or bulk private evidence storage [W01, W06]. Keep large raw captures/render masters outside the published site behind a governed artifact store, with optimized public derivatives. Vercel Hobby has a non-commercial personal-use restriction; do not assume that a monetized product qualifies or that paid features/signing/storage are free [W05]. Verify the actual plan and billing authority before final provider acceptance.

No Vercel connection, authenticated DNS inventory or live Pages settings were established in this audit. The available Vercel connector was suggested, not connected. Publication work therefore remains unexecuted.
