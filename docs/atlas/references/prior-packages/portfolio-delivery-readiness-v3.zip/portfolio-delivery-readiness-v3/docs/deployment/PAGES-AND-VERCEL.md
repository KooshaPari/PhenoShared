# Pages and Vercel implementation contract

## GitHub Pages

Use an explicit custom build/upload/deploy workflow for applicable static docs. The build input is a manifest with subject source commit, renderer/package version, theme/asset version, visibility filter, output location and base prefix. Validate links, anchors, examples, search and privacy before uploading. The deploy job needs the documented Pages/OIDC permission and environment model [W01]; its artifacts must originate from the qualified build, not a fresh unrelated build.

Discover actual configured source/action settings, environment protections, domain CNAME/verification and last successful deployment through authorized provider reads. The README's reference to `deploy.yml` returned 404 at the observed PhenoDocs source path; another workflow or hosting setting may exist. Repair claims based on real configuration rather than manufacturing a new duplicate pipeline.

## Vercel landing consumer

Discover the actual project root, deployment ID, install/build/output configuration, monorepo graph, aliases, preview protection, environment scopes, redirects/rewrites, logs and plan. Use the existing landing source. Root-level discovery must enumerate the intended nested sites instead of deciding that no root package means no JavaScript work.

Choose one authoritative production promotion path. If Vercel native Git builds are used, prevent a second CI path from independently publishing different bytes to the same production alias. If GitHub produces prebuilt output, follow the provider's installed CLI/build-output contract and verify framework/server/runtime assumptions before promotion. No speculative prebuilt command is advertised as already compatible.

## Profile matrix

At minimum, test root static fixture, Pages `/<repo>/`, Vercel `/<slug>/docs/<version>/`, preview under its actual base, and each declared locale. Test route refresh, 404, missing artifact, normalized trailing slash, encoded paths, assets, favicon/touch icon, search chunk URLs, sitemap/canonical links and version switch. Private fixtures must not be exported to public variants.

Different target bases intentionally produce different files. Compare their manifest-declared logical pages and source revisions, not naive byte identity. Apply cache headers per artifact mutability and audience. A preview slug or unreviewed PR must never shadow a production path.

## Publication verification receipt

Record input/output digests, build run, immutable preview/deployment ID, target provider/environment, actor/permission, alias change, smoke commands, HTTP responses, artifact download identity, verified timestamp and rollback address. Fetching a 200 page alone does not prove all documentation links or application workflows work. Store provider IDs without secrets.

## Delivery stop conditions

Stop promotion on failed mandatory acceptance, visibility mismatch, missing target artifacts, unknown signed subject, stale baseline, namespace collision, absent owner approval, unsafe database transition or an unverified live dependency. Preserve candidate artifacts and concise diagnostics so the next agent continues rather than restarting.
