# Package validation limits

The included Python helper checks this dossier's structure, link targets, source references, work graph, authored-spec crosslinks and planning-schema examples. It includes negative controls for dishonest state combinations and tests PERT arithmetic on synthetic tasks.

It does not run native product tests, attest a real binary, authenticate a producer or reviewer, verify a cloud deployment, scan all secrets/licenses, crawl external URLs, validate every Markdown anchor, or judge visual quality. It intentionally reports `PACKAGE_STRUCTURE_CONSISTENT`, never approval of the portfolio or a product. Its synthetic tests are not a claim that all source repositories meet the independent v2 assurance floors.

Richer production checks must remain in the qualified owning tooling and CI pipelines. This helper is not a new registry, portfolio service or approval engine. Do not promote it into one merely because it has a test suite.
