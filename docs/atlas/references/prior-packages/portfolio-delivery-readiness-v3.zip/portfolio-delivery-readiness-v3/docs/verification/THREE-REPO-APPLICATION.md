# Applying delivery readiness to the reported three-repository batch

These are role-sensitive plans, not newly verified dispositions. Reconcile actual accepted decisions and current worker changes first.

## phenotype-gateway

Where the accepted outcome is a historical donor/reference, do not generate a new product site, fake gateway screenshots, new service, or modern runtime test campaign solely to raise a completion score. Verify exact source capabilities, custody, consumer/target parity, truthful README/source links, license obligations and intended hosting lifecycle. Publish a clear archive/reference page only where useful and approved. A redirect working is not proof that functionality migrated. The target owner supplies any required runtime capture and release evidence.

## phenotype-gfx

Where retained as a shared library/incubator, publish actual source/API docs, supported engine/ABI/build profiles, valid package/install instructions and meaningful consumer demonstrations. Real graphics consumers must render actual behavior; a generic 3D cube is not proof of the library's intended geometry or streaming contract. Decorative Blender art is separate from actual rendering evidence. Capture relevant GPU/native platforms through isolated sessions, not assumed browser/headless equivalence. Keep memory, latency, color and correctness requirements explicit. Complete existing required CI/release defects rather than treating PR #20 as product closure.

## PhenoProc

Publish process/IPC contracts and role boundaries, package/consumer examples, compatibility/security requirements, independent suites and benchmarks. VHS records a real consumer program using the public API and intended process interaction. Do not make a web dashboard merely for screenshots. Verify machine-safe CLI output where one exists and actual library installation/import otherwise. The 16 MiB UDS change discussed earlier is a public behavior constraint needing consumer acceptance, not merely a three-test success. Current code and PR state were not refreshed in this audit.

For all three, existing worker permissions and shared-tool leases remain. Documentation/capture/release tasks should extend the accepted target, not recreate obsolete independent products or bypass the coordinating migration decision.
