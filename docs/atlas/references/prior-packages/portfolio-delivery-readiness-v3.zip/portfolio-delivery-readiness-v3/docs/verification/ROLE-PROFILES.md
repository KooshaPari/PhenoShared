# Role-specific readiness and nonapplicability

| Role | Close before domain-feature implementation | Must wait for actual candidate |
|---|---|---|
| CLI | Contract, source docs, install matrix, terminal brand, tape/oracle design, CI/release adapters | Real installation, independent coverage, useful-task VHS and external package validation |
| Library/SDK | Consumer API/examples, ABI/semver matrix, docs, package pipeline | Consumer builds, real integration/E2E, registry availability and behavior |
| GUI/web/desktop | IA/brand source, capture scenarios, runtime/route matrix, environment pipelines | Real screens/journeys, accessibility, native installs, app/data workflows |
| Shared tool | Generic contracts, self-docs, external fixture and pipeline | Actual tool implementation and two-consumer proof; tooling code is not exempt |
| Service/GPU runtime | Infra/capacity/security plans, deployment/recovery adapters | Native service execution, perf/contention, state restore and real endpoints |
| Incubator | Question, research/source set, falsification plan, bounded demo pipeline | Experiment result and accepted graduation/absorption/stop outcome |
| Historical donor | Custody/map/rights/redirect plan | Accepted successor parity and authorized lifecycle verification; no fake runtime modernization |

A dependency on unfinished product code must identify the exact missing capability and owning work package. Broad “awaiting implementation” without an acceptance oracle is not execution-ready planning. A missing cloud credential does not block a local docs build. A stub screenshot does not close a final product-media gate.

## Reporting matrix per repository

Role/target; accepted decision; immutable source; tool versions/root; required coverage family cells; artifacts/classes; proposed versus observed route; build/package/install/signing; private capture and native support; brand source/license/export; SOTA/pilot/case study; rollback; actual engine and provider receipts; stage; blocker ID/owner/next action. Report first useful outcome as a bounded release rather than calling the lifetime roadmap complete.
