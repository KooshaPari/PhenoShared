# Cross-traceability and evidence invalidation

Use existing canonical IDs and adapters; do not create a new authoritative portfolio ledger to consume this dossier.

```text
human source -> accepted intent/constraint -> requirement
 -> architecture/ADR -> bounded work package -> implementation/tool adapter
 -> verification obligation -> actual run -> artifact/capture/asset
 -> published route/package -> clean consumer/case-study outcome
```

Reverse queries must find public behavior without a requirement, a requirement with no evidence, a published route without an artifact, an artifact without a qualified build, a screenshot without a real subject, a rich asset without rights/source, a migrated source without a destination or accepted retirement, and a product claim whose evidence was invalidated.

## Identity distinctions

A source commit, artifact hash, build run, test profile, screenshot, data seed, software version, deployment ID and domain alias are different identities. Keep links rather than pretending one SHA identifies all of them. A blob hash validates source bytes but not which complete repository revision was executed.

## Freshness

Changes in subject behavior, dependencies, toolchain, capture profile, brand/assets, renderer, base path, private filter, release config or runtime route invalidate the affected evidence. Reuse unaffected evidence only through an explicit compatibility/impact rule. An unchanged screenshot may still become misleading when its public claim changes. Post-merge/final candidate verification follows the accepted release policy.

## Counts and percentages

The machine catalog in this package lists finite obligations, not the total mathematical state space. Counts are for planning. Runtime acceptance retains the independent v2 measurement cells and mandatory-check conjunction. Missing evidence is UNKNOWN/BLOCKED, never 0/0=100%. A checked document link proves linkage only; it does not prove semantic adequacy.

## Privacy

Keep private source/capture paths out of public backlinks, HTML, scripts, maps, search artifacts, sitemaps and machine indexes. Retain internal access-controlled provenance. Do not expose secrets in hashes/log excerpts or use public artifact stores for private originals. Public derivative records can point to an opaque internal master ID without exposing its location.

## Integration receipt

Record actual tool/API version, scope/root, method/command, subject, inputs, outputs, native result, actor identity, failure controls and provider receipt where applicable. No invented AgilePlus transition or signed approval. Publication is accepted only by the authorized owner after evidence checks, not by a self-issued YAML `approved: true`.
