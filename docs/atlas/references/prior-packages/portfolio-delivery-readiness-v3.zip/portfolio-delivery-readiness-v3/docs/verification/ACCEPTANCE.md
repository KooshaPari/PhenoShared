# Finite acceptance catalog

These 62 obligations describe planned checks, not current compliance. Mandatory checks all pass; critical obligations require complete satisfaction. 85% breadth never permits failure of a mandatory selected check. Instrumentation and evidence remain separate. Product-specific finer denominators are derived from the real support/capability inventory.

| ID | Family | Obligation | Work | Critical |
|---|---|---|---|---|
| ACC-001 | role | Tool subject-state separation | WP02 | True |
| ACC-002 | role | External PhenoDocs consumer | WP04 | True |
| ACC-003 | role | AgilePlus root isolation | WP09 | True |
| ACC-004 | role | Safe pollution migration | WP10 | True |
| ACC-005 | docs | Real link and anchor checks | WP03 | True |
| ACC-006 | docs | Required artifact-family content | WP06 | False |
| ACC-007 | docs | Versioned source federation | WP06 | False |
| ACC-008 | docs | Generated plan/work/spec views | WP06 | False |
| ACC-009 | docs | Generated roadmap/changelog/history | WP06 | False |
| ACC-010 | docs | Accessible WBS/DAG | WP06 | False |
| ACC-011 | docs | Audience-filtered search | WP04 | True |
| ACC-012 | docs | Actual quickstart | WP05 | False |
| ACC-013 | docs | Intent fidelity and acquisition | WP02 | False |
| ACC-014 | docs | Public metadata correctness | WP04 | False |
| ACC-015 | route | Explicit target origin/base | WP07 | True |
| ACC-016 | route | Current alias inventory | WP08 | True |
| ACC-017 | route | Pages artifact deployment | WP13 | True |
| ACC-018 | route | Vercel root composition | WP14 | True |
| ACC-019 | route | Runtime origin isolation | WP15 | True |
| ACC-020 | route | No fictitious runtime for CLI | WP15 | True |
| ACC-021 | route | Cutover and rollback | WP14 | True |
| ACC-022 | release | Real artifact identity | WP16 | True |
| ACC-023 | release | Platform/ABI build matrix | WP16 | True |
| ACC-024 | release | Source/SBOM/notices/provenance | WP16 | True |
| ACC-025 | release | Signing qualification | WP16 | True |
| ACC-026 | release | Clean install and first value | WP17 | True |
| ACC-027 | release | Upgrade and rollback | WP17 | True |
| ACC-028 | release | Registry/channel verification | WP17 | True |
| ACC-029 | release | No double promotion | WP16 | True |
| ACC-030 | ci | Required job discovery | WP11 | True |
| ACC-031 | ci | Failure propagation | WP12 | True |
| ACC-032 | ci | Independent suite floors | WP12 | True |
| ACC-033 | ci | Critical obligations complete | WP12 | True |
| ACC-034 | ci | Frozen install and profile keys | WP27 | False |
| ACC-035 | ci | Final candidate evidence | WP17 | False |
| ACC-036 | ci | Measured optimization | WP27 | False |
| ACC-037 | infra | Least-privilege runner pools | WP18 | True |
| ACC-038 | infra | Native session and resource leases | WP20 | True |
| ACC-039 | infra | Restore actual state | WP18 | True |
| ACC-040 | infra | Drift/reconciliation | WP18 | True |
| ACC-041 | infra | Plan and license entitlement | WP01 | True |
| ACC-042 | capture | Current verifier qualification | WP19 | True |
| ACC-043 | capture | Real subject capture | WP24 | True |
| ACC-044 | capture | Hard assertions and native reports | WP19 | True |
| ACC-045 | capture | Raw and derivative separation | WP24 | True |
| ACC-046 | capture | Private-environment boundary | WP20 | True |
| ACC-047 | capture | VHS real CLI workflow | WP23 | False |
| ACC-048 | capture | Library consumer evidence | WP23 | False |
| ACC-049 | capture | Timeout and cleanup | WP20 | True |
| ACC-050 | asset | Brand source custody | WP21 | False |
| ACC-051 | asset | Editable source and recipes | WP22 | False |
| ACC-052 | asset | Font/stock/material rights | WP22 | True |
| ACC-053 | asset | Appropriate rich asset placement | WP22 | False |
| ACC-054 | asset | Color and format fidelity | WP22 | False |
| ACC-055 | asset | Reduced motion and performance | WP22 | False |
| ACC-056 | asset | Machine-safe terminal brand | WP23 | True |
| ACC-057 | research | Source-backed SOTA | WP25 | False |
| ACC-058 | research | Controlled pilot | WP25 | False |
| ACC-059 | research | Real case study | WP26 | False |
| ACC-060 | trace | Bidirectional cross-layer traceability | WP28 | True |
| ACC-061 | trace | Honest readiness state | WP28 | True |
| ACC-062 | trace | Actual tool adoption receipts | WP28 | True |

## Concrete oracles

### ACC-001 — Tool subject-state separation

No unrelated live portfolio state is owned by the reusable tooling.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-002 — External PhenoDocs consumer

An unrelated owner builds docs with correct own brand, license and source.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-003 — AgilePlus root isolation

Identical feature IDs in two subject roots remain isolated.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-004 — Safe pollution migration

Owned records import with IDs/provenance and verified consumer switch.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-005 — Real link and anchor checks

Seeded broken link/anchor yields failing report, exit and hosted gate.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-006 — Required artifact-family content

PRD, specs, ADRs, architecture, intent/SOTA, work, ops and verification resolve applicable topics.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-007 — Versioned source federation

Two real subjects use pinned source manifests and correct provenance.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-008 — Generated plan/work/spec views

Statuses and owners come from source records, not sample JSON.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-009 — Generated roadmap/changelog/history

Actual revisions/releases and scope distinguish proposed from shipped.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-010 — Accessible WBS/DAG

Graph/table reflect typed edges and reject cycles.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-011 — Audience-filtered search

Private fixture never reaches HTML/search/LLM index/media.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-012 — Actual quickstart

Clean unrelated consumer executes documented commands at claimed version.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-013 — Intent fidelity and acquisition

Raw/human/normalized/redacted/synthesis remain separate with errors and rights.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-014 — Public metadata correctness

No blanket MIT/owner/brand claims on consumers.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-015 — Explicit target origin/base

Root, Pages and Vercel prefixes pass complete route/asset/search fixtures.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-016 — Current alias inventory

Current roles, old links, target mapping and rollback are evidenced or explicitly unknown.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-017 — Pages artifact deployment

Required public static artifact has correct provenance and actual deployment receipt.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-018 — Vercel root composition

Deep docs/landing routes resolve correctly through accepted composition.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-019 — Runtime origin isolation

Actual hosted apps use approved domains, cookies/CORS/callbacks and privacy.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-020 — No fictitious runtime for CLI

Nonhosted role receives docs/artifacts without unnecessary service.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-021 — Cutover and rollback

Candidate parity and previous working target are verified before authorized switch.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-022 — Real artifact identity

Expected executable/package/static subjects exist; dummy or mismatched output rejected.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-023 — Platform/ABI build matrix

Every required OS/arch/ABI package is actually built and inspected.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-024 — Source/SBOM/notices/provenance

Distributed subject maps to source, dependencies and valid rights metadata.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-025 — Signing qualification

Required platform signing/notarization and final-subject verification are demonstrated.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-026 — Clean install and first value

Actual distributed candidate installs and performs the promised task.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-027 — Upgrade and rollback

Configuration/data compatibility and previous-artifact recovery are tested.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-028 — Registry/channel verification

Published version can be fetched from actual authorized channel with matching identity.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-029 — No double promotion

Duplicate events/resumes cannot overwrite a published version or diverge subjects.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-030 — Required job discovery

Nested sites and shared dependencies trigger the correct checks.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-031 — Failure propagation

Injected command and required-job errors reject final gate.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-032 — Independent suite floors

Each applicable unit/integration/E2E metric meets >=85 independently with native reports.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-033 — Critical obligations complete

All mandatory and finite critical obligations pass; aggregate cannot hide failures.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-034 — Frozen install and profile keys

No unlocked install fallback or cross-profile/trust cache mixing.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-035 — Final candidate evidence

Required acceptance maps to final merged/queue/release candidate under approved policy.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-036 — Measured optimization

Reduced resource/latency cost preserves acceptance coverage and oracle behavior.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-037 — Least-privilege runner pools

Untrusted builds cannot access signing/prod/private browser credentials.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-038 — Native session and resource leases

Capture/render respects GPU/CPU/RAM/I/O limits and foreground workloads.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-039 — Restore actual state

Backup restore recovers databases/artifacts/config and a representative workflow.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-040 — Drift/reconciliation

GitOps claims have actual continuous reconciliation; other deployment styles labelled accurately.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-041 — Plan and license entitlement

Actual hosting/creative/signing plan and permission availability confirmed or blocked.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-042 — Current verifier qualification

Negative pixels/semantics, unavailable backend and mock output cannot pass as live.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-043 — Real subject capture

Frames/videos originate from exact candidate and actual implemented workflow.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-044 — Hard assertions and native reports

Assertions check behavior independently of captured success text.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-045 — Raw and derivative separation

Unedited evidence master links to explicit redactions/annotations.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-046 — Private-environment boundary

No unrelated device/account/notification capture, broad mounts or leaked private indexes.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-047 — VHS real CLI workflow

Real install/use/failure workflow recorded with transcript and exit/output verification.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-048 — Library consumer evidence

Actual consumer program proves package use instead of fabricated GUI.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-049 — Timeout and cleanup

Owned evidence preserved; only owned ephemeral resources cleaned and lease released.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-050 — Brand source custody

Actual source/token/license/consumer map established before regeneration.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-051 — Editable source and recipes

Every required authored asset has retained source/project and export recipe.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-052 — Font/stock/material rights

Redistribution rights checked; prohibited font binaries not shipped.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-053 — Appropriate rich asset placement

2D/2.5D/3D chosen for real job; CLI only branding/no fake GUI.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-054 — Color and format fidelity

Color/alpha/tone-map profile and SDR fallback verified for distribution.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-055 — Reduced motion and performance

Posters, captions, motion preferences and loading/resource budgets pass.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-056 — Machine-safe terminal brand

No ASCII/ANSI branding contaminates JSON/MCP/stdout; plain/no-color output works.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-057 — Source-backed SOTA

Claimed edge uses dated/pinned primary sources and explicit alternatives/tradeoffs.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-058 — Controlled pilot

Comparable task/oracles/budgets and raw failed runs retained.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-059 — Real case study

Useful outcome/install/failure story supported by actual captures and evidence.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-060 — Bidirectional cross-layer traceability

Public claim -> subject -> checks -> artifacts -> route/consumer and reverse gaps detected.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-061 — Honest readiness state

Design/canary/product/published/operated states distinct; blockers retain owners.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.

### ACC-062 — Actual tool adoption receipts

Tool version/root/input/output and actual engine/publication receipts attached.

Current status: `PLANNED_NOT_EXECUTED`; role condition: applicable to the accepted bounded subject role/support matrix.
