# Private journey and product-capture factory

## Outcome, not vanity screenshots

Every declared public journey is a scenario with source requirement, exact product artifact, deterministic synthetic data where appropriate, actions, expected semantics and hard assertions. Capture the real product completing that scenario. Save raw stdout/stderr, process exit, trace/network/DOM/API evidence when available, and actual frames/video. A pretty still without a functional oracle is illustration, not end-to-end acceptance.

Use phenotype-journeys extensively as the manifest, capture-adapter and publication-facing evidence layer **after the invoked verifier path is qualified**. Carry forward v2 findings about fixed verdicts and assertion error handling for current-head revalidation. Never label mock or canned scores as live proof. The tool is an adapter; native exit/DOM/API/screenshot oracles remain inspectable.

## Environment profiles

| Profile | Appropriate workloads | Boundaries |
|---|---|---|
| EP-WEB | Browser product, docs and landing | Pinned Playwright/browser in an ephemeral non-root environment; real app backend/fixtures |
| EP-CLI | Terminal product/installer | Private shell/PTY, fixed geometry/locale and fonts, VHS plus hard exit/output checks |
| EP-LINUX-GUI | Linux GUI/TUI requiring display | Compatible virtual display/compositor; verify actual rendering backend and GPU needs |
| EP-WINDOWS | Native Windows GUI/installer/game | Dedicated authorized VM/session; permissions and GPU/driver matched to support contract |
| EP-MAC | Native macOS/Adobe/desktop | Dedicated authorized session/VM where supported; Screen Recording/accessibility consent and entitlement |
| EP-DEVICE | Mobile/hardware/peripheral product | Controlled device/emulator with explicit lease, no personal notifications or unrelated account capture |

A Linux container is not a Windows/macOS GUI host and does not by itself establish security isolation. Playwright documents browser/container version and sandbox requirements [W08]. Native recording can use approved platform capture or isolated OBS profiles [W21]; minimizing an app on the user's desktop is not equivalent to isolation.

## Pipeline

1. Read scenario/permissions and acquire resource lease; verify actual subject digest.
2. Create ephemeral environment with owned mounts/network, no broad home or production credential access.
3. Seed labelled realistic data; fix locale/time zone/view geometry and record nondeterministic dependencies.
4. Install/launch the candidate via the advertised path, not a separate stub.
5. Execute the real workflow; capture failures as failures; run mandatory semantic assertions.
6. Preserve raw evidence masters and per-file hashes. Record all retries and mode/backend identities.
7. Scan for secrets/private paths/PII; create explicitly linked redacted derivatives where approved.
8. Produce screenshots, walkthrough/loop video, transcript/captions and posters from the successful real run, retaining failure diagnosis separately.
9. Validate media and viewer, then publish only audience-approved derivatives after authorized action.
10. Tear down owned resources without deleting user state; verify cleanup and return lease.

## Coverage inventory

Map every required user-facing capability to at least one representative journey; each critical workflow includes meaningful error/recovery coverage. This is scenario coverage, not a substitute for independent E2E source coverage. Library-only products use actual consuming programs. Services use real API/CLI control/observability workflows, not a fake dashboard.

Define selected view states by requirement: first launch, empty/loading/populated states, success, validation errors, connection failure and recovery, settings, accessibility/dark/light/locale support where promised. Do not generate the Cartesian product blindly; use a reviewed risk/support matrix and retain the uncovered list.

## Timing and privacy

Keep evidence video timing unaltered for performance assertions. Promotional time compression is labelled and never used as latency evidence. Record software timestamps separately from visible scanout/input-to-photon claims. Hide secrets by preventing them from entering fixtures/logs first; blurring only the video does not sanitize trace files. A hidden container is a user-nondisruptive workspace, not authorization to capture private activity.

## Publication outputs

Every output references journey ID, source version, capture profile, assertions, original master, edits/redactions, rights, timestamps, and placement. Public evidence pages show real status and scope, not a universal quality score. Missing product implementation or a required platform leaves that scenario blocked with its owning work package.
