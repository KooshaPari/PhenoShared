# Rich asset production: owned source, reproducible exports, honest use

## Begin with placements and existing design custody

Inventory existing assets, brand tokens, templates, scene files, diagrams, original art, fonts, textures, licenses and actual consumer paths. The phenoDesign README declares archival but does not identify a precise successor [G13]. Resolve source custody before regenerating a competing brand system or unarchiving that repo. Prefer retained high-quality assets and the existing accepted visual language.

Each asset serves a placement: product mark, app icon, social/OG card, documentation illustration, onboarding panel, terminal identity, interactive hero, empty-state background, tutorial, prompt/reference input, presentation or case-study media. A clever 3D render is optional where it adds no user value. CLI-only products receive branding and real terminal demos; no fake GUI.

## Two pipelines, never conflated

**Evidence pipeline:** actual product pixels/logs -> immutable master -> reviewed redaction -> labelled annotations/crops. Preserve original timestamps and semantics. No generative fill, UI substitution or invented success in evidence.

**Authored pipeline:** approved brief/placement/brand -> editable source -> reproducible export -> visual/accessibility/performance review -> public derivative. Concept artwork and non-shipping UI are visibly labelled. If assets become model prompts/reference inputs, record permissions, model/provider policy and data exposure. Do not upload private captures to a cloud creative service by default.

## Media levels

| Level | Typical source | Outputs | Evaluation |
|---|---|---|---|
| 2D | SVG/vector source, raster layers | SVG, PNG/WebP/AVIF as supported | Readability, scale, contrast, license, bytes |
| 2.5D | Layered composition with camera/parallax | Video, image sequence or validated animation format | Motion comfort, loop/poster, clean fallbacks |
| 3D | Blender scene, geometry, material/lighting data | glTF/GLB for approved interactive use; stills/video | GPU/CPU/VRAM budget, accessibility fallback, source rights |
| Dynamic web | Reviewed renderer/component using approved assets | Responsive interactive scene | Input/reduced-motion/battery/hidden-tab behavior |
| Terminal | Plain text + optional ANSI/Unicode | ASCII/logo/help treatment | Parser safety, no-color, terminal widths |

## Practical production stack

Blender is the first reproducible 3D/render worker; its documented background invocation avoids foreground GUI rendering [W11]. Photoshop UXP can automate supported host operations [W12]; After Effects `aerender` supports scripted render workflows [W13]. These do not imply the entire Adobe suite runs unlicensed in generic Linux containers. The user reports Adobe/Blender availability; workers must probe actual versions, installed fonts/plugins, renderer dependencies and licensing before acceptance.

Use OSS-first tools for shareable automation where they fit: FFmpeg/ffprobe for derivatives and metadata [W18], Krita for editable paint/animation and documented export operations [W20], OBS for suitable native capture profiles [W21], and other approved vector/image/diagram tools after local and primary-source qualification. Existing licensed Adobe is a useful optional production adapter, not a mandatory dependency for every downstream build.

## Reproduction contract

Store source project identity, exact inputs and textures, dependency/version manifest, render engine/device, color pipeline, resolution/framerate, deterministic settings/seed where meaningful, command/script, output hashes, review status and known nondeterminism. Preserve `.blend`, `.aep`, `.psd`/`.ai` or equivalent source with proper rights and an exchange/export path. Do not rely on one agent's unsaved desktop session.

Fonts are references plus licensing/installation instructions. Do not copy installed proprietary fonts into repos/ZIPs; do not redistribute container fonts through this package. Model/material/image licenses are item-specific. An original Blender render is not automatically CC0 if its dependencies are not.

## Color and performance

Use explicit color spaces and a tested SDR/sRGB public fallback; preserve raw profile/metadata where HDR/color fidelity is a product requirement. Do not advertise a captured HDR desktop as color-accurate after unrecorded tone mapping. Test dark/light backgrounds, alpha, gradients, compression and text readability. Avoid needless heavy transparent video when a poster/SVG works.

Set placement budgets before export. Proposed starting budgets—not measured guarantees—are a small first-view static/poster payload, lazy-loaded rich media, no initial forced audio, pause when offscreen/hidden, and reduced-motion/data-saving alternatives. Record actual page transfer, main-thread work, GPU memory and long-task impact; do not let an animated hero undermine the product's performance claim.

## Review

Visual/brand quality cannot be reduced to a single model score. Use the approved rubric and appropriate human review. Automated checks cover dimensions, missing sources, illegal states, license fields, broken links, metadata, size thresholds, contrast opportunities and motion preferences. Public derivative approval remains distinct from evidence validity and from permission to publish.
