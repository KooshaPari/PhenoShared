# CLI, library and machine-interface media

A product without a GUI still needs recognizable identity, useful documentation and real demonstrations. It does **not** need a fabricated visual dashboard or animated panel background inside a nonexistent application.

## Required CLI brand kit

Provide a clean wordmark/icon for landing/docs/package pages; a plain ASCII fallback and optional Unicode/ANSI rendering; consistent help/completions/manpage styling; concise version identity; and a consistent error vocabulary. Validate 80-column and narrow terminals, dark/light backgrounds, no-color behavior, noninteractive execution, redirected output and accessibility.

Brand decoration belongs in interactive surfaces by policy. JSON, NDJSON, CSV, MCP/stdout protocols and shell-pipeline outputs must remain clean and parseable. Do not prepend ASCII art, ANSI sequences or download promotions to machine data. Use stderr for authorized diagnostics; stdout remains contractual. `--help`, `--version` and any banner opt-in/default need explicit compatibility tests.

## VHS production contract

VHS scripts terminal sessions into recorded media and supports reusable tape sources [W10]. Probe the actual installed VHS/terminal/FFmpeg toolchain. Keep tape files, fixture setup, expected outputs and command digests with the subject. Record install, first useful task, a representative error/recovery and key differentiator, not just `--help`.

Tape `Hide`/`Show` is suitable for setup in an editorial demonstration, not for concealing an error while claiming a complete unedited performance trace. Preserve hard exit/output checks outside the visual transcript; a printed success sentinel is not self-authenticating proof. Waiting for actual output or completion is preferable to unexplained sleeps that flake under load.

Export a high-quality public video/poster and a text transcript or terminal log; an asciinema-style accessible alternative may be adopted after capability/license review. Keep raw master and transformation recipe. Ensure commands and secrets in the terminal are publication-safe. Do not run VHS publication/upload features automatically.

## Libraries and protocol tools

Use a clean consumer project that installs/imports the actual package and completes a bounded task. Record that CLI or notebook workflow via the appropriate real tools. API examples should compile/run under version-pinned dependencies. A self-hosted service can demonstrate request/response and operational behavior without inventing a GUI. Non-user-facing helper packages may share the parent brand while retaining package identity, ownership and release compatibility.

## Negative tests

JSON output with branding accidentally injected; `NO_COLOR` or declared no-color flag ignored; unsupported terminal escapes; narrow-width overflow; nondeterministic spinner in redirected logs; failed command with zero exit; missing package at advertised registry; tape recording a different binary than the release candidate. Every required negative case must fail truthfully.
