# PhenoDocs: required-now delivery surface

The current rich-workspace plan marks generated data and cross-repo federation as Phase 2/3 [G07]. This audit promotes their applicable delivered capability to the current target. It does not assume that each labelled item is absent from implementation; refresh code, tests, packages and rendered output first.

## Required capabilities

| Capability | Concrete delivered result | Acceptance/failure case |
|---|---|---|
| Portable consumer configuration | Arbitrary subject/owner/base path/license/brand, no mandatory fleet checkout | Unrelated external fixture builds; missing required config rejected |
| Source ingestion | Explicit repo/local manifest, revision pin, path filters and visibility | Missing revision/path fails; duplicate IDs/collisions rejected |
| Plan/work/spec/research views | Source-backed structured display, author/status/date/owner, trace links | Missing source or stale facts visible; status cannot be inferred from prose |
| Roadmap view | Horizons and explicit assumptions; actual milestone state from owner | No fabricated dates or implied implemented features |
| Changelog/release view | Release-linked user changes, source version and compatibility notes | An unpublished tag does not become a shipped release |
| Commit/history view | Real commit IDs and provenance, stable pagination/filtering | No demo data in production view; empty source labelled empty |
| WBS/DAG view | Accessible graph plus table, typed dependencies, cycle detection | Deliberate cycle fails; priority/resource links not rendered as prerequisites |
| Cross-project federation | Reusable adapter rendering approved content projections | No copying entire product trees into the tool; correct source backlinks |
| Search and machine indexes | Version/audience scoped searchable docs and explicit machine export | Private and withdrawn content absent from every index/cache |
| Docs quality | Build, internal anchors/links, navigation/media/alt/caption/readability checks | Seeded broken link must fail both local and hosted gate |
| Journey viewer | Verifiable actual recordings, assertions, subject IDs, mode labels | Mock/live confusion and missing assertion backend rejected |
| Publication variants | Pages prefix and Vercel docs prefix with correct assets/canonical metadata | Deep link, refresh, search, 404 and locale routes tested per target |

## Architecture refinement

Use source adapters -> normalized read model -> renderer components -> target-specific build. Read models are derived, inspectable and regenerable. Store actual work state at source, not inside the hub. An editable UI must call the owning scoped tool with authorization and record its receipt; editing a cached JSON display is not an engine update.

Run link and artifact checks fail-closed. Remove blanket `ignoreDeadLinks: true` for required published surfaces only after triaging existing failures and adding scoped, reviewed exceptions where justified. Default legal text must not claim every consumer is MIT. A default sample brand is a labelled theme, not a forced identity. [G06, G10]

## Suggested implementation closure slices

First: neutral external fixture + real link checker + final check propagation. Second: explicit source manifest and version/audience isolation. Third: a single subject's actual plan/spec/changelog/commit/WBS views with table fallback. Fourth: second independent subject to prove federation. Fifth: target-specific Pages/Vercel builds and consumer screenshot proof. Do not postpone all rich views indefinitely; deliver bounded real versions now and keep later visual polish nonblocking only when it is not required.

## Content contract

Every displayed number/status needs source record, retrieval/measurement time, interpretation and scope. Requirements and proposed work remain visible without claiming implementation. No generated percent-complete badge without a fixed accepted denominator. Technical “future” comments, obsolete proposals and superseded work must be classified, not blindly implemented. The complete user-requested capability horizon remains linked even when one view has no applicable data for a particular subject.

## Delivery artifact

Publish a usable reusable package/tool with external-consumer quickstart and example, and separately deploy its own documentation/demo. A private root web-site package is not automatically an npm library, and a docs-only site does not need a bogus binary release. Choose the actual distribution units during package discovery.
