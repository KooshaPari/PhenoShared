# AgilePlus tooling adoption and publication

The observed source contract expressly states that AgilePlus is tooling and does not own cross-project state [G12]. Its repository contains explicit scope work [G11]. Neither a checked task nor source text proves the local agent session is bound to the correct deployed engine.

## Mandatory local probe

Resolve current repository root, installed tool/package/source version, MCP endpoint identity, supported methods, session root and current state through authorized reads. Record unsupported commands rather than inventing the older CLI/API. Distinguish the tool repository's self-work from managed subject records.

For actual state mutations, use existing authorization and service contracts. Preserve returned transaction/audit IDs and materialized projection identities. `docs/agileplus/` review artifacts are not a writable alternate database. Mutable `.agileplus/` database/locks/logs stay out of ordinary commits except accepted configuration. [G12]

## Release and conformance fixture

A clean external repository must initialize without a central portfolio clone; import/inspect a bounded feature; manage a work package; materialize docs; validate meaningful positive/negative evidence; and recover from interruption under the actual implemented interfaces. Repeat with two roots and identical slugs. Test wrong-root requests, stale writer/concurrency, local worktrees, path traversal, cancellation and corrupt imports.

Do not make test stubs or accepted fake receipts stand in for engine transitions. A validator that echoes a message must be qualified before being used for acceptance. The v2 source findings remain a repair queue for revalidation, not a guarantee that every defect still exists unchanged.

## Documentation federation

AgilePlus can produce a stable export contract consumed by PhenoDocs. The export includes identity, version, source root reference without private absolute paths, requirement/WP/decision IDs, status, evidence digests, visibility and freshness. It is read-only and rebuildable. Site content is filtered before indexing and publication. Public readers cannot infer private portfolio topology from filenames or backlinks.

## Decontamination and restore

Map central legacy records to their actual subject owners with reviewed decisions; preserve unknown items without silently assigning them. Record database backups separately from source refs and generated exports. Prove import idempotency or explicit duplicate rejection, audit-chain handling, rollback and restart. Only authorized owners retire old active writer paths after consumers switch.

## Product scope versus portfolio policy

AgilePlus may implement generic policy configuration and progression rules. The current human portfolio policy is a versioned *consumer input*, not hardcoded business truth inside the reusable engine. Its own source repo requires its own docs, releases and tests like any other tool product. This does not make it the storage home for every other product's roadmap.
