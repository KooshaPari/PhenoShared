# Tool/data decontamination without loss

## What must remain in the tools

PhenoDocs: reusable rendering/index/federation machinery, themes/components, adapters, schemas, tests, generic examples, the tool's own documentation and a deliberately bounded demo consumer. AgilePlus: scoped work engine, CLI/MCP/API contracts, validation, adapters, its own product requirements, and generic migration fixtures. Their self-dogfood records are legitimate.

## What is not tool-owned truth

Unrelated portfolio product requirements, copied application code, whole customer/portfolio catalogs, active cross-project work databases, raw personal session exports, live deploy credentials, one-off production domain config and portfolio-specific approval records. These can be tool inputs, generated views or history retained under clear labels, but not an implicitly mutable authority inside the tool source.

## Classification pass

For each candidate path/record, classify TOOL_IMPLEMENTATION, TOOL_SELF_DOC, GENERIC_FIXTURE, SUBJECT_OWNED_CONTENT, DEPLOYMENT_INSTANCE_CONFIG, GENERATED_PROJECTION, HISTORICAL_CUSTODY, SECRET_PRIVATE or UNKNOWN. Use schema/writer/reader and history evidence rather than directory name. A file under docs/ may contain code; a registry-named module may merely be a generic plugin registry, which is legitimate tool code.

Build a many-to-many owner map with source commit/path, destination owner/path, policy/privacy, original IDs, consumer references, evidence freshness, export/import plan and rollback. Current human direction settles reusable-tool role, not arbitrary path ownership or blanket deletion.

## Migration sequence

Freeze and export the affected records with exact provenance. Identify owners using accepted decisions, not name guessing. In a disposable copy, import into the intended subjects; verify counts, identities, audit history, links, behavior and duplicate policy. Update tool consumers to pass explicit manifests/configuration. Exercise an unrelated external-repo fixture and a private consumer. Only then propose removing live ownership from the old tool checkout. Preserve labelled custody until target receipts and rollback tests pass.

For AgilePlus, use the actual deployed root-bound engine contract. The observed repo contract says source state belongs under each subject Git root and review files are materialized [G12]. Do not overwrite those projections and infer a successful import. Back up SQLite consistently and include engine metadata/audit state; Git alone is not database backup.

For PhenoDocs, separate renderer package from the Phenotype hub instance. Initially an explicit `examples/` demo and `sites/` consumer configuration can live in one checkout if packaging and APIs keep the boundary real. A split into another repository is justified only by existing topology decisions, not as a reflexive cleanup.

## Required negative controls

An unrelated project builds without KooshaPari-specific remotes or central state. A private document never appears in public HTML/search/media/LLM indexes. Two projects with the same slug remain separate. A wrong-root request fails. Missing owner mappings stop the migration. A stale projection is labelled stale. A recovered old portfolio doc cannot silently override current user decisions. A collection of fixtures cannot masquerade as live active projects.

Do not make removal of all historical pollution a blocker for every small bug fix. Scope migrations to the delivery path, preserve unclassified history, and keep residual ownership work visible.
