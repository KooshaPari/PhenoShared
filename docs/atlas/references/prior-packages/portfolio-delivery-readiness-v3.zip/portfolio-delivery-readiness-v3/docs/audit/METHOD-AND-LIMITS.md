# Audit method and limits

This was a targeted source audit across the delivery-related parts of PhenoDocs, AgilePlus, phenotype-landing, phenotype-infra and phenotype-fleet-ops, plus the phenoDesign README. Observed main refs were resolved for the five main repositories; relevant files were read at those immutable revisions. Only the design README is recorded as a mutable-default-branch observation with its blob identity. Sources and limitations are machine-readable.

The review looked for discrepancies between declared and actually wired tooling, build, release, federation and ownership behavior. It used official hosting, recording, rendering and GitOps documentation to constrain the proposed plan. No full 146-repository current-tree or historical audit is claimed. No live AgilePlus engine, native creative device, full cloud account or authoritative DNS configuration was inspected.

Two small source files are preserved and their bytes recomputed to match reported Git blob identities. Larger sources have pinned URLs, commit/blob identity and bounded findings. This does not amount to complete archival of every repository file. The prior assurance ZIP is preserved unchanged as historical context.

The package's Python checks validate structural consistency and planned schema examples. They do not execute project builds, establish CI failure rates, prove security, authenticate production receipts, render product screenshots, measure performance or deploy a domain. The source findings should be reproduced by the assigned owners at the then-current baseline, preserving newer valid repairs.

Read-only provider/document retrieval failures are recorded. Missing source paths are not proof that no alternative workflow or dashboard configuration exists. Public website parsing is not production health verification. The Vercel connector was suggested but not connected in this session.
