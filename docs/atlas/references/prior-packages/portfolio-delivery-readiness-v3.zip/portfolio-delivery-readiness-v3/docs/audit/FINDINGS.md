# Targeted delivery audit

Source review is tied to the captured pins in [sources](../../references/SOURCES.md). This is not an account-wide audit or approval to edit another worker's repository. Refresh heads and preserve newer valid repairs before reproducing.

## F01 — PhenoDocs tooling and deployment instance are entangled

**Evidence:** `source_design_gap`. **Owner work:** `WP02`.

Reusable code coexists with portfolio-owner defaults, concrete site navigation and a hub instance. Classify rather than delete: a labelled example/self-doc is legitimate, unrelated live authority is not.

**Acceptance:** An independent external consumer works with its own owner, content, brand, license and paths without cloning portfolio state.

Sources: G01, G05, G06

## F02 — Current PhenoDocs link check is still a no-op

**Evidence:** `source_confirmed`. **Owner work:** `WP03`.

The pinned script prints a stub-success line and returns zero. The earlier exact-script reproduction remains historical evidence; this run re-read the unchanged blob, not reran product CI.

**Acceptance:** Seed a broken relative link/anchor and verify native command, report and hosted required gate all reject it.

Sources: G10

## F03 — Shared renderer disables dead-link enforcement and assumes MIT

**Evidence:** `source_confirmed`. **Owner work:** `WP04`.

ignoreDeadLinks is true; footer says MIT regardless of consumer; default org is KooshaPari. Legal/identity/default behavior must be explicit inputs.

**Acceptance:** Unrelated non-MIT fixture shows correct metadata, actual source backlinks and failing dead links under publish profile.

Sources: G06

## F04 — PhenoDocs generic CI can conceal real command failures

**Evidence:** `source_confirmed`. **Owner work:** `WP12`.

Multiple commands append successful echo warnings and jobs are advisory. Final test job is echo-only under always; aggregate references the wrong dependency-review needs key.

**Acceptance:** Injected lint/test/security failures and missing required jobs produce explicit rejection at final required status.

Sources: G03

## F05 — Landing CI does not implement its documented nested-site build matrix

**Evidence:** `source_confirmed`. **Owner work:** `WP11`.

The inspected workflow uses generic root-only discovery and no explicit site build matrix. README says root CI builds eight Astro packages. Other workflows/provider builds were not exhaustively audited.

**Acceptance:** Fail a nested site and shared template; correct affected closures run and fail; valid sites build with their own actual lockfiles.

Sources: G02, G09

## F06 — Release attestation is wired around a dummy artifact

**Evidence:** `source_confirmed`. **Owner work:** `WP16`.

Build step writes a text placeholder rather than the product. The action input contains shell substitution syntax instead of an evaluated digest. No actual workflow execution was performed here.

**Acceptance:** Real candidate subject is built/inspected/tested and attested; verification rejects dummy, missing or wrong artifacts.

Sources: G04

## F07 — Base-path selection conflates GitHub Actions with GitHub Pages

**Evidence:** `source_confirmed`. **Owner work:** `WP07`.

GITHUB_ACTIONS=true selects /<repo>/ even when the same runner builds for a Vercel docs subpath. Target profile must be explicit.

**Acceptance:** Run root, Pages-prefix and Vercel-prefix fixture builds with correct deep links, assets, canonical URLs and search.

Sources: G05

## F08 — Readme path convention does not establish actual Vercel composition

**Evidence:** `evidence_gap`. **Owner work:** `WP08`.

Site config defines Astro build only. Root vercel.json at inspected path returned 404; actual dashboard/edge configuration unknown. Public home exposes legacy subdomains.

**Acceptance:** Authenticated route/project/domain inventory plus explicit target composition, alias parity and rollback receipts.

Sources: G02, G08, W17

## F09 — Generated rich views and federation still appear as future phases

**Evidence:** `source_confirmed`. **Owner work:** `WP06`.

Phase 2 generation and Phase 3 federation are listed after current sample/IA work. Some code may already exist; confirm before duplicating. Latest user asks current delivery, not indefinite deferral.

**Acceptance:** Real two-subject generated plan/spec/research/roadmap/changelog/history/WBS views, stale/empty/error behavior and privacy validation.

Sources: G07

## F10 — PhenoDocs public README contains unresolved source/deploy references

**Evidence:** `source_confirmed`. **Owner work:** `WP05`.

README refers to yourorg dependencies and deploy.yml, which returned 404 at this pin. This does not establish absence of a deployment through another mechanism.

**Acceptance:** Verified quickstart/package identity, authoritative workflow links and published route; distinguish tool self-docs from hub example.

Sources: G01

## F11 — AgilePlus repo-local contract must replace legacy central-state assumptions

**Evidence:** `source_contract`. **Owner work:** `WP09`.

Source already specifies subject-root ownership and generated review artifacts. This is not proof every central historical record or installed service migrated.

**Acceptance:** Two-root isolated engine operations and reviewed export/import/restore with preserved IDs; no cross-project state owned by tool repo.

Sources: G11, G12

## F12 — Shared design retirement notice does not name an exact successor

**Evidence:** `evidence_gap`. **Owner work:** `WP21`.

Archive declaration lacks source/token/export/consumer mapping. Do not revive or overwrite assets on that statement alone.

**Acceptance:** Identify accepted source owners, rights and consumers; recover high-quality source; verify export parity before new production.

Sources: G13

## F13 — Prior journey-verdict defects require consumer requalification

**Evidence:** `historical_revalidation`. **Owner work:** `WP19`.

Assurance v2 records fixed-score live verification and assertion-error handling at its own pinned source. This targeted run did not refresh the current journey implementation; do not claim those paths repaired or unchanged.

**Acceptance:** Current invoked capture/verifier path rejects negative pixels/semantics, missing source, backend error and synthetic verdicts.

Sources: Current instruction / prior assurance provenance / explicit coverage limit; not a new source-confirmed product defect.

## F14 — Live deployment, DNS, installed creative tools and native capture remain unverified

**Evidence:** `access_gap`. **Owner work:** `WP01`.

Vercel connector was available but not installed/connected; no authenticated account or local workstation probe occurred. Public URL parsing is not administrative verification.

**Acceptance:** Named action/access receipts or explicit blockers; licensed/native tools are locally probed before scheduling.

Sources: W03, W05

## F15 — Product-dependent outcomes cannot be completed by pipeline scaffolds

**Evidence:** `policy_gap`. **Owner work:** `WP28`.

New requested scope requires actual product captures, final release installs and pilots. A fixture can qualify mechanics but cannot prove an unimplemented product.

**Acceptance:** Every obligation has distinct readiness state and owned product/authority/environment blocker where appropriate.

Sources: Current instruction / prior assurance provenance / explicit coverage limit; not a new source-confirmed product defect.

## F16 — Fleet-wide infrastructure and recovery coverage is not established by this source sample

**Evidence:** `coverage_gap`. **Owner work:** `WP18`.

This audit inspected delivery/tooling sources, not every provider, runner, project deployment, secret store or backup. Do not promote partial inventory to complete infra audit.

**Acceptance:** Declared infra scope inventoried with restore/drift/resource evidence; unsupported areas remain visible.

Sources: Current instruction / prior assurance provenance / explicit coverage limit; not a new source-confirmed product defect.

## F17 — Infrastructure charter mixes deployment environment with product consolidation

**Evidence:** source boundary question, not demonstrated missing implementation. **Owner work:** WP18.

phenotype-infra README presents nanovms, PhenoCompose and BytePort as absorbed code. This source statement does not decide whether these product lifecycles belong in IaC; do not broaden the current infra task automatically.

**Acceptance:** Resolve independent product/runtime/IaC ownership and actual consumer paths before consolidation or reuse.

Source: [G14] in the source register.

## F18 — Fleet operations documentation refers to a different repository identity

**Evidence:** source boundary question, not demonstrated missing implementation. **Owner work:** WP18.

README heading/install/uses examples point to phenotype/phenotype-ops, whereas inspected source is KooshaPari/phenotype-fleet-ops. Referenced remote validity and actual adoption were not verified.

**Acceptance:** Resolve current shared-workflow source, publish identifiers, installed CLI and real callers; no blind policy-owner promotion.

Source: [G15] in the source register.
