# Low-level delivery contracts

## Identity and source selection

Use hosting provider repository ID when available, owner/name as a mutable display field, full commit OID, component path and build profile. A Git blob OID identifies source bytes, not the commit subject. Record both when fetched. An external artifact records SHA-256, media type, length and originating run. Copy/rename mappings preserve original identities.

An individual task binds its accepted decision/target version and owned write paths before execution. Refresh stale refs without erasing the observed baseline. Newer valid worker changes are preserved. No operator checkout resets or implicit garbage collection.

## RoutePlan contract

Required fields: route ID; purpose (marketing/docs/app/mirror); normalized host and leading/trailing base path; proposed/accepted/observed status; audience; subject/component; build variant; source profile; primary canonical URL; legacy aliases; edge provider; expected response/headers; rollback snapshot reference; owner and action permission reference. Production application session cookies must not be scoped casually to every sibling subdomain. Use explicit allowed origins and test host/header handling.

Only one accepted active primary route may own the same host+path namespace. An example does not satisfy this rule in production. Prefer consumer-specific doc namespaces and deterministic collision rejection to path shadowing. A missing optional rewrite backend is visible; a missing required backend blocks deployment.

## ReleasePlan contract

Required fields: product/package ID, source commit, target OS/arch/ABI/runtime, toolchain/lockfile/build-config identity, expected executable/package inventory, instrumented verification profiles, noninstrumented performance baseline, license notices, SBOM and provenance, channel/version, signing policy, staged install/upgrade/uninstall, promotion order and rollback/withdrawal policy. Registry immutability or inability to reuse a version is handled explicitly. Reverting source is not equivalent to rolling back a database or a published package.

A release subject must be the real binary/package/image/site digest. An attestation validates lineage, not behavior or legal rights [W04]. Signing, notarization and timestamping may legitimately alter bytes; retain unsigned/signed subject relations and attest the distributed subject. Do not promise deterministic signed bytes without measurement.

## CapturePlan and AssetPlan

Capture identity includes actual application artifact, fixture/data seed, environment OS/browser/GPU/driver/display profile, locale/time zone/font set references, viewport/scale, timestamps, hard assertion IDs, capture tool version and privacy classification. Frames and videos have individual digests. Do not require OCR when semantic exit/DOM/API assertions are available; use actual GUI evidence when rendering correctness is the property being tested.

Asset identity includes content origin (authored/captured/derived/concept), source editing project, dependencies/textures/fonts by licensed reference, generation recipe/tool version, optional prompt/model/seed, parent captures, transformation list, rights, dimensions/duration/color/alpha, byte budget, alt text/captions, reduced-motion fallback and exact consuming placements. A numeric seed improves repeatability but does not guarantee deterministic output from all rendering or generative tools.

## State machines

```text
DRAFT -> DESIGNED -> PIPELINE_VERIFIED -> PRODUCT_VERIFIED
      -> PUBLISHED_VERIFIED -> OPERATED_VERIFIED
```

This is a milestone projection over separate obligations, not a replacement AgilePlus engine lifecycle. Any obligation can be BLOCKED_PRODUCT_IMPLEMENTATION, BLOCKED_ENVIRONMENT, BLOCKED_AUTHORITY, FAILED, STALE or EXCEPTED. No missing check becomes success because a predecessor passed. A source change invalidates only the affected evidence via explicit impact rules, while final candidate qualification remains required.

## Error and retry behavior

Permanent contract/privacy/identity failures do not retry automatically. Transient provider/network errors have bounded retry and preserve first-attempt outcomes. Capture timeouts, empty suites, missing media, malformed manifests and tool failures are nonaccepting. Cleanup runs only against uniquely owned ephemeral outputs. Capture failure must retain diagnostic evidence before destroying the private environment according to retention policy.

## Observability

Log queue wait, dependency download, cache hit/miss, build/test/capture/render/sign/deploy duration, rejected input reason, CPU/GPU/RAM/I/O peak, output bytes, provider run ID, first-attempt success, publish drift and privacy-filter results. Do not log secrets or unbounded private payloads. Explain skipped checks with the support-manifest condition and evidence, not a green checkmark.

## Runtime-state isolation

AgilePlus sessions bind to the subject Git root. Tests must cover two projects with identical feature slugs, symlink/worktree resolution, concurrent writers, stale leases, wrong-root requests, import replay and restore. Backup mutable database state separately from tracked review exports; a Git checkout alone cannot restore a local SQLite database. [G11, G12]

The companion JSON schemas are **planning schemas**, not attestation validation or a trusted source-registry implementation. The package validator checks self-consistency, not actual deployment correctness.
