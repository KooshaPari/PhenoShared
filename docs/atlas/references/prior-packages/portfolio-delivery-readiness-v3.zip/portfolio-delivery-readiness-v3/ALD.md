# Abstraction-layer design (ALD)

ALD here means **abstraction-layer design**, not another restatement of the HLD. It specifies how product intent becomes concrete delivery plans without conflating facts, policies and provider state.

## Layer 1 — Intent and approved target

Input: subject identity, versioned requirements, release scope, support matrix, required publication channels, rights/visibility constraints, resource budget and action permissions. These are authored or approved records, not outputs inferred from one passing build.

## Layer 2 — Typed delivery intermediate records

- `Subject`: repository identity, full commit, component and public contract.
- `RoutePlan`: host/path, origin, audience, base path, source artifact and transition plan.
- `ReleasePlan`: package targets, build profile, checks, signing/provenance, promotion and rollback.
- `CapturePlan`: real product artifact, environment class, deterministic scenario, hard oracles and media outputs.
- `AssetPlan`: placement/job, brand source, editing recipe, rights, exports and performance/accessibility budgets.
- `Obligation`: acceptance behavior, owner, required evidence, status, source and dependency.

Plans are not receipts. Proposals are not decisions. A configured target is not an observed deployment. The data examples in this package are explicitly proposed or synthetic.

## Layer 3 — Tool-independent execution DAG

Lower the records into bounded work: qualify tools; export subject state; build artifact; instrument independent suites; produce docs; capture real scenario; inspect rights/privacy; construct target variants; stage install/deploy; verify; request authorized promotion. Branches of the graph may proceed independently, but output artifacts carry immutable dependency identities.

Hard prerequisites, priority, resource exclusions, write leases and external blockers are different relations. Only actual artifact/contract prerequisites enter the DAG. GPU/native-OS access is a resource lease, not a fake dependency on an unrelated repo's task.

## Layer 4 — Platform/provider adapters

GitHub Actions/Pages, Vercel, package registries, native installers, OCI runtimes, site renderers, Playwright/VHS/native capture, Blender/Adobe and existing QA tools are adapters. An adapter has a capability probe, supported versions, input schema, least-privilege boundary, deterministic outputs, negative controls and observable failure modes. The adapter must expose unsupported conditions, not silently provide mock success.

## Layer 5 — Receipts and presentation

Actual runs produce source/artifact/environment identity, command/API request, native reports, outcome, errors and timestamps. Rendered evidence pages and dashboards are projections of these receipts. A raw JSON receipt does not authenticate its producer; authentication and independent oracle review remain separate acceptance obligations.

## Lowering invariants

1. Every public claim retains the exact source and maturity classification.
2. Every target variant records its own digest and origin/base profile.
3. Every media derivative points to its source master; evidence cannot be manufactured by creative tools.
4. No lowering step acquires greater privileges than the explicit execution envelope.
5. Tooling consumers outside the Phenotype portfolio must work without cloning a central registry or hardcoding KooshaPari names.
6. Incomplete product work stays an owned dependency, not a reason to fabricate a screenshot, release or adoption metric.

No distributed graph runtime is implemented here. These records can be represented within existing AgilePlus/portfolio contracts through adapters rather than introducing a new product or competing database.
