# Portfolio delivery readiness v3

**Audit + executable plan, dated September 9, 2026. No production changes performed.**

This package extends the portfolio execution correction and assurance v2. It is an additive dossier for an existing approved documentation home, **not a new portfolio repository or registry**. Current human permission and exclusive repository write leases remain controlling. Tooling must work for outside users, not require the KooshaPari fleet to exist.

## Read first

1. [Delivery contract](DELIVERY-CONTRACT.md): required outcomes, tooling/data boundaries and honest completion states.
2. [Source-grounded audit](docs/audit/FINDINGS.md): current targeted findings and explicit uncertainty.
3. [HLD](HLD.md), [ALD](ALD.md), [LLD](LLD.md): design and contracts.
4. [Agent addendum](prompts/APPLY-TO-ALL-AGENTS.md): portable continuation instructions.
5. [Work plan](work/PLAN.md), [work packages](work/WORK-PACKAGES.md), [DAG](work/DAG.md).
6. [Acceptance catalog](docs/verification/ACCEPTANCE.md) and [validation report](validation/REPORT.md).

## Target experience

An approved product has a coherent marketing page under `phenotype.space`, versioned PhenoDocs-built documentation under that domain plus the required GitHub Pages surface, an appropriate `pheno.studio` runtime mapping when it has a hosted application, verified downloadable/installable artifacts, real journey media, useful case studies, and a traceable deployment and rollback history. Source documentation and work records remain with each subject repository. Exact subpaths and aliases in examples are proposals until accepted.

## Scope of this delivery

The package provides policy, source evidence, mandatory-now PhenoDocs capabilities, role corrections, route/release/capture/asset contracts, test plans, risk and research decisions, a dependency graph, and agent work packages. It does not assert that these pipelines are implemented or live. Source pin and access limitations are in [coverage-limitations.json](data/coverage-limitations.json).

Use `python scripts/validate_package.py` and `python -m unittest discover -s tests -v` for the *package's* checks. These do not execute your product tests or approve deployments. The supplied manifests are clearly proposed or synthetic; source evidence is separate from example data.

## Preservation

The previous assurance ZIP is preserved unchanged in [provenance](provenance/README.md). Its independent >=85% gates and 100% critical/mandatory obligations remain. The new document narrows neither product intent nor evidence requirements. It clarifies what can close before domain-feature code is ready, and what must remain blocked with an owner.
