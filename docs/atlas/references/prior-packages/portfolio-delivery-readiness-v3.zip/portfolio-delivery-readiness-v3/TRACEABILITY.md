# Traceability entry point

The canonical planning graph is [data/traceability.json](data/traceability.json). It joins INT-DELIVERY-001 to all work packages, acceptance obligations and source findings. Detailed runtime/evidence identity requirements are in [docs/verification/TRACEABILITY.md](docs/verification/TRACEABILITY.md).

Authored specification drafts refer to the same machine records. They are not running AgilePlus state. The six bundles are semantic import inputs; use the actual installed scoped engine contract rather than forcing a legacy `kitty-specs` layout or editing generated `docs/agileplus` files.

This planning graph has no real product acceptance receipts. It intentionally does not claim deployed, published or operated status. Conditional capture/runtime dependencies are explicit in the work records and must be bound when an owner instantiates a target profile.
