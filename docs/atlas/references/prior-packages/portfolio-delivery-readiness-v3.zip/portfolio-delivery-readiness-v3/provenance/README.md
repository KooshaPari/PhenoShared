# Preserved sources

[portfolio-assurance-v2.zip](portfolio-assurance-v2.zip) is copied unchanged. [input-manifest.json](input-manifest.json) records its exact hash. The prior package is historical input; current explicit user boundaries and this delivery extension resolve relevant role/stage ambiguities, not a blanket supersession of its assurance rules.

[source-captures.json](source-captures.json) records two complete small source captures whose bytes match the Git blob OIDs supplied by the connector. Other source findings are anchored to pinned source URLs/blob IDs in [the source register](../references/SOURCES.md); full raw snapshots of every source were not materialized. No authenticated cloud settings or workstation session logs were acquired.

Do not treat nested historical archive contents as fresh product evidence. No font binaries or licensed creative assets were copied into this package.
