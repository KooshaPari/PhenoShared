# Apply now: tooling purity, delivery readiness, publication and genuine media

This is an additive execution correction. Preserve current PRs, valid evidence, subject intent, richer local docs/processes, existing IDs and exclusive write leases. Do not restart the whole portfolio audit or replace the parent mission with another general documentation pass.

## Mission

The target remains evidence-backed polyrepo shaping, approved migration/absorption/decomposition/retention, then usable stable products or accepted non-product terminal states. Complete all applicable work surrounding domain-feature implementation: planning, specs, architecture, intent, SOTA, QA/QC/QE, release builds, packaging, publishing, CI/CD, GitOps/infra, operations/recovery, branding/media, real journeys, case studies and cross-traceability.

“Everything except code” does NOT prohibit the engineering code needed to repair PhenoDocs, AgilePlus, capture/validation tools, build/release scripts or infrastructure adapters. Those are current delivery work. It also does NOT permit fake proof of unimplemented product functionality. Finish independent machinery now and attach genuinely product-dependent gates to exact owned capabilities.

## Authorization

Current explicit operator permissions govern. Existing scoped repair/commit/push/PR authority remains valid; do not ask anew for every permitted follow-on repair. This document does not grant remote creation, merges, publish, DNS/alias changes, paid purchases, license changes, archive, history rewrite, private device access, security-gate bypass or writes in another worker's repo. Prepare scoped action requests and continue other authorized work when a real boundary blocks progress.

## PhenoDocs and AgilePlus are TOOLS

They are not canonical repositories of the portfolio's records. Keep reusable tool implementation, own product docs, tests and labelled generic examples. Classify foreign product copies, live portfolio records, deployment-instance configuration, generated views and historical custody. Map each to its proper owner without loss before extraction. A generic plugin registry inside a tool can be legitimate implementation; do not delete by filename.

Product docs/intent/specs/assets live with their accepted subject owner. AgilePlus records are scoped to the real subject Git root under the actual deployed engine contract. Query and mutate through authorized real CLI/MCP/API interfaces; retain receipts; do not infer state transitions from generated Markdown. Back up mutable data separately from Git before migrations.

PhenoDocs consumes explicit manifests and produces derived render/search/view artifacts. It must work for an unrelated external project with its own owner, license, brand, paths and private/public data—not require the KooshaPari fleet. Keep the Phenotype hub/marketing as configured consumers, using the existing landing source rather than copying all sites into tool code.

## Domains and deployment

Target roles: `phenotype.space` for the generic Vercel-hosted landing/public product pages and docs subpages; GitHub Pages for required static docs surfaces; `pheno.studio` for real project/runtime deployment mappings. Exact slugs, docs version paths, subdomains, API origins and aliases require the current accepted route map.

Preserve working old URLs until parity, source custody and rollback are verified. DNS does not route URL subpaths. Either compose static outputs in the root landing build or use explicit verified edge rewrites. Do not infer Pages base paths merely from GitHub Actions running. Every target has explicit origin/base profile and tested deep links/assets/search/canonical metadata.

Discover actual Vercel project settings, aliases/plan, Pages settings, DNS/certificates, existing app origins, callbacks and cookies before cutover. A README claim, config file, URL returning 200, or generated route record is not production verification. Missing access remains named and owned. Nonhosted CLIs/libraries do not need fake runtime deployments.

## Required PhenoDocs work is now, not indefinite “future”

Reconcile existing code and roadmap first. Complete applicable source generation, plan/research/spec/work/roadmap/changelog/history views, WBS/DAG graph with accessible table fallback, cross-repo federation, private/public filtering, search and machine indexes, version/source backlinks, real links/media verification and qualified journey viewers. Existing implemented parts are reused. Sample data cannot ship as actual portfolio state.

Treat only genuine roadmap requirements as work; a technical comment mentioning future code is not a mandate. Preserve required horizons and exact blockers instead of deleting requirements to pass.

## CI/CD and release

Inventory actual nested packages/sites and support profiles. Fix required command failures masked with warnings, echo-only final gates, missing/misnamed dependencies and empty test selection. Use one meaningful required verdict per obligation. Frozen lockfiles must not fall back to uncontrolled installs. Apply dependency-aware changed-target selection with conservative fallback and final-candidate qualification.

Keep unit/integration/E2E and other required assurance families independent at >=85% under the accepted capability/component/language/platform/profile/metric matrix; preserve stronger thresholds. All mandatory selected checks and finite critical obligations require complete passing evidence. Do not replace E2E source coverage with screenshot count or combine suite accumulators to pass. Test the gate with bad inputs and failure controls.

Release the actual artifacts, never placeholders. Define real platform/ABI/package targets, expected outputs, checksums, SBOM/notices, signing/provenance, clean install/use/upgrade/uninstall and registry/channel verification. Attest the real distributed subject; shell syntax in action inputs is not a computed digest. Signatures are not behavioral correctness proofs. Prevent duplicate concurrent publication and unsafe cancellation midway through promotion.

Use appropriate existing/free/OSS tooling and actual installed contracts; inspect edition/plan constraints. A site root marked private need not be published as a package. A docs-only product need not fake binaries. Do not force long-lived/GPU services onto unsuitable hosting.

## Infrastructure

Inventory and qualify runners, credentials, networks/DNS/TLS, artifact retention, storage, deployment environments, backups/restores, alerting and resource controls. GitOps means actual desired-state reconciliation where used; a one-shot push script alone is not that. Prefer simple deployment where sufficient rather than creating new clusters for appearances.

Untrusted builds/captures never inherit production credentials, full home mounts, personal browser profiles, Docker sockets or unrestricted SSH agents. Preserve privacy and source custody. Test restore, not just backup creation. Preserve release/domain rollback; Git revert alone cannot undo a database migration.

## Real product journeys in private nondisruptive environments

Use phenotype-journeys heavily after qualifying the invoked current verifier and adapter. Public workflows get actual product captures and hard semantic assertions, with exact artifact/version, fixture seed, environment, actions, errors, raw logs, frames/video and timestamps. Keep mock/API/native modes distinct. Fixed scores, backend errors, missing pixels and printed success messages are not evidence.

Use private browser/CLI environments for web/terminal work. Native Windows/macOS/GPU apps need compatible dedicated sessions/VMs/devices and consent/entitlements. A Linux container is not a universal native GUI host. “Hidden” means not disturbing the operator, not concealed capture or expanded access.

Do not steal focus or route the operator's mic/speakers. Enforce global CPU/GPU/RAM/I/O/session budgets to protect gaming and Ableton. Capture failure keeps diagnostics, releases leases and cleans only owned resources.

## Branding and rich assets

Locate current accepted brand/token/source owners first, including phenoDesign history and actual consumers. Use available OSS and user-licensed Blender/Adobe after probing versions, fonts/plugins, rights and automation. Do not assume reported availability means the tool is accessible in this execution environment.

Create placement-driven editable 2D/2.5D/3D sources and static/animated/interactive exports where useful: marks/icons, landing heroes, panels/backgrounds, docs illustrations, tutorials, social cards, prompt/reference inputs and case-study assets. Record source dependencies, recipes, tool versions, rights, color/alpha, formats, bytes, captions/alt text, reduced-motion/poster fallbacks and consuming paths. Do not add expensive 3D to every small library for uniformity.

Maintain two pipelines: actual evidence masters and authored presentation assets. Never generatively edit screenshots into proof, remove failures, change metric values or hide time compression. Label concepts and synthetic data. Prevent private captures from leaving their allowed environment. Fonts are licensed references, not copied proprietary binaries.

CLI-only apps need good brand identity, ASCII/plain/no-color fallback and real VHS recordings/transcripts of useful tasks and errors. No fake GUI. No banners/ANSI art injected into JSON/NDJSON/CSV/MCP or machine stdout. Libraries demonstrate real consuming code.

## Research and product value

Complete subject-owned intent provenance and living dimensional SOTA. Reuse valid research and fill genuine gaps with current primary sources; do not pad competitor lists. Design/execute controlled pilots and real case studies against stable bounded products, with direct/upstream/composed alternatives, explicit invariants, margins, budgets and retained failures. A screenshot is not a case study. Negative/inconclusive pilot results must be reported honestly.

## Source findings to route, not blindly replay

At observed PhenoDocs `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`: link checker remains a no-op; reusable config disables dead links and hardcodes legal defaults; CI masks several failures; release-attestation builds dummy content; base inference assumes any GitHub Actions build is Pages; rich generated/federated views remain future-labelled. Landing at `a986d7a5e0fbfff7a89a2a7cb59b56a5e93b829c` has generic root CI rather than the advertised nested-site build matrix. AgilePlus at `82130cae162d6743b9c7271c8fdef441f0f20ade` explicitly defines repo-local state ownership.

Refresh heads and preserve newer valid fixes before reproducing. Current instantiated environment, cloud configuration and source behavior have not all been tested by this document. Do not label historical findings current without checking.

## Status and continuation

Maintain separate DESIGN_READY, PIPELINE_VERIFIED, PRODUCT_VERIFIED, PUBLISHED_VERIFIED and OPERATED_VERIFIED views without replacing actual AgilePlus lifecycle vocabulary. A canary proves only its pipeline. Product/authority/environment blockers need IDs, owners, exact required actions and wakeup triggers. An inherited required defect is still the assigned outcome's work even if it predates the PR.

Every worker returns one concise target matrix: accepted role and disposition; baseline and owners; actual tools/engine scope; docs/intent/SOTA/coverage; route/release/infra; capture/assets/case study; cross-traceability; exact blockers; next ready work. Coordinators retain parent outcomes and cross-repo migration responsibility after delegation.

Then perform ready authorized work depth-first. Do not stop at another outline, a green badge, a count of files/screenshots, or “give me the next three repos” while the current target has no owned path to acceptance.
