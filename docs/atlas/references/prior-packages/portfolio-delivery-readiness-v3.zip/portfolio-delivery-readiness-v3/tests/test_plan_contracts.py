"""Synthetic package-contract checks, not evidence of any product deployment."""
import copy, importlib.util, json, math, subprocess, sys, tempfile, unittest
from pathlib import Path
import jsonschema
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('checker',ROOT/'scripts/validate_package.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
class PlanTests(unittest.TestCase):
 def load(self,kind):return json.loads((ROOT/'examples'/f'{kind}.json').read_text())
 def reject(self,kind,obj):
  with self.assertRaises((ValueError,jsonschema.ValidationError)):checker.validate_record(kind,obj)
 def complete(self,kind):
  # These fabricated IDs are intentionally labelled synthetic fixtures. The helper does not authenticate them.
  d=self.load(kind);d.update(state='product_verified',run_receipts=['SYNTHETIC-TEST-NOT-AUTHORITY'],source_commit='a'*40,artifact_sha256='b'*64)
  return d
 def test_all_proposed_examples_validate(self):
  for kind in ['route','capture','asset','release']:checker.validate_record(kind,self.load(kind))
 def test_unknown_fields_rejected(self):
  d=self.load('route');d['automatic_approval']=True;self.reject('route',d)
 def test_bad_sha_rejected(self):
  d=self.load('release');d['source_commit']='short';self.reject('release',d)
 def test_verified_requires_receipts(self):
  d=self.load('release');d['state']='product_verified';self.reject('release',d)
 def test_canary_not_product(self):
  d=self.complete('release');d['product_kind']='synthetic_canary';d['clean_install_receipt']='SYNTHETIC';self.reject('release',d)
 def test_release_requires_install(self):self.reject('release',self.complete('release'))
 def test_publication_requires_authority_ref(self):
  d=self.complete('route');d.update(state='published_verified',origin_state='verified',rollback_ref='SYNTHETIC');self.reject('route',d)
 def test_published_route_requires_origin(self):
  d=self.complete('route');d.update(state='published_verified',authorization_ref='SYNTHETIC',rollback_ref='SYNTHETIC');self.reject('route',d)
 def test_normalized_route(self):
  for base in ['/bad//path/','/../hidden/','relative']:
   d=self.load('route');d['base_path']=base;self.reject('route',d)
 def test_capture_requires_real_master(self):self.reject('capture',self.complete('capture'))
 def test_capture_no_foreground_takeover(self):
  d=self.load('capture');d['foreground_isolation']=False;self.reject('capture',d)
 def test_published_capture_privacy(self):
  d=self.complete('capture');d.update(state='published_verified',authorization_ref='SYNTHETIC',capture_mode='actual',raw_master_ref='SYNTHETIC',audience='public');self.reject('capture',d)
 def test_concept_not_evidence(self):
  d=self.load('asset');d['is_product_evidence']=True;self.reject('asset',d)
 def test_edited_evidence_rejected(self):
  for edit in ['generative_fill','replace_ui','change_metrics','retime']:
   d=self.load('asset');d.update(origin='derived_capture',is_product_evidence=True,derivative_of='SYNTHETIC',transforms=[edit]);self.reject('asset',d)
 def test_derived_needs_master(self):
  d=self.load('asset');d['origin']='derived_capture';self.reject('asset',d)
 def test_no_font_binaries(self):
  d=self.load('asset');d['includes_font_binaries']=True;self.reject('asset',d)
 def test_published_asset_rights(self):
  d=self.complete('asset');d.update(state='published_verified',authorization_ref='SYNTHETIC');self.reject('asset',d)
 def test_release_provenance_rollback(self):
  d=self.complete('release');d.update(state='published_verified',authorization_ref='SYNTHETIC',clean_install_receipt='SYNTHETIC');self.reject('release',d)
 def test_no_empty_check_inventory(self):
  d=self.load('release');d['required_checks']=[];self.reject('release',d)
 def test_toy_dag(self):
  tasks=[self.task('A',[],1,2,3),self.task('B',['A'],2,2,2),self.task('C',['A'],1,1,1)]
  self.assertEqual(checker.topo(tasks),['A','B','C'])
  p=checker.pert(tasks);self.assertEqual(p['critical_path_hours'],4);self.assertEqual(p['nodes']['C']['slack'],1)
 def task(self,id,deps,a,m,b):return {'id':id,'hard_dependencies':deps,'effort_hours':{'optimistic':a,'most_likely':m,'pessimistic':b}}
 def test_cycle_rejected(self):
  with self.assertRaises(ValueError):checker.topo([self.task('A',['B'],1,1,1),self.task('B',['A'],1,1,1)])
 def test_unknown_dependency_rejected(self):
  with self.assertRaises(ValueError):checker.topo([self.task('A',['X'],1,1,1)])
 def test_duplicate_task_rejected(self):
  with self.assertRaises(ValueError):checker.topo([self.task('A',[],1,1,1),self.task('A',[],1,1,1)])
 def test_duplicate_dependency_rejected(self):
  with self.assertRaises(ValueError):checker.topo([self.task('A',[],1,1,1),self.task('B',['A','A'],1,1,1)])
 def test_missing_estimates_no_forecast(self):
  p=checker.pert([self.task('A',[],None,None,None)]);self.assertIsNone(p['critical_path_hours'])
 def test_invalid_estimates_rejected(self):
  for vals in [(-1,1,2),(2,1,3),(True,1,2),(1,math.nan,3),(1,2,math.inf)]:
   with self.assertRaises(ValueError):checker.pert([self.task('A',[],*vals)])
 def test_empty_graph(self):self.assertEqual(checker.pert([])['critical_path_hours'],0)
 def test_relative_link_check(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'README.md').write_text('[broken](missing.md)\n[external](https://example.invalid/)')
   self.assertEqual(len(checker.local_links(p)),1)
 def test_package_graph_and_links(self):
  r=checker.validate(ROOT);self.assertEqual(r['errors'],[]);self.assertFalse(r['product_approved'])
 def test_cli(self):
  p=subprocess.run([sys.executable,str(ROOT/'scripts/validate_package.py')],capture_output=True,text=True,timeout=30)
  self.assertEqual(p.returncode,0,p.stdout+p.stderr);r=json.loads(p.stdout);self.assertFalse(r['deployment_performed'])
 def test_cli_missing_root(self):
  with tempfile.TemporaryDirectory() as d:
   p=subprocess.run([sys.executable,str(ROOT/'scripts/validate_package.py'),'--root',d],capture_output=True,text=True,timeout=30)
   self.assertNotEqual(p.returncode,0);self.assertEqual(json.loads(p.stdout)['status'],'INVALID_PACKAGE')
if __name__=='__main__':unittest.main()
