# DLV-02 — Generated documentation and domain publication

## Intent

Provide the concrete generated documentation and domain publication capability required by INT-DELIVERY-001 without claiming product or deployment outcomes from planning artifacts.

## Mandatory scope

The exact behaviors are the following acceptance obligations from the canonical [catalog](../../docs/verification/ACCEPTANCE.md): ACC-006, ACC-007, ACC-008, ACC-009, ACC-010, ACC-015, ACC-016, ACC-017, ACC-018, ACC-019, ACC-020, ACC-021, ACC-030. Their source records, applicability and criticality live in [obligations.json](../../data/obligations.json); do not hand-maintain a divergent second inventory.

## Requirements

ACC-006 SHALL be satisfied when applicable to the accepted subject target. ACC-007 SHALL be satisfied when applicable to the accepted subject target. ACC-008 SHALL be satisfied when applicable to the accepted subject target. ACC-009 SHALL be satisfied when applicable to the accepted subject target. ACC-010 SHALL be satisfied when applicable to the accepted subject target. ACC-015 SHALL be satisfied when applicable to the accepted subject target. ACC-016 SHALL be satisfied when applicable to the accepted subject target. ACC-017 SHALL be satisfied when applicable to the accepted subject target. ACC-018 SHALL be satisfied when applicable to the accepted subject target. ACC-019 SHALL be satisfied when applicable to the accepted subject target. ACC-020 SHALL be satisfied when applicable to the accepted subject target. ACC-021 SHALL be satisfied when applicable to the accepted subject target. ACC-030 SHALL be satisfied when applicable to the accepted subject target.

## Constraints

Preserve independent >=85% assurance-family floors and 100% critical/mandatory satisfaction. Preserve source/data custody, actual tool interfaces, existing write leases and permission boundaries. Missing implementation/native environment/authority stays explicitly blocked. Do not replace actual product evidence with fixtures, screenshots or self-declared approval.

## Failure and exclusions

Synthetic data may be used for reproducible qualification but must be labelled. Unrelated product domain features are not silently added. Any external action requires its existing explicit authorization. A negative experiment can close the experiment, not approve an unsupported product claim.

## Evidence

Findings: F05, F07, F08, F09. Read [source audit](../../docs/audit/FINDINGS.md). Actual subject run receipts have not been produced by this specification.
