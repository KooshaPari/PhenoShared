# DLV-04 — Private genuine journey capture

## Intent

Provide the concrete private genuine journey capture capability required by INT-DELIVERY-001 without claiming product or deployment outcomes from planning artifacts.

## Mandatory scope

The exact behaviors are the following acceptance obligations from the canonical [catalog](../../docs/verification/ACCEPTANCE.md): ACC-038, ACC-042, ACC-043, ACC-044, ACC-045, ACC-046, ACC-047, ACC-048, ACC-049, ACC-056. Their source records, applicability and criticality live in [obligations.json](../../data/obligations.json); do not hand-maintain a divergent second inventory.

## Requirements

ACC-038 SHALL be satisfied when applicable to the accepted subject target. ACC-042 SHALL be satisfied when applicable to the accepted subject target. ACC-043 SHALL be satisfied when applicable to the accepted subject target. ACC-044 SHALL be satisfied when applicable to the accepted subject target. ACC-045 SHALL be satisfied when applicable to the accepted subject target. ACC-046 SHALL be satisfied when applicable to the accepted subject target. ACC-047 SHALL be satisfied when applicable to the accepted subject target. ACC-048 SHALL be satisfied when applicable to the accepted subject target. ACC-049 SHALL be satisfied when applicable to the accepted subject target. ACC-056 SHALL be satisfied when applicable to the accepted subject target.

## Constraints

Preserve independent >=85% assurance-family floors and 100% critical/mandatory satisfaction. Preserve source/data custody, actual tool interfaces, existing write leases and permission boundaries. Missing implementation/native environment/authority stays explicitly blocked. Do not replace actual product evidence with fixtures, screenshots or self-declared approval.

## Failure and exclusions

Synthetic data may be used for reproducible qualification but must be labelled. Unrelated product domain features are not silently added. Any external action requires its existing explicit authorization. A negative experiment can close the experiment, not approve an unsupported product claim.

## Evidence

Findings: F13. Read [source audit](../../docs/audit/FINDINGS.md). Actual subject run receipts have not been produced by this specification.
