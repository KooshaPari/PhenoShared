# DLV-05 — Creative asset sources and distribution

## Intent

Provide the concrete creative asset sources and distribution capability required by INT-DELIVERY-001 without claiming product or deployment outcomes from planning artifacts.

## Mandatory scope

The exact behaviors are the following acceptance obligations from the canonical [catalog](../../docs/verification/ACCEPTANCE.md): ACC-050, ACC-051, ACC-052, ACC-053, ACC-054, ACC-055. Their source records, applicability and criticality live in [obligations.json](../../data/obligations.json); do not hand-maintain a divergent second inventory.

## Requirements

ACC-050 SHALL be satisfied when applicable to the accepted subject target. ACC-051 SHALL be satisfied when applicable to the accepted subject target. ACC-052 SHALL be satisfied when applicable to the accepted subject target. ACC-053 SHALL be satisfied when applicable to the accepted subject target. ACC-054 SHALL be satisfied when applicable to the accepted subject target. ACC-055 SHALL be satisfied when applicable to the accepted subject target.

## Constraints

Preserve independent >=85% assurance-family floors and 100% critical/mandatory satisfaction. Preserve source/data custody, actual tool interfaces, existing write leases and permission boundaries. Missing implementation/native environment/authority stays explicitly blocked. Do not replace actual product evidence with fixtures, screenshots or self-declared approval.

## Failure and exclusions

Synthetic data may be used for reproducible qualification but must be labelled. Unrelated product domain features are not silently added. Any external action requires its existing explicit authorization. A negative experiment can close the experiment, not approve an unsupported product claim.

## Evidence

Findings: F12. Read [source audit](../../docs/audit/FINDINGS.md). Actual subject run receipts have not been produced by this specification.
