# DLV-01 — Tool purity and scoped adoption

## Intent

Provide the concrete tool purity and scoped adoption capability required by INT-DELIVERY-001 without claiming product or deployment outcomes from planning artifacts.

## Mandatory scope

The exact behaviors are the following acceptance obligations from the canonical [catalog](../../docs/verification/ACCEPTANCE.md): ACC-001, ACC-002, ACC-003, ACC-004, ACC-005, ACC-011, ACC-012, ACC-013, ACC-014. Their source records, applicability and criticality live in [obligations.json](../../data/obligations.json); do not hand-maintain a divergent second inventory.

## Requirements

ACC-001 SHALL be satisfied when applicable to the accepted subject target. ACC-002 SHALL be satisfied when applicable to the accepted subject target. ACC-003 SHALL be satisfied when applicable to the accepted subject target. ACC-004 SHALL be satisfied when applicable to the accepted subject target. ACC-005 SHALL be satisfied when applicable to the accepted subject target. ACC-011 SHALL be satisfied when applicable to the accepted subject target. ACC-012 SHALL be satisfied when applicable to the accepted subject target. ACC-013 SHALL be satisfied when applicable to the accepted subject target. ACC-014 SHALL be satisfied when applicable to the accepted subject target.

## Constraints

Preserve independent >=85% assurance-family floors and 100% critical/mandatory satisfaction. Preserve source/data custody, actual tool interfaces, existing write leases and permission boundaries. Missing implementation/native environment/authority stays explicitly blocked. Do not replace actual product evidence with fixtures, screenshots or self-declared approval.

## Failure and exclusions

Synthetic data may be used for reproducible qualification but must be labelled. Unrelated product domain features are not silently added. Any external action requires its existing explicit authorization. A negative experiment can close the experiment, not approve an unsupported product claim.

## Evidence

Findings: F01, F02, F03, F10, F11. Read [source audit](../../docs/audit/FINDINGS.md). Actual subject run receipts have not been produced by this specification.
