# High-level design: reusable tooling, owned content, explicit publication

## System boundary

The fleet is a set of independent subject repositories and services. It is not a single data tenant embedded into PhenoDocs or AgilePlus. The delivery system composes immutable artifacts through explicit manifests and adapters. No new central runtime is required just to execute this plan.

```text
Subject repository / product
  ├─ owned intent, requirements, domain docs and assets
  ├─ local AgilePlus work state + tracked review projections
  ├─ acceptance/support/release manifest
  └─ source -> tested artifact -> release candidate
                         │
          ┌──────────────┼─────────────────┐
          │              │                 │
    PhenoDocs tool   journey tooling   release tooling
    renders/indexes  records/verifies  builds/packages
          │              │                 │
    docs bundle      raw evidence       real artifact
          │              │                 │
          └──────────────┼─────────────────┘
                  explicit consumer manifests
                         │
      phenotype-landing / deployment configuration
        ├─ Vercel: phenotype.space marketing + docs composition
        ├─ GitHub Pages: required static documentation surfaces
        └─ pheno.studio: separately deployed application origins
```

Cross-repo inventory and governance records remain with their accepted current owners. This design consumes an approved record; it does not choose a new registry owner or move all portfolio metadata into a tool. Generic renderers can display WBS, changes, history, evidence and roadmaps without becoming the source of those facts.

## Ownership table

| Item | Owner | Tool role |
|---|---|---|
| Product requirements and public claims | Subject product | AgilePlus manages scoped work/evidence; PhenoDocs renders |
| Live feature/WP state | Subject repo's scoped engine | AgilePlus supplies implementation and validation |
| Tool's own requirements and tests | Tool repo | Legitimate self-dogfood, not pollution |
| Public hub/marketing composition | Existing landing consumer/deployment owner | PhenoDocs package is a dependency |
| DNS/aliases and runtime topology | Approved infra/deployment owner | Declarative provider adapter; externally verified |
| Brand tokens/components | Accepted design owner, yet to be resolved at exact paths | Exported versions consumed by tools/sites |
| Screenshot/journey original | Subject run's evidence owner | Capture tool records; publication uses filtered derivatives |
| Portfolio inventory/decisions | Existing accepted portfolio authority | Read-only versioned projection into sites |

## Deployment strategy

Prefer deterministic **static composition** of approved versioned docs artifacts into the existing landing build for `phenotype.space`. This simplifies public cache and privacy boundaries. Independent Vercel site deployments joined by path rewrites are a fallback when their separate release cadence warrants it. [W02]

A Pages variant and a Vercel path variant may have different rendered byte digests because absolute base paths and canonical metadata differ. They must share source/content revision, renderer version and semantic page inventory, while recording their own artifact digests. Do not claim byte-for-byte build-once identity across intentional target transformations.

Runtime application hosts under `pheno.studio` are separate from marketing/documentation. A CLI or library can have a product page and downloadable artifacts without an always-on runtime deployment. A background worker, long-lived service, GPU process or database is not automatically suitable for Vercel's static/frontend hosting model; select hosting from its runtime contract and verified plan capabilities.

## Quality and security boundaries

Untrusted PR builds use low-privilege isolated runners and cannot access publish credentials, production sessions, DNS keys, internal docs or Adobe account state. Build artifacts are promoted only after required final-revision checks. The publish job verifies artifact identity instead of running untrusted hooks while holding credentials. Shared caches are separated by trust domain and build profile.

Content classification precedes every static render, search index and LLM-oriented export. A public repository does not imply all its imported blobs, capture logs or personal paths are publishable. Private project sources stay behind an authenticated build/read boundary; `noindex` is not access control.

## Nonfunctional acceptance

Reserve CPU/GPU/RAM/I/O and native-session capacity for foreground gaming and audio. Capture workers do not steal input, route microphones unexpectedly or modify the operator's current desktop. Site media has a performance budget, static fallback, accessible alternative and reduced-motion behavior. Every remote/public action has a scope-specific authorization and rollback plan.

Sources and inspection limits: [SOURCES.md](references/SOURCES.md), [coverage-limitations.json](data/coverage-limitations.json).
