# Dependency DAG

Hard prerequisite edges are shown. Priority, resource locks, external permissions and profile-specific publication/capture applicability remain separate fields. The actual product-selected graph must include its required capture/install edges and omit inapplicable hosting with rationale.

```mermaid
flowchart TD
  WP01["WP01: Observation and authorization baseline"]
  WP02["WP02: Classify tool code versus subject content"]
  WP03["WP03: Repair and qualify docs link validation"]
  WP04["WP04: Neutral renderer defaults and public filtering"]
  WP05["WP05: Package and quickstart PhenoDocs as a reusable tool"]
  WP06["WP06: Complete generated and federated rich views now"]
  WP07["WP07: Explicit site origin and base-path variants"]
  WP08["WP08: Before/after domain and alias plan"]
  WP09["WP09: AgilePlus runtime state isolation and restore"]
  WP10["WP10: Migrate classified pollution with consumer parity"]
  WP11["WP11: Landing nested-site discovery and reusable composition"]
  WP12["WP12: Make CI failure propagation authoritative"]
  WP13["WP13: GitHub Pages publication lane"]
  WP14["WP14: Vercel landing/docs composition lane"]
  WP15["WP15: pheno.studio runtime mapping and cutover preparation"]
  WP16["WP16: Real builds, packages, provenance and signing"]
  WP17["WP17: Clean install/update and staged publication"]
  WP18["WP18: Infrastructure inventory, recovery and drift proof"]
  WP19["WP19: Qualify actual journey verifier/adapters"]
  WP20["WP20: Private capture environment profiles"]
  WP21["WP21: Brand and asset custody map"]
  WP22["WP22: Editable 2D/2.5D/3D asset pipeline"]
  WP23["WP23: Terminal branding and VHS consumer recordings"]
  WP24["WP24: Actual GUI/product screenshots and walkthroughs"]
  WP25["WP25: SOTA and controlled product/delivery pilots"]
  WP26["WP26: Publish honest case-study and media surfaces"]
  WP27["WP27: Measured CI/CD and render optimization"]
  WP28["WP28: Cross-traceability and role-specific final audit"]
  WP01 --> WP02
  WP01 --> WP03
  WP02 --> WP04
  WP03 --> WP04
  WP04 --> WP05
  WP04 --> WP06
  WP04 --> WP07
  WP01 --> WP08
  WP01 --> WP09
  WP02 --> WP10
  WP05 --> WP10
  WP09 --> WP10
  WP01 --> WP11
  WP01 --> WP12
  WP05 --> WP13
  WP07 --> WP13
  WP12 --> WP13
  WP07 --> WP14
  WP08 --> WP14
  WP11 --> WP14
  WP12 --> WP14
  WP08 --> WP15
  WP12 --> WP15
  WP01 --> WP16
  WP12 --> WP16
  WP16 --> WP17
  WP01 --> WP18
  WP01 --> WP19
  WP18 --> WP20
  WP19 --> WP20
  WP01 --> WP21
  WP21 --> WP22
  WP19 --> WP23
  WP20 --> WP23
  WP21 --> WP23
  WP19 --> WP24
  WP20 --> WP24
  WP21 --> WP24
  WP01 --> WP25
  WP06 --> WP26
  WP14 --> WP26
  WP22 --> WP26
  WP25 --> WP26
  WP11 --> WP27
  WP12 --> WP27
  WP18 --> WP27
  WP10 --> WP28
  WP13 --> WP28
  WP14 --> WP28
  WP17 --> WP28
  WP18 --> WP28
  WP26 --> WP28
  WP27 --> WP28
  WP23 -. subject_has_cli_or_library_demo .-> WP26
  WP24 -. subject_has_gui .-> WP26
  WP17 -. page_claims_published_release .-> WP26
  WP15 -. page_claims_live_app .-> WP26
  WP15 -. subject_is_hosted_app .-> WP28
  WP23 -. subject_has_cli_or_library_demo .-> WP28
  WP24 -. subject_has_gui .-> WP28
```

Machine source: [work-packages.json](work-packages.json). Duration/critical path status: **UNESTIMATED_PENDING_LOCAL_BASELINE**. Do not interpret graph depth as elapsed days.
