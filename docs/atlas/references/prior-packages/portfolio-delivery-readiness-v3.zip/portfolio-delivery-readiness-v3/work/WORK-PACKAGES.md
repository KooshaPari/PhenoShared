# Executable work-package contracts

These are planned packets, not granted permissions or completed work. Coordinator binds real owners, baselines and leases. Estimates intentionally remain unestimated until local scope/availability is known.

## WP01 — Observation and authorization baseline

Lane: `control`. Hard inputs: none.

Capture source refs, accepted targets, active write leases and actual provider/device access. No new full portfolio audit is a prerequisite to narrow fixes.

**Candidate write scope:** all assigned sources and deployment manifests.

**Outputs:** current source pins; live settings access requests; local tooling probe plan.

**Negative/acceptance check:** Unknown or missing provider/device permission stays blocked; stale source recheck preserves concurrent work.

**Owner:** control-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP02 — Classify tool code versus subject content

Lane: `tool-boundary`. Hard inputs: WP01.

Classify actual writers/consumers, self-dogfood, fixtures, projections, history and unrelated live records. Assign source-target owners before moving.

**Candidate write scope:** phenodocs owned paths; AgilePlus owned paths.

**Outputs:** content-owner map; custody and rollback plan.

**Negative/acceptance check:** Ambiguous owner or private content halts that transfer, not unrelated repairs.

**Owner:** tool-boundary-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP03 — Repair and qualify docs link validation

Lane: `tool-boundary`. Hard inputs: WP01.

Replace no-op behavior in the owning repo. Check actual link/anchor/media semantics and report failures into CI.

**Candidate write scope:** phenodocs scripts/tests.

**Outputs:** real checker or qualified adapter; seeded negative reports.

**Negative/acceptance check:** Broken link, anchor, missing media and malformed report must not yield success.

**Owner:** tool-boundary-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP04 — Neutral renderer defaults and public filtering

Lane: `tool-boundary`. Hard inputs: WP02, WP03.

Use explicit owner/license/brand/base/source inputs; preserve labelled demo defaults; eliminate blanket public dead-link bypass.

**Candidate write scope:** phenodocs reusable config/types/tests.

**Outputs:** external consumer fixture; visibility and metadata tests.

**Negative/acceptance check:** Private content and non-MIT fixture must not inherit public/MIT defaults.

**Owner:** tool-boundary-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP05 — Package and quickstart PhenoDocs as a reusable tool

Lane: `tool-boundary`. Hard inputs: WP04.

Identify package/CLI/library units, verify install/consumer APIs and repair nonexistent dependency/workflow claims.

**Candidate write scope:** phenodocs package/API/docs.

**Outputs:** actual distribution plan; clean external quickstart.

**Negative/acceptance check:** Missing dependency or unavailable method fails; docs-only root never publishes fake binary.

**Owner:** tool-boundary-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP06 — Complete generated and federated rich views now

Lane: `tool-boundary`. Hard inputs: WP04.

Finish plan/spec/research/work/roadmap/changelog/history/WBS surfaces with bounded real data and consumer-owned manifests.

**Candidate write scope:** phenodocs adapters/components/schemas/tests.

**Outputs:** real two-subject views; accessible DAG/table; source freshness markers.

**Negative/acceptance check:** Cycle, stale data, source error, empty input, duplicate ID and private leak tests.

**Owner:** tool-boundary-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP07 — Explicit site origin and base-path variants

Lane: `publication`. Hard inputs: WP04.

Replace provider inference with explicit target config and validate required locales/assets/search/canonical links.

**Candidate write scope:** phenodocs consumer build profiles; subject docs config.

**Outputs:** root/Pages/Vercel build profiles; variant manifests.

**Negative/acceptance check:** GitHub Actions building for non-Pages cannot silently select Pages prefix.

**Owner:** publication-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP08 — Before/after domain and alias plan

Lane: `publication`. Hard inputs: WP01.

Discover actual existing routes/providers, preserve subdomain aliases, select exact runtime and docs namespaces.

**Candidate write scope:** approved infra route manifests; landing consumer mapping.

**Outputs:** current/desired route inventory; namespace decision; rollback snapshots plan.

**Negative/acceptance check:** Unknown DNS/plan/access prevents cutover; wrong content destination never accepted.

**Owner:** publication-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP09 — AgilePlus runtime state isolation and restore

Lane: `tool-boundary`. Hard inputs: WP01.

Probe deployed contract and implement missing isolation/restore behavior within owner authorization.

**Candidate write scope:** AgilePlus scope/engine/adapters/tests.

**Outputs:** two-root engine proof; DB backup restore test.

**Negative/acceptance check:** Wrong root, identical slugs, stale lease, corrupt import and restore failure rejected.

**Owner:** tool-boundary-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP10 — Migrate classified pollution with consumer parity

Lane: `migration`. Hard inputs: WP02, WP05, WP09.

Transfer only accepted owned records/config; generated consumer views stay rebuildable; preserve historical custody until parity.

**Candidate write scope:** explicit source-target manifests only.

**Outputs:** verified exports/imports; source/ID map; consumer switch receipts.

**Negative/acceptance check:** No target owner, count mismatch, incompatible schema or private leak halts transfer.

**Owner:** migration-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP11 — Landing nested-site discovery and reusable composition

Lane: `publication`. Hard inputs: WP01.

Find actual sites/packages and locks, deduplicate shared templates without flattening distinct products; test nested affected builds.

**Candidate write scope:** phenotype-landing root/site build manifests/tests.

**Outputs:** actual site matrix; shared template dependency graph.

**Negative/acceptance check:** Nested site failure and shared-theme changes must trigger correct failed/expanded checks.

**Owner:** publication-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP12 — Make CI failure propagation authoritative

Lane: `cicd`. Hard inputs: WP01.

Remove success masking from required paths, correct needs keys/discovery and qualify final aggregators.

**Candidate write scope:** owned tool/site CI; shared workflow owner via coordinated task.

**Outputs:** actual check contract; seeded hosted/local failures.

**Negative/acceptance check:** Required unknown/skipped/failed/empty jobs fail; advisory diagnostics remain explicitly nonaccepting.

**Owner:** cicd-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP13 — GitHub Pages publication lane

Lane: `publication`. Hard inputs: WP05, WP07, WP12.

Verify custom build/deploy, permissions, namespace and privacy; publish only real artifacts under actual authority.

**Candidate write scope:** subject/tool Pages consumer workflows.

**Outputs:** validated artifact workflow; staging/actual Pages receipts when authorized.

**Negative/acceptance check:** Missing artifact, wrong prefix, stale SHA and unauthorised environment block publishing.

**Owner:** publication-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP14 — Vercel landing/docs composition lane

Lane: `publication`. Hard inputs: WP07, WP08, WP11, WP12.

Select static composition or approved rewrites and one authoritative promotion path. Test runtime/asset/cache behavior before alias switch.

**Candidate write scope:** phenotype-landing consumer config; authorized Vercel project settings.

**Outputs:** preview artifact; route parity tests; promotion/rollback receipt.

**Negative/acceptance check:** Private preview bypass, route collision, asset 404 and wrong build origin reject candidate.

**Owner:** publication-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP15 — pheno.studio runtime mapping and cutover preparation

Lane: `publication`. Hard inputs: WP08, WP12.

Map genuine hosted apps to approved origins; do not invent deployments for libraries or force GPU/daemon workloads onto unsuitable hosting.

**Candidate write scope:** product owned deployment adapters; approved infra config.

**Outputs:** per-product runtime suitability; origin/cookie policy; cutover plan.

**Negative/acceptance check:** Callback/CORS/cookie errors or unsafe data transition block cutover.

**Owner:** publication-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP16 — Real builds, packages, provenance and signing

Lane: `cicd`. Hard inputs: WP01, WP12.

Replace dummy builds, bind attestations to actual subjects, qualify packaging for supported targets.

**Candidate write scope:** each accepted product release unit; release workflow owner.

**Outputs:** real output inventory; SBOM/provenance; signing/install matrix.

**Negative/acceptance check:** Dummy content, wrong digest, empty archive or unverified signatures fail.

**Owner:** cicd-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP17 — Clean install/update and staged publication

Lane: `cicd`. Hard inputs: WP16.

Run real packaged consumers; publish only authorized versions after mandatory gates and record download/install identity.

**Candidate write scope:** release consumers/tests; authorized registries.

**Outputs:** native install/upgrade/remove evidence; external channel verification.

**Negative/acceptance check:** Local-source-only smoke cannot prove installed release; partial upload/version collision must be handled.

**Owner:** cicd-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP18 — Infrastructure inventory, recovery and drift proof

Lane: `infra`. Hard inputs: WP01.

Inventory applicable providers and resources; test backups/restores and actual reconciliation where GitOps is claimed.

**Candidate write scope:** approved infra/runner/config owners.

**Outputs:** runner trust split; resource limits; restore/drift tests.

**Negative/acceptance check:** Revoked creds, corrupt backups, drift, full disk, stale lease and wrong audience are nonaccepting.

**Owner:** infra-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP19 — Qualify actual journey verifier/adapters

Lane: `capture`. Hard inputs: WP01.

Revalidate prior defects at current head and qualify selected paths; integrate native hard assertions and honest mock mode.

**Candidate write scope:** phenotype-journeys owned verifier/CLI/adapters/tests.

**Outputs:** current negative controls; truthful verdict propagation.

**Negative/acceptance check:** Fixed success, missing image bytes, backend error and assertions_error cannot pass.

**Owner:** capture-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP20 — Private capture environment profiles

Lane: `capture`. Hard inputs: WP18, WP19.

Create least-privilege reproducible environments and native session leases without foreground interruption.

**Candidate write scope:** capture harness owner; subject scenario configs.

**Outputs:** web/CLI/native profiles; privacy and teardown tests.

**Negative/acceptance check:** No host-home/browser/vault mounts; no unintended input/audio takeover; missing native capability blocked.

**Owner:** capture-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP21 — Brand and asset custody map

Lane: `creative`. Hard inputs: WP01.

Locate original tokens/art/project sources and exact successor before creating or moving assets.

**Candidate write scope:** accepted design sources; subject brand consumers.

**Outputs:** source/license/consumer map; retained source catalog.

**Negative/acceptance check:** Unknown redistribution/license/source stays blocked; archive notice alone not a custody proof.

**Owner:** creative-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP22 — Editable 2D/2.5D/3D asset pipeline

Lane: `creative`. Hard inputs: WP21.

Probe available OSS/Blender/Adobe; produce placement-driven source projects and exports with rights/color/fallback metadata.

**Candidate write scope:** owned asset sources/export scripts.

**Outputs:** authoring recipes; source/derivative manifests; visual/perf variants.

**Negative/acceptance check:** Missing source/font license, wrong profile, misleading concept or oversized blocking media rejected.

**Owner:** creative-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP23 — Terminal branding and VHS consumer recordings

Lane: `capture`. Hard inputs: WP19, WP20, WP21.

Capture actual candidate install and useful workflow; ensure branding does not contaminate machine protocols.

**Candidate write scope:** CLI subject docs/brand/tapes/tests.

**Outputs:** real task recordings; ASCII/no-color proof; transcripts.

**Negative/acceptance check:** Failed command masked by sentinel, bad JSON/stdout or substituted binary rejects proof.

**Owner:** capture-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP24 — Actual GUI/product screenshots and walkthroughs

Lane: `capture`. Hard inputs: WP19, WP20, WP21.

Cover required public state/journey inventory on the actual product with controlled fixtures and native rendering.

**Candidate write scope:** subject journey/scenario/media paths.

**Outputs:** actual raw captures; redacted derivatives; assertion logs.

**Negative/acceptance check:** Unimplemented UI stays product-blocked; generated/mock screenshot cannot become evidence.

**Owner:** capture-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP25 — SOTA and controlled product/delivery pilots

Lane: `research`. Hard inputs: WP01.

Reuse existing research; complete gaps and run justified bounded pilots on stable candidates, separating canary from product results.

**Candidate write scope:** subject research and benchmark homes.

**Outputs:** versioned comparisons; experiment contracts; retained raw results.

**Negative/acceptance check:** No posthoc denominator/quality reduction; missing baseline or failed run stays explicit.

**Owner:** research-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP26 — Publish honest case-study and media surfaces

Lane: `publication`. Hard inputs: WP06, WP14, WP22, WP25.

Combine verified current claims and actual role-required captures/install results. CLI and GUI evidence prerequisites are selected by the subject manifest.

**Candidate write scope:** landing and subject docs consumers.

**Outputs:** case-study pages; source-linked media placements.

**Negative/acceptance check:** Any required capture/product receipt absent blocks that page claim; no pretend success art.

**Owner:** publication-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP27 — Measured CI/CD and render optimization

Lane: `cicd`. Hard inputs: WP11, WP12, WP18.

Reduce duplication and queue/compute costs after correctness. Preserve support/coverage and native proof.

**Candidate write scope:** approved workflow/cache/runner owners.

**Outputs:** baseline/after timings; cache trust tests; WIP policy.

**Negative/acceptance check:** Coverage loss, cache contamination or realtime foreground disruption invalidates optimization.

**Owner:** cicd-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.

## WP28 — Cross-traceability and role-specific final audit

Lane: `control`. Hard inputs: WP10, WP13, WP14, WP17, WP18, WP26, WP27.

Independently verify accepted target, route/package/capture evidence and permissions. Branch prerequisites are profile-specific; no forced live deployment for non-hosted tools.

**Candidate write scope:** existing subject and portfolio projections.

**Outputs:** outcome matrix; real receipts; owned residual blockers.

**Negative/acceptance check:** Canary, schema validation, PR or evidence count cannot close product/publication obligations.

**Owner:** control-owner; coordinator must bind actual named worker and lease. **Status:** PLANNED_NOT_EXECUTED.

**Permissions and rollback:** existing explicit scope only; no new external mutation authorization. preserve source/data/provider snapshots; apply task-specific approved rollback; never reset operator checkout

**Blocking/continuation:** stop only blocked action; retain owner/wakeup and continue independent authorized work.
