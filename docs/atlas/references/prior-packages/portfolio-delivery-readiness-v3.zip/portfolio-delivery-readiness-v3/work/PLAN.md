# Delivery plan and closure-first scheduling

## Do not start another fleet-wide rewrite

Read current accepted target, affected source pins, this addendum and relevant prior evidence. Reuse completed repairs. The latest direction makes tooling decontamination, publication, real media and applicable future PhenoDocs views current obligations; it does not authorize nine workers to rewrite the same tool repo or deploy arbitrary production changes.

## Work lanes and waves

| Wave | Useful closure | Work |
|---|---|---|
| A | Honest tooling/check baseline and current owner/access map | WP01–WP05, WP09, WP12, WP19, WP21 |
| B | One real public docs/landing route with safe preview and native tool consumption | WP06–WP08, WP11, WP13–WP14 |
| C | Actual release/install chain and private capture profiles | WP15–WP18, WP20, WP23–WP24 |
| D | Rich authored assets plus evidence-backed case studies/pilots | WP22, WP25–WP26 |
| E | Measured optimization and scoped final acceptance | WP27–WP28; iteration after each real product slice |

Wave labels express priority bands, not extra dependencies. Some listed work starts earlier if its actual prerequisites exist. Shared design/infra work needs independent owners but must not become an indefinite gate to a tiny CLI correction. The first pilot uses one already-runnable CLI and one web/native product chosen by current evidence and ownership, not a guessed “best repo.”

## Golden path

Select an accepted bounded target. Probe tools/permissions -> repair failing gates -> build real artifact -> execute independent suites -> render versioned docs -> capture one useful journey privately -> create/choose approved brand assets -> compose landing/docs preview -> clean install and stage release -> authorize and verify publication -> test rollback -> update case-study and source-linked state.

Then apply the reusable mechanism to each product role. A third repository may be a migration donor and should receive custody/lifecycle validation instead of runtime modernization. The source-target-consumer owner remains responsible for the whole outcome.

## Exact ownership

Three parent agents retain portfolio outcome responsibility. A child worker receives its target, next packet, required evidence and permission envelope. Cross-repo tasks are paired with the destination/shared-tool owner and independent verifier. Never let adjacent inventory names define an incoherent migration scope. A write lease is not a prohibition on authorized read-only contract inspection.

## WIP and resources

Use separate budgets for active targets, review-ready PRs, native/GPU capture, render, publishing and hosted CI. “At most three repos per chat” is not a global budget. Keep evidence readers parallel where safe; admit a small number of useful closure paths according to available review/hardware capacity. Native captures and expensive renders must not degrade the user's game or audio session.

## PERT and forecast

The work graph is concrete; duration estimates are not yet calibrated. Each packet has nullable optimistic/most-likely/pessimistic hours. PERT expected duration is `(O + 4M + P)/6`, variance `((P-O)/6)^2`. Once scoped estimates exist, compute earliest/latest times, slack and dependency-only critical paths mechanically, then model resource constraints separately. Do not invent a calendar forecast from 28 broad packets.

The [DAG](DAG.md) and machine records expose missing estimates explicitly. The validation code tests the calculation on a labelled synthetic example; no synthetic forecast is presented as the real plan.

## Closure

Report DESIGN_READY, PIPELINE_VERIFIED, PRODUCT_VERIFIED, PUBLISHED_VERIFIED and OPERATED_VERIFIED separately from existing AgilePlus feature states. All required target gates must have evidence at the accepted baseline. An external permission or implementation blocker remains owned. A useful task may finish while its product remains open. No “everything complete” from a docs ZIP, screenshot folder or a green status lacking an oracle.
