# Planning examples — not running deployments

The four JSON files demonstrate typed **proposed** contracts. None describes a live product, authorized route, produced asset or executed release. `example-tool` is an example slug, not a newly created repository. Replace/bind through actual subject/owner decisions before execution.

The schemas restrict shape; the reference semantic checks reject some misleading record combinations. They do not authenticate an operator, contact a cloud provider, verify external evidence receipts or prove implementation. Even a schema-valid record is not authority to publish.

The plan can be adapted to existing contracts rather than imposing these example paths on a tool. Do not write these records into an AgilePlus engine and infer state. Existing deployment/work tooling remains the canonical execution system.
