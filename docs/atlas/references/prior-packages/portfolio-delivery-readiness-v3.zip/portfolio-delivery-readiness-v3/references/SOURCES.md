# Source register

Pinned repository findings are source inspections, not executed product tests. External references were read for this plan; installed/deployed versions require a fresh local capability probe. A failed fetch does not establish a failed production deployment.

## G01 — PhenoDocs ref

https://github.com/KooshaPari/phenodocs/blob/9c8e695855b6861e22c5ac1b145d531cb1ecdb3d/README.md

Federation tool description; placeholder links; referenced deploy workflow.

Commit `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`; Git blob `9678aadc95c1abd7093b89e94f2fc56f8b0b5cb5`.

## G02 — Landing ref

https://github.com/KooshaPari/phenotype-landing/blob/a986d7a5e0fbfff7a89a2a7cb59b56a5e93b829c/README.md

Nested sites and intended phenotype.space product paths; not live deployment proof.

Commit `a986d7a5e0fbfff7a89a2a7cb59b56a5e93b829c`; Git blob `d9657011afd8bfa90f2cd2a41b35baaf379b6447`.

## G03 — PhenoDocs CI

https://github.com/KooshaPari/phenodocs/blob/9c8e695855b6861e22c5ac1b145d531cb1ecdb3d/.github/workflows/ci.yml

Advisory commands, weak discovery, wrong needs key and echo-only terminal test job.

Commit `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`; Git blob `cb5b578ea2992dd76eac2fbae2acd5327e2c2d22`.

## G04 — PhenoDocs release attestation

https://github.com/KooshaPari/phenodocs/blob/9c8e695855b6861e22c5ac1b145d531cb1ecdb3d/.github/workflows/release-attest.yml

Dummy artifact and shell expression in action input rather than evaluated output.

Commit `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`; Git blob `a58e2a81506e30c92265d6407ca1760760bb1bf7`.

## G05 — PhenoDocs consumer config

https://github.com/KooshaPari/phenodocs/blob/9c8e695855b6861e22c5ac1b145d531cb1ecdb3d/.vitepress/config.mts

Infers Pages path from any GitHub Actions run; concrete portfolio/site data.

Commit `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`; Git blob `29e528711de90ec5e1bc94b505edb4b676088d53`.

## G06 — PhenoDocs reusable configuration

https://github.com/KooshaPari/phenodocs/blob/9c8e695855b6861e22c5ac1b145d531cb1ecdb3d/packages/docs/src/config/index.ts

ignoreDeadLinks true, default owner and MIT footer.

Commit `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`; Git blob `589b67be6479b9df15e65503ef7ebb5756782924`.

## G07 — PhenoDocs rich views plan

https://github.com/KooshaPari/phenodocs/blob/9c8e695855b6861e22c5ac1b145d531cb1ecdb3d/docs/planning/rich-workspace-views.md

Generated data and federation listed as later phases; draft view contracts.

Commit `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`; Git blob `83f43a51c3a46215e03bca00c841128fd02a67f2`.

## G08 — Landing site configuration

https://github.com/KooshaPari/phenotype-landing/blob/a986d7a5e0fbfff7a89a2a7cb59b56a5e93b829c/sites/tracera-landing/vercel.json

Build commands only; no root route composition established.

Commit `a986d7a5e0fbfff7a89a2a7cb59b56a5e93b829c`; Git blob `f5b871dabbe6cfdb1a31ea58ca170e4e0d0c229d`.

## G09 — Landing CI

https://github.com/KooshaPari/phenotype-landing/blob/a986d7a5e0fbfff7a89a2a7cb59b56a5e93b829c/.github/workflows/ci.yml

Generic root discovery, advisory jobs, no site build matrix in this workflow.

Commit `a986d7a5e0fbfff7a89a2a7cb59b56a5e93b829c`; Git blob `14049e238f1f49cf9101a4b5ebc42c5e2d8a28be`.

## G10 — PhenoDocs link script

https://github.com/KooshaPari/phenodocs/blob/9c8e695855b6861e22c5ac1b145d531cb1ecdb3d/scripts/check_docs_links.py

Still prints stub OK and exits zero at this observed revision.

Commit `9c8e695855b6861e22c5ac1b145d531cb1ecdb3d`; Git blob `ddca435f62b5d0f5fe8721584f220c28e3bf7697`.

## G11 — AgilePlus scope work

https://github.com/KooshaPari/AgilePlus/blob/82130cae162d6743b9c7271c8fdef441f0f20ade/kitty-specs/eco-048-agileplus-project-scope/tasks.md

Existing repo-local scope work; task checkboxes are not running-engine proof.

Commit `82130cae162d6743b9c7271c8fdef441f0f20ade`; Git blob `144398141ba001c9b15b40f4e2dfad019a0dbd05`.

## G12 — AgilePlus state contract

https://github.com/KooshaPari/AgilePlus/blob/82130cae162d6743b9c7271c8fdef441f0f20ade/docs/agileplus/repo-state-contract.md

Explicit tooling/not cross-project authority; state and projection separation.

Commit `82130cae162d6743b9c7271c8fdef441f0f20ade`; Git blob `ef2fcff1e3a77d1299adb472fbf10a7add60a045`.

## W01 — GitHub Pages custom workflows

https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

Build/upload/deploy artifact chain and permissions.

## W02 — Vercel rewrites

https://vercel.com/docs/rewrites

Path routing and external-origin proxying; source base paths remain relevant.

## W03 — Vercel domains

https://vercel.com/docs/domains/working-with-domains

Project/domain mapping requires actual account verification.

## W04 — GitHub artifact attestations

https://docs.github.com/en/actions/how-tos/secure-your-work/use-artifact-attestations/use-artifact-attestations

Real subjects and verification; availability depends on visibility/plan.

## W05 — Vercel Hobby plan

https://vercel.com/docs/plans/hobby

Non-commercial personal use constraint; no assumption that a monetized portfolio qualifies.

## W06 — GitHub Pages limits

https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits

Static-site limits; not a SaaS/runtime host or bulk media archive.

## W07 — VitePress site configuration

https://vitepress.dev/reference/site-config

Explicit base, site/metadata and rendering configuration; match installed version.

## W08 — Playwright containers

https://playwright.dev/docs/docker

Pinned browser dependencies and sandbox/trust distinctions.

## W09 — Playwright screenshots

https://playwright.dev/docs/screenshots

Capture actual rendered state; asserts and raw traces remain separate.

## W10 — VHS

https://github.com/charmbracelet/vhs

Terminal recordings, tape files and export formats; requires suitable installed dependencies.

## W11 — Blender background rendering

https://docs.blender.org/manual/id/4.2/advanced/command_line/render.html

Stable CLI background-render model; verify actual installed version and options.

## W12 — Adobe Photoshop UXP scripting

https://developer.adobe.com/photoshop/uxp/scripting/

Host scripting automation; not proof of standalone Linux/headless application entitlement.

## W13 — Adobe After Effects automated rendering

https://helpx.adobe.com/after-effects/desktop/render-and-export/automate-rendering/automated-rendering-network-rendering.html

aerender/network rendering documentation; entitlement and host availability still need probe.

## W14 — OpenGitOps principles

https://opengitops.dev/

Declarative, immutable/versioned, automatically pulled and continuously reconciled; Git-triggered push alone is not full GitOps.

## W15 — GitHub Actions secure use

https://docs.github.com/en/actions/reference/security/secure-use

Least privilege, untrusted input and runner/action trust.

## W16 — GoReleaser

https://goreleaser.com/

Packaging/release tool candidate; verify free versus Pro feature availability before adoption.

## W17 — Public Phenotype home

https://phenotype.space/

Parsed public landing links use multiple legacy subdomains; not an authenticated Vercel/DNS audit.

## G13 — phenoDesign retirement notice

https://github.com/KooshaPari/phenoDesign/blob/main/README.md

Declares archived July 29; does not identify precise asset successor. Hosting archive flag not established.

## W18 — FFmpeg documentation

https://ffmpeg.org/documentation.html

Command-line media conversion and metadata; match installed-version docs.

## W20 — Krita command-line documentation

https://docs.krita.org/en/reference_manual/linux_command_line.html

Editable raster/animation source with documented export paths; platform probe required.

## W21 — OBS launch parameters

https://obsproject.com/kb/launch-parameters

Named recording/scene/profile automation; actual permissions and isolated native display required.

## G14 — Infrastructure repository charter

https://github.com/KooshaPari/phenotype-infra/blob/63f917dae4d73c65330b968af9950baa71fd255f/README.md

Claims consolidation of nanovms, PhenoCompose and BytePort; actual scope and IaC/product separation require adjudication.

Commit `63f917dae4d73c65330b968af9950baa71fd255f`; Git blob `f75ab5b42ee26100b79ac4f9f10e6d7937f70184`.

## G15 — Fleet operations charter

https://github.com/KooshaPari/phenotype-fleet-ops/blob/7f00cb39cbb4f88b35d791a30735ffa2b9fe2938/README.md

Calls itself phenotype-ops and advertises a different owner/repo in install and reusable workflow references; consumers and actual remote identity need verification.

Commit `7f00cb39cbb4f88b35d791a30735ffa2b9fe2938`; Git blob `815e134bc53b8a7f6fc2e891d27e86b128ba3358`.
