#!/usr/bin/env python3
"""Validate this planning dossier, not a product or a deployment authority.

Requires Python 3.10+ and jsonschema. No network, subprocess builds, or writes.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import re
import sys
from collections import deque
from pathlib import Path
from urllib.parse import unquote
try:
    import jsonschema
except ImportError as exc:
    raise SystemExit('Missing required local validator dependency: jsonschema. No check ran.') from exc

ROOT = Path(__file__).resolve().parents[1]


def topo(tasks: list[dict]) -> list[str]:
    ids = [t['id'] for t in tasks]
    if len(ids) != len(set(ids)):
        raise ValueError('duplicate task ID')
    dependencies = {t['id']: set(t['hard_dependencies']) for t in tasks}
    if any(len(t['hard_dependencies']) != len(set(t['hard_dependencies'])) for t in tasks):
        raise ValueError('duplicate dependency')
    if any(d not in dependencies for ds in dependencies.values() for d in ds):
        raise ValueError('unknown dependency')
    ready = deque(sorted(k for k, v in dependencies.items() if not v))
    result = []
    while ready:
        node = ready.popleft()
        result.append(node)
        for key in sorted(dependencies):
            if node in dependencies[key]:
                dependencies[key].remove(node)
                if not dependencies[key]:
                    ready.append(key)
    if len(result) != len(tasks):
        raise ValueError('dependency cycle')
    return result


def pert(tasks: list[dict]) -> dict:
    order = topo(tasks)
    missing = []
    duration = {}
    variance = {}
    for t in tasks:
        e = t['effort_hours']
        vals = [e.get(k) for k in ('optimistic', 'most_likely', 'pessimistic')]
        if any(v is None for v in vals):
            missing.append(t['id'])
            continue
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in vals):
            raise ValueError('invalid effort number')
        a, m, b = vals
        if not 0 <= a <= m <= b:
            raise ValueError('unordered/negative PERT estimate')
        duration[t['id']] = (a + 4 * m + b) / 6
        variance[t['id']] = ((b - a) / 6) ** 2
    if missing:
        return {'status': 'UNESTIMATED_PENDING_LOCAL_BASELINE', 'missing': missing, 'critical_path_hours': None}
    lookup = {t['id']: t for t in tasks}
    es, ef = {}, {}
    for node in order:
        es[node] = max((ef[d] for d in lookup[node]['hard_dependencies']), default=0)
        ef[node] = es[node] + duration[node]
    finish = max(ef.values(), default=0)
    ls, lf = {}, {}
    for node in reversed(order):
        successors = [k for k in order if node in lookup[k]['hard_dependencies']]
        lf[node] = min((ls[s] for s in successors), default=finish)
        ls[node] = lf[node] - duration[node]
    return {'status': 'DEPENDENCY_ONLY_MODEL_NOT_CALENDAR_FORECAST', 'critical_path_hours': finish,
            'nodes': {n: {'expected_hours': duration[n], 'variance': variance[n], 'earliest_start': es[n],
                          'earliest_finish': ef[n], 'latest_start': ls[n], 'latest_finish': lf[n],
                          'slack': max(0, ls[n]-es[n])} for n in order}}


def validate_record(kind: str, obj: dict, root: Path = ROOT) -> None:
    schema = json.loads((root/'schemas'/f'{kind}.schema.json').read_text())
    jsonschema.Draft202012Validator(schema, format_checker=jsonschema.FormatChecker()).validate(obj)
    verified = obj['state'] in ('product_verified', 'published_verified')
    if verified and obj.get('product_kind') == 'synthetic_canary':
        raise ValueError('canary cannot prove product verification')
    if obj['state'] == 'published_verified' and not obj['authorization_ref']:
        raise ValueError('published record missing claimed action-authority receipt (not authenticated here)')
    if kind == 'route':
        if '//' in obj['base_path'] or '..' in obj['base_path'] or obj['host'].endswith('.'):
            raise ValueError('route not normalized')
        if obj['state'] == 'published_verified' and (obj['origin_state'] != 'verified' or not obj['rollback_ref']):
            raise ValueError('published route lacks origin/rollback record')
    elif kind == 'capture':
        if verified and (obj['capture_mode'] != 'actual' or not obj['raw_master_ref']):
            raise ValueError('actual capture master required')
        if not obj['foreground_isolation']:
            raise ValueError('capture violates nondisruption requirement')
        if obj['state'] == 'published_verified' and obj['audience'] == 'public' and not obj['privacy_review_ref']:
            raise ValueError('public capture lacks privacy review reference')
    elif kind == 'asset':
        if obj['is_product_evidence'] and obj['origin'] not in ('actual_capture', 'derived_capture'):
            raise ValueError('authored/concept asset is not product evidence')
        if obj['is_product_evidence'] and set(obj['transforms']) & {'generative_fill', 'replace_ui', 'change_metrics', 'retime'}:
            raise ValueError('misleading evidence transform')
        if obj['origin'] == 'derived_capture' and not obj['derivative_of']:
            raise ValueError('derived capture missing master link')
        if obj['state'] == 'published_verified' and (obj['license_status'] != 'verified' or not obj['rights_ref']):
            raise ValueError('published asset lacks rights record')
    elif kind == 'release':
        if verified and not obj['clean_install_receipt']:
            raise ValueError('release lacks clean-install receipt')
        if obj['state'] == 'published_verified' and (not obj['provenance_receipt'] or not obj['rollback_ref']):
            raise ValueError('published release lacks provenance/rollback record')


def local_links(root: Path) -> list[str]:
    errors = []
    for p in root.rglob('*.md'):
        # Prose target-path existence only: no network/anchor crawling or Markdown execution.
        text = re.sub(r'```.*?```', '', p.read_text(), flags=re.S)
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', text):
            target = target.strip().split(' ')[0]
            if not target or target.startswith(('#', 'http:', 'https:', 'mailto:', '/')):
                continue
            local = unquote(target.split('#', 1)[0])
            if not (p.parent/local).exists():
                errors.append(f'{p.relative_to(root)} -> {target}')
    return errors


def validate(root: Path = ROOT) -> dict:
    errors = []
    parsed = {}
    for p in root.rglob('*.json'):
        try:
            parsed[str(p.relative_to(root))] = json.loads(p.read_text())
        except (json.JSONDecodeError, UnicodeError) as exc:
            errors.append(f'{p}: {exc}')
    if errors:
        return {'status':'INVALID_PACKAGE','errors':errors}
    for path, obj in parsed.items():
        if path.startswith('schemas/'):
            try: jsonschema.Draft202012Validator.check_schema(obj)
            except jsonschema.SchemaError as exc: errors.append(str(exc))
    for kind in ('route','capture','asset','release'):
        try: validate_record(kind, parsed['examples/'+kind+'.json'], root)
        except (ValueError, jsonschema.ValidationError) as exc: errors.append(f'{kind}: {exc}')
    work = parsed['work/work-packages.json']
    findings = parsed['data/findings.json']
    obligations = parsed['data/obligations.json']
    sources = parsed['data/sources.json']
    known = {'INT-DELIVERY-001'}
    for group in (work, findings, obligations, sources):
        ids = [x['id'] for x in group]
        if len(ids) != len(set(ids)): errors.append('duplicate identifiers')
        if known.intersection(ids): errors.append('cross-kind identifier collision')
        known.update(ids)
    work_ids = {x['id'] for x in work}; source_ids={x['id'] for x in sources}
    for entry in findings+obligations:
        if entry['work_package'] not in work_ids: errors.append('orphan work reference: '+entry['id'])
        for sid in entry['source_ids']:
            if sid not in source_ids: errors.append('orphan source: '+sid)
    for e in parsed['data/traceability.json']['edges']:
        if e['from'] not in known or e['to'] not in known: errors.append('unknown trace endpoint')
    traced = {e['to'] for e in parsed['data/traceability.json']['edges']}
    if any(x['id'] not in traced for x in obligations): errors.append('untraced obligation')
    for p in root.glob('specs/*/meta.json'):
        d=json.loads(p.read_text())
        for key in ('work_packages','finding_ids','acceptance_ids'):
            if any(i not in known for i in d[key]): errors.append('unknown spec reference: '+str(p))
        if d['engine_state'] != 'NOT_QUERIED': errors.append('unsupported engine state claim')
    try:
        order=topo(work); schedule=pert(work)
        expanded=[]
        for t in work:
            conditional=[d for c in t.get('conditional_dependencies', []) for d in c['requires']]
            expanded.append({**t, 'hard_dependencies': sorted(set(t['hard_dependencies'] + conditional))})
        topo(expanded)  # Even the conservative all-applicable union must remain acyclic.
    except ValueError as exc: errors.append(str(exc)); order=[]; schedule={}
    for receipt in parsed['provenance/source-captures.json']:
        raw=(root/receipt['path']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=receipt['sha256']: errors.append('source capture SHA256 mismatch')
        oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if oid!=receipt['git_blob_oid']: errors.append('source capture Git blob mismatch')
    source=parsed['docs/intent/PROVENANCE.json']
    if hashlib.sha256((root/'docs/intent'/source['file']).read_bytes()).hexdigest()!=source['sha256']:
        errors.append('human prompt hash mismatch')
    errors += local_links(root)
    if any(p.is_symlink() for p in root.rglob('*')): errors.append('unexpected symlink')
    result={'status':'INVALID_PACKAGE' if errors else 'PACKAGE_STRUCTURE_CONSISTENT',
            'product_approved':False,'deployment_performed':False,'errors':errors,
            'counts':{'findings':len(findings),'work_packages':len(work),'acceptance_obligations':len(obligations),
                      'sources':len(sources),'planning_schemas':4,'authored_spec_bundles':len(list(root.glob('specs/*/meta.json')))},
            'topological_order':order,'schedule':schedule,
            'limits':['Does not authenticate receipts or approval','Does not execute product tests or deploy',
                      'Checks prose relative file targets, not external links or every anchor']}
    return result


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    args=parser.parse_args()
    try: result=validate(args.root.resolve())
    except (KeyError,OSError,TypeError,ValueError) as exc:
        print(json.dumps({'status':'INVALID_PACKAGE','errors':[str(exc)],'product_approved':False})); return 1
    print(json.dumps(result,indent=2))
    return 0 if not result['errors'] else 1

if __name__=='__main__':
    raise SystemExit(main())
